import xbmc,os

addon_id   = 'plugin.video.bygencer'

icon       = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))

def cat():
	addDir('[COLOR white][B]panda1[/COLOR][/B]','panda1',3,'https://cdn6.aptoide.com/imgs/a/7/8/a78c34966c4e443e7235d839b5856c0d_icon.png?w=256',fanart,'')
	addDir('[COLOR white][B]panda2.com[/COLOR][/B]','panda2',3,'https://cdn6.aptoide.com/imgs/a/7/8/a78c34966c4e443e7235d839b5856c0d_icon.png?w=256',fanart,'')
	addDir('[COLOR white][B]panda3.com[/COLOR][/B]','panda3',3,'https://cdn6.aptoide.com/imgs/a/7/8/a78c34966c4e443e7235d839b5856c0d_icon.png?w=256',fanart,'')
	addDir('[COLOR white][B]panda4.com[/COLOR][/B]','panda4',3,'https://cdn6.aptoide.com/imgs/a/7/8/a78c34966c4e443e7235d839b5856c0d_icon.png?w=256',fanart,'')
	addDir('[COLOR white][B]OKEY 1[/COLOR][/B]','panda',3,'https://cdn6.aptoide.com/imgs/a/7/8/a78c34966c4e443e7235d839b5856c0d_icon.png?w=256',fanart,'')
	addDir('[COLOR white][B]Sourcetv.info[/COLOR][/B]','sourceetv',3,'https://cdn6.aptoide.com/imgs/a/7/8/a78c34966c4e443e7235d839b5856c0d_icon.png?w=256',fanart,'')
	
def get(url):
	if url == 'sourceetv':
		sourcetv()
	elif 'sourcetv' in url:
		sourcetvm3u(url)
	elif url == 'panda4':
		panda4()
	elif url == 'panda3':
		panda3()
	elif url == 'panda2':
		panda2()
	elif url == 'panda1':
		panda1()
	elif url == 'panda':
		panda()
	else:
		listm3u(url)
		
		
		
def panda():
	import re
	open = OPEN_URL('username=panelsourceturk&password=aH4Evh3BL0&type=m3u')
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for name,url in regex:
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,10,icon,fanart,'')
		
def panda1():
	import re
	open = OPEN_URL('https://dailyiptvlist.com/dl/tr-m3uplaylist-2019-11-10-2.m3u')
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for name,url in regex:
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,10,icon,fanart,'')
	
		
		
def panda2():
	import re
	open = OPEN_URL('https://dailyiptvlist.com/dl/tr-m3uplaylist-2019-11-10-3.m3u')
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for name,url in regex:
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,10,icon,fanart,'')
				
def panda3():
	import re
	open = OPEN_URL('https://dailyiptvlist.com/dl/tr-m3uplaylist-2019-11-10-5.m3u')
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for name,url in regex:
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,10,icon,fanart,'')
		
def panda4():
	import re
	open = OPEN_URL('https://dailyiptvlist.com/dl/tr-m3uplaylist-2019-11-10-6.m3u')
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for name,url in regex:
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,10,icon,fanart,'')
		
def sourcetv():
	open = OPEN_URL('https://sourcetv.info/')
	all  = regex_get_all(open,'<div class="article-image-wrapper">','<div class="panel">')
	for a in all:
		name = regex_from_to(a,'title="','"')
		url  = regex_from_to(a,'href="','"')
		icon = regex_from_to(a,'src="','"')
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,3,icon,fanart,'')
def sourcetvm3u(url):
	import re
	open = OPEN_URL(url)
	url  = regex_from_to(open,'<p><a href="','"')
	open = OPEN_URL(url)
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for name,url in regex:
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,10,icon,fanart,'')
		
		
def listm3u(url):
	import re
	open = OPEN_URL(url)
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for name,url in regex:
		if name.endswith('.ts') or name.endswith('.m3u'):
			url = name
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,10,icon,fanart,'')
######################################################################################################
		
		
		
def regex_from_to(text, from_string, to_string, excluding=True):
	import re,string
	if excluding:
		try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
		except: r = ''
	else:
		try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
		except: r = ''
	return r


def regex_get_all(text, start_with, end_with):
	import re,string
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r



def OPEN_URL(url):
	import requests
	headers = {}
	headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'
	link = requests.session().get(url, headers=headers, verify=False).text
	link = link.encode('ascii', 'ignore')
	return link
	
logfile    = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.bygencer', 'log.txt'))

def log(text):
	file = open(logfile,"w+")
	file.write(str(text))
	
	
def readfile(url,file):
            file = open(os.path.join(url, file))
            data = file.read()
            file.close()
            return data
		
		
def addDir(name,url,mode,iconimage,fanart,description):
	import xbmcgui,xbmcplugin,urllib,sys
	u=sys.argv[0]+"?url="+url+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==10:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
	xbmcplugin.endOfDirectory