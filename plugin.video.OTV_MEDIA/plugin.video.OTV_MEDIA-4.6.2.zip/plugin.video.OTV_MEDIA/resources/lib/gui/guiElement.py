# -*- coding: utf-8 -*-
from os import path
from resources.lib.comaddon import addon, xbmc
from resources.lib.config import cConfig
from resources.lib.util import cUtil
from resources.lib import logger
from resources.lib.db import cDb
import os, re, urllib, string
import sys
def alfabekodla(text):

        text = (str(text)).replace('\\x','')
        text = (str(text)).replace('\\u','')
        text = (str(text)).replace('&auml;','ä')
	text = (str(text)).replace('00e4','ä')
	text = (str(text)).replace('feff','ä')
        text = (str(text)).replace('&#228;','ä')
	text = (str(text)).replace('&Auml;','Ä')
	text = (str(text)).replace('00c4','Ä')
	text = (str(text)).replace('&#196;','Ä')
	text = (str(text)).replace('&ouml;','ö')
	text = (str(text)).replace('00f6','ö')
	text = (str(text)).replace('&#246;','ö')
	text = (str(text)).replace('&ouml;','Ö')
	text = (str(text)).replace('&Ouml;','Ö')
	text = (str(text)).replace('00d6','Ö')
	text = (str(text)).replace('&#214;','Ö')
	text = (str(text)).replace('&uuml;','ü')
	text = (str(text)).replace('00fc','ü')
	text = (str(text)).replace('&#252;','ü')
	text = (str(text)).replace('&Uuml;','Ü')
	text = (str(text)).replace('00dc','Ü')
	text = (str(text)).replace('&#220;','Ü')
        text = (str(text)).replace('tv_','player')
	text = (str(text)).replace('&szlig;','ß')
	text = (str(text)).replace('00df','ß')
	text = (str(text)).replace('&#223;','ß')
	text = (str(text)).replace('&amp;','&')
	text = (str(text)).replace('&quot;','\"')
	text = (str(text)).replace('&gt;','>')
	text = (str(text)).replace('&apos;',"'")
	text = (str(text)).replace('&acute;','\'')
	text = (str(text)).replace('&ndash;','-')
	text = (str(text)).replace('&bdquo;','"')
	text = (str(text)).replace('&rdquo;','"')
	text = (str(text)).replace('&ldquo;','"')
	text = (str(text)).replace('&lsquo;','\'')
	text = (str(text)).replace('&rsquo;','\'')
	text = (str(text)).replace('&#034;','\'')
	text = (str(text)).replace('&#038;','&')
	text = (str(text)).replace('&#039;','\'')
	text = (str(text)).replace('&#39;','\'')
	text = (str(text)).replace('&#160;',' ')
	text = (str(text)).replace('00a0',' ')
	text = (str(text)).replace('00b4','\'')
	text = (str(text)).replace('&#174;','')
	text = (str(text)).replace('&#225;','a')
	text = (str(text)).replace('&#233;','e')
	text = (str(text)).replace('&#243;','o')
	text = (str(text)).replace('&#8211;',"-")
	text = (str(text)).replace('2013',"-")
	text = (str(text)).replace('&#8216;',"'")
	text = (str(text)).replace('&#8217;',"'")
	text = (str(text)).replace('&#8220;',"'")
	text = (str(text)).replace('&#8221;','"')
	text = (str(text)).replace('&#8222;',',')
	text = (str(text)).replace('201e','\"')
	text = (str(text)).replace('201c','\"')
	text = (str(text)).replace('201d','\'')
	text = (str(text)).replace('2019s','\'')
	text = (str(text)).replace('00e0','à')
	text = (str(text)).replace('00e7','ç')
	text = (str(text)).replace('00e9','é')
	text = (str(text)).replace('&#xC4;','Ä')
	text = (str(text)).replace('&#xD6;','Ö')
	text = (str(text)).replace('&#xDC;','Ü')
	text = (str(text)).replace('&#xE4;','ä')
	text = (str(text)).replace('&#xF6;','ö')
	text = (str(text)).replace('&#xFC;','ü')
	text = (str(text)).replace('&#xDF;','ß')
	text = (str(text)).replace('&#xE9;','é')
	text = (str(text)).replace('&#xB7;','·')
	text = (str(text)).replace("&#x27;","'")
	text = (str(text)).replace("&#x26;","&")
	text = (str(text)).replace("&#xFB;","û")
	text = (str(text)).replace("&#xF8;","ø")   
	text = (str(text)).replace("&#x21;","!")                          
	text = (str(text)).replace("&#x3f;","?")
        text = (str(text)).replace("&#304;",  "I")       
        text = (str(text)).replace("&#304;",  "I")
        text = (str(text)).replace("&#39;", "'")
        text = (str(text)).replace('&#39;',"ş")
	text = (str(text)).replace('&#8230;','...')
	text = (str(text)).replace('2026','...')  
	text = (str(text)).replace('c59f','ş')
	text = (str(text)).replace('c4b1','ı')
        text = (str(text)).replace('c3b6','ö')
        text = (str(text)).replace('c3bc','ü')                    
        text = (str(text)).replace('c387','Ç')
        text = (str(text)).replace('c3a7','ç')
        text = (str(text)).replace('c396','Ö')
        text = (str(text)).replace('c4b0','İ')
        text = (str(text)).replace('c39c','ü')
        text = (str(text)).replace('c49f','ğ')
        text = (str(text)).replace('&#8234;','')
	text = (str(text)).replace("&#39;", "'")
        text = (str(text)).replace('&#39;',"ş")
	text = (str(text)).replace('&#8230;','...')
	text = (str(text)).replace('2026','...')
	text = (str(text)).replace('&hellip;','...')
	text = (str(text)).replace('&#8234;','')
        text = (str(text)).replace("&#231;", "ç")
        text = (str(text)).replace('&#351;',"ş")
	text = (str(text)).replace('&#350;','ş')
	text = (str(text)).replace('&#246;','ö')
	text = (str(text)).replace('&#214;','Ö')
	text = (str(text)).replace('&#199;','Ç')
        text = (str(text)).replace('0130','i')
        text = (str(text)).replace('00c7','Ç')
        text = (str(text)).replace('015e','�?')
        text = (str(text)).replace('015f','ş')
        text = (str(text)).replace('2014','-')
        text = (str(text)).replace('011e','�?')
        text = (str(text)).replace('0131','ı')
        text = (str(text)).replace('c59e','Ş')
        text = (str(text)).replace('c3a4','ä')
        text = (str(text)).replace('00e1','a')
        reload(sys)
        sys.setdefaultencoding("utf-8")
        return text                           


class cGuiElement:
    '''
    This class "abstracts" a xbmc listitem.

    Kwargs:
        sTitle    (str): title/label oft the GuiElement/listitem
        sSite     (str): siteidentifier of the siteplugin, which is called if the GuiElement is selected 
        sFunction (str): name of the function, which is called if the GuiElement is selected
    
        These arguments are mandatory. If not given on init, they have to be set by their setter-methods, before the GuiElement is added to the Gui. 
    '''
#    DB = cDb()
    DEFAULT_FOLDER_ICON = 'DefaultFolder.png'
   
    MEDIA_TYPES = ['movie','tvshow','season','episode']
    ADDON = addon()
    def __init__(self, sTitle = '', sSite = None, sFunction = None):
        self.__sRootArt = 'special://home/addons/plugin.video.OTV_MEDIA/resources/art/'

        self.__sType = 'video'
        self.__sMediaUrl = ''
        self.__sTitle = cUtil.cleanse_text(sTitle)
        self.__sTitleSecond = ''
        self.__sDescription = ''
        self.__sThumbnail = ''
        self.__sIcon = self.DEFAULT_FOLDER_ICON
        self.__aItemValues = {}
        self.__aProperties = {}
        self.__aContextElements = []
        self.__sMetaAddon = self.ADDON.getSetting('meta-view')
        self.__sMeta = 0
        self.__sPlaycount = 0        
        self.__sFanart = "special://home/addons/plugin.video.OTV_MEDIA/fanart.jpg"
        self.__sMediaUrl = ''
        self.__sSiteUrl = ''
        self.__sSiteName = sSite
        self.__sFunctionName = sFunction
        self._sLanguage = ''
        self._sSubLanguage = ''
        self.__TmdbId = ''
        self._sYear = ''
        self.__sPoster = ''
        self._sQuality = ''
        self._mediaType = ''
        self.__sMediaUrl = ''
        self.__sFileName = ''
        self._season = ''
        self._episode = ''
        self.__ImdbId = ''
        self.__aItemValues = {}
        self._imdbID = ''
        self._rating = ''
        self._isMetaSet = False
        self.__sCat = ''
       
    def setType(self, sType):
        self.__sType = sType

    def getType(self):
        return self.__sType
    def setMetaAddon(self, sMetaAddon):
        self.__sMetaAddon = sMetaAddon
    def getCleanTitle(self):
        self.__sTitle=alfabekodla(self.__sTitle)
        return self.__sTitle

    def setMediaUrl(self, sMediaUrl):
        self.__sMediaUrl = sMediaUrl
    def addItemValues(self, sItemKey, mItemValue):
        self.__aItemValues[sItemKey] = mItemValue

    def getMediaUrl(self):
        return self.__sMediaUrl
    def setImdbId(self, data):
        self.__ImdbId = data

    def getImdbId(self):
        return self.__ImdbId

    def setSiteName(self, sSiteName):
        self.__sSiteName = sSiteName

    def getSiteName(self):
        return self.__sSiteName
    def setMeta(self, sMeta):
        self.__sMeta = sMeta

    def getMeta(self):
        return self.__sMeta
    def setCat(self, sCat):
        self.__sCat = sCat
    def setFileName(self, sFileName):
        self.__sFileName = sFileName

    def getFileName(self):
        return self.__sFileName

    def getCat(self):
        return self.__sCat
    def setTmdbId(self, data):
        self.__TmdbId = data

    def getTmdbId(self):
        return self.__TmdbId
    def getFileName(self):
        return self.__sFileName

    def setFunction(self, sFunctionName):
        self.__sFunctionName = sFunctionName
    def setSiteUrl(self, sSiteUrl):
        self.__sSiteUrl = sSiteUrl

    def getSiteUrl(self):
        return self.__sSiteUrl
    def getFunction(self):
        return self.__sFunctionName
    def setMediaUrl(self, sMediaUrl):
        self.__sMediaUrl = sMediaUrl

    def getMediaUrl(self):
        return self.__sMediaUrl
    def getInfoLabel(self):
        meta = {
        'title': xbmc.getInfoLabel('ListItem.title'),
        'label': xbmc.getInfoLabel('ListItem.title'),
        'originaltitle': xbmc.getInfoLabel('ListItem.originaltitle'),
        'year': xbmc.getInfoLabel('ListItem.year'),
        'genre': xbmc.getInfoLabel('ListItem.genre'),
        'director': xbmc.getInfoLabel('ListItem.director'),
        'country': xbmc.getInfoLabel('ListItem.country'),
        'rating': xbmc.getInfoLabel('ListItem.rating'),
        'votes': xbmc.getInfoLabel('ListItem.votes'),
        'mpaa': xbmc.getInfoLabel('ListItem.mpaa'),
        'duration': xbmc.getInfoLabel('ListItem.duration'),
        'trailer': xbmc.getInfoLabel('ListItem.trailer'),
        'writer': xbmc.getInfoLabel('ListItem.writer'),
        'studio': xbmc.getInfoLabel('ListItem.studio'),
        'tagline': xbmc.getInfoLabel('ListItem.tagline'),
        'plotoutline': xbmc.getInfoLabel('ListItem.plotoutline'),
        'plot': xbmc.getInfoLabel('ListItem.plot'),
        'cover_url': xbmc.getInfoLabel('ListItem.Art(thumb)'),
        'backdrop_url': xbmc.getInfoLabel('ListItem.Art(fanart)'),
        'imdb_id': xbmc.getInfoLabel('ListItem.IMDBNumber'),
        'season': xbmc.getInfoLabel('ListItem.season'),
        'episode': xbmc.getInfoLabel('ListItem.episode')
        }

        if meta['title']:
            meta['title'] = self.getTitle()

        for key, value in meta.items():
            self.addItemValues(key, value)

        if meta['backdrop_url']:
            self.addItemProperties('fanart_image', meta['backdrop_url'])
            self.__sFanart = meta['backdrop_url']
        if meta['trailer']:
            meta['trailer'] = meta['trailer'].replace(u'\u200e', '').replace(u'\u200f', '')
            self.__sTrailerUrl = meta['trailer']
        if meta['cover_url']:
            self.__sThumbnail = meta['cover_url']
            self.__sPoster = meta['cover_url']

        return

    def setTitle(self, sTitle):
        self.__sTitle = cUtil.cleanse_text(sTitle)

    def getTitle(self):
        return self.__sTitle

    def setMediaType(self, mediaType):
        '''
        Set mediatype for GuiElement

        Args:
            mediaType(str): 'movie'/'tvshow'/'season'/'episode'
        '''
        mediaType = mediaType.lower()
        if mediaType in self.MEDIA_TYPES:
            self._mediaType = mediaType
        else:
            logger.info('Unknown MediaType given for %s' % self.getTitle())

    def setSeason(self, season):
        self._season = season
        self.__aItemValues['season'] = str(season)

    def setEpisode(self, episode):
        self._episode = episode
        self.__aItemValues['episode'] = str(episode)

    def setTVShowTitle(self, tvShowTitle):
        self.__aItemValues['TVShowTitle'] = str(tvShowTitle)

    def setYear(self, year):
        try:
            year = int(year)
        except:
            logger.info('Year given for %s seems not to be a valid number' % self.getTitle())
            return False
        if len(str(year)) != 4:
            logger.info('Year given for %s has %s digits, required 4 digits' % (self.getTitle(), len(str(year))))
            return False
        if year > 0:
            self._sYear = str(year)
            self.__aItemValues['year'] = year
            return True
        else:
            logger.info('Year given for %s must be greater than 0' % self.getTitle())
            return False

    def setTitleSecond(self, sTitleSecond):
        self.__sTitleSecond = cUtil.cleanse_text(str(sTitleSecond))

    def getTitleSecond(self):
        return self.__sTitleSecond

    def setDescription(self, sDescription):
        sDescription = cUtil.cleanse_text(sDescription)
        self.__sDescription = sDescription
        self.__aItemValues['plot'] = sDescription

    def getDescription(self):
        if 'plot' not in self.__aItemValues:
            return self.__sDescription
        else:
            return self.__aItemValues['plot']

    def setThumbnail(self, sThumbnail):
        self.__sThumbnail = sThumbnail

    def getThumbnail(self):
        return self.__sThumbnail

    def setIcon(self, sIcon):
        try:
            self.__sIcon = unicode(sIcon, 'utf-8')
        except:
            self.__sIcon = sIcon
        self.__sIcon = self.__sIcon.encode("utf-8")
        self.__sIcon = urllib.quote_plus(self.__sIcon, safe=':/')

    def getIcon(self):
        #if 'http' in self.__sIcon:
        #    return urllib.unquote_plus(self.__sIcon)
        folder = "special://home/addons/plugin.video.OTV_MEDIA/resources/art"
        path = "/".join([folder, self.__sIcon]) 
        #return os.path.join(unicode(self.__sRootArt, 'utf-8'), self.__sIcon)
        return path

    
    def setFanart(self, sFanart):
        self.__sFanart = sFanart

    def getFanart(self):
        return self.__sFanart
    def setPoster(self, sPoster):
        self.__sPoster = sPoster

    def getPoster(self):
        return self.__sPoster

    def addItemValue(self, sItemKey, sItemValue):
        self.__aItemValues[sItemKey] = sItemValue
        
    def setItemValues(self, aValueList):
        self.__aItemValues = aValueList

    def getItemValues(self):
        self.__aItemValues['title'] = self.getTitle()
        if self.getDescription():
            self.__aItemValues['plot'] = self.getDescription()
        for sPropertyKey in self.__aProperties.keys():
            self.__aItemValues[sPropertyKey] = self.__aProperties[sPropertyKey]
        return self.__aItemValues
    
    def addItemProperties(self, sPropertyKey, sPropertyValue):
        self.__aProperties[sPropertyKey] = sPropertyValue
  
    def getItemProperties(self):
        for sItemValueKey in self.__aItemValues.keys():
            if not self.__aItemValues[sItemValueKey]=='':
                try:
                    self.__aProperties[sItemValueKey] = str(self.__aItemValues[sItemValueKey])
                except:
                    pass
        return self.__aProperties

    def addContextItem(self, oContextElement):
        self.__aContextElements.append(oContextElement)

    def getContextItems(self):
        return self.__aContextElements

    def setLanguage(self, sLang):
        self._sLanguage = str(sLang)

    def setSubLanguage(self, sLang):
        self._sSubLanguage = str(sLang)

