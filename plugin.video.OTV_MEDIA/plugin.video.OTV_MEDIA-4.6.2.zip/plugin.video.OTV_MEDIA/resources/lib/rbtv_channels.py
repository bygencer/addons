import requests
import json
import string
import random
from base64 import b64decode


class rbtvChannels(object):
    def __init__(self,config, user=""):
        self.config = config
        self.user = user
        self.s = requests.Session()
        self.s.headers.update({"User-Agent": "Dalvik/2.1.0 (Linux; U; Android 5.1.1; AFTT Build/LVY48F)"})

    @staticmethod
    def id_generator(size=8, chars=string.ascii_lowercase + string.digits):
        return "".join(random.choice(chars) for _ in range(size))

    def register_user(self):
        user_url =  "http://163.172.111.138:8030/rbtv/i/adduserinfo.nettv/"
        data = {"api_level": "19", "android_id": self.id_generator(16), "device_id": "unknown", "device_name": "AFTT", "version": "1.3 (31)"}
        headers = {
            "Referer": "http://welcome.com/",
            "Authorization": "Basic aGVsbG9NRjpGdWNrb2Zm",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "User-Agent": "Dalvik/1.6.0 (Linux; U; Android 4.4.2; LGM-V300K Build/N2G47H)",
            "Host": "163.172.111.138:8030",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "Content-Length": "115"
        }
        r = self.s.post(user_url, headers=headers, data=data)
        self.user = str(r.json().get("user_id"))

    def get_channel_list(self):
        check = "1"
        if not self.user:
            self.register_user()
            check = "8"
        list_url ="http://163.172.111.138:8030/rbtv/i/redbox.tv/"
        data = {"check": "1", "user_id": "210210", "version": "31"}
        headers = {
            "Referer": "http://welcome.com/",
            "Authorization": "Basic aGVsbG9NRjpGdWNrb2Zm",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "User-Agent": "Dalvik/1.6.0 (Linux; U; Android 4.4.2; LGM-V300K Build/N2G47H)",
            "Host": "163.172.111.138:8030",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "Content-Length": "34"
        }
        r = self.s.post(list_url, headers=headers, data=data)
        return r.json()
