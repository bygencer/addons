# -*- coding: utf-8 -*-
import re
from resources.lib import logger
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.otvhelper import *
SITE_IDENTIFIER = 'kinox_one'
SITE_NAME = 'KINOX.ONE'
SITE_ICON = 'kinox_one.png'
SITE_GLOBAL_SEARCH = False

URL_MAIN = 'http://kinox.one'
URL_FILME = URL_MAIN + '/movies/'
URL_SERIEN = URL_MAIN + '/tv-shows/'
URL_CARTOONS = URL_MAIN + '/cartoons/'


def load():
    logger.info("Load %s" % SITE_NAME)
    oGui = cGui()
    params = ParameterHandler()
    params.setParam('sUrl', URL_FILME)
    oGui.addFolder(cGuiElement('Filme', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_SERIEN)
    oGui.addFolder(cGuiElement('Serien', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_CARTOONS)
    oGui.addFolder(cGuiElement('Cartoons', SITE_IDENTIFIER, 'showEntries'), params)
    oGui.addFolder(cGuiElement('Genre', SITE_IDENTIFIER, 'showGenre'))
    oGui.addFolder(cGuiElement('Suche', SITE_IDENTIFIER, 'showSearch'))
    oGui.setEndOfDirectory()


def showGenre():
    oGui = cGui()
    params = ParameterHandler()
    sHtmlContent = cRequestHandler(URL_MAIN).request()
    isMatch, aResult = cParser.parse(sHtmlContent, '<a[^>]*href="([^"]+)">([^<]+)</a></li><li>')

    if not isMatch:
        oGui.showInfo('xStream', 'Es wurde kein Eintrag gefunden')
        return

    for sUrl, sName in aResult:
        params.setParam('sUrl', URL_MAIN + sUrl)
        oGui.addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    oGui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=None):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    oRequest.addHeaderEntry('Upgrade-Insecure-Requests', '1')
    if sSearchText:
        oRequest.addParameters('do', 'search')
        oRequest.addParameters('story', sSearchText)
        oRequest.addParameters('subaction', 'search')  
        oRequest.setRequestType(1)
    sHtmlContent = oRequest.request()

    pattern = '<a[^>]href="([^"]+)"><div.*?<img[^>]src="([^"]+).*?<div[^>]class="tiitle">([^<]+).*?<div[^>]class="shortttt">([^<]+)'
    isMatch, aResult = cParser().parse(sHtmlContent, pattern)

    if not isMatch:
        if not sGui: oGui.showInfo('xStream', 'Es wurde kein Eintrag gefunden')
        return

    total = len(aResult)
    for sUrl, sThumbnail, sName, sYear in aResult:
        sYear = re.compile("([0-9]{4})").findall(sYear)
        for year in sYear:
            sYear = year
            break
        isTvshow = True if "staffel" in sName.lower() else False
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showEpisodes' if isTvshow else 'showHosters')
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        oGuiElement.setThumbnail(URL_MAIN + sThumbnail)
        oGuiElement.setFanart(URL_MAIN + sThumbnail)
        oGuiElement.setYear(sYear)
        oGuiElement.setMediaType('movie')
        params.setParam('entryUrl', sUrl)
        oGui.addFolder(oGuiElement, params, isTvshow, total)
    if not sGui:
        isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, '<a[^>]href="([^"]+)">Next</a>')
        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('movies')
        oGui.setEndOfDirectory()


def showEpisodes():
    oGui = cGui()
    params = ParameterHandler()
    sUrl = ParameterHandler().getValue('entryUrl')
    oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('Upgrade-Insecure-Requests', '1')
    sHtmlContent = oRequest.request()
    
    pattern = 'data-title="([^"]+).*?data-url="([^"]+)'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        oGui.showInfo('xStream', 'Es wurde kein Eintrag gefunden')
        return
    total = len(aResult)
    for sName, sUrl in aResult:
        if not 'trailer' in sName.lower():
            oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'getHosterUrl')
            params.setParam('sUrl', sUrl)
            oGui.addFolder(oGuiElement, params, False, total)
    oGui.setView('episodes')
    oGui.setEndOfDirectory()


def showSearch():
    oGui = cGui()
    sSearchText = oGui.showKeyBoard()
    if not sSearchText: return
    _search(False, sSearchText)
    oGui.setEndOfDirectory()


def _search(oGui, sSearchText):
    if not sSearchText: return
    showEntries(URL_MAIN, oGui, sSearchText)


def showHosters():
    oGui = cGui()
    Url = ParameterHandler().getValue('entryUrl')
    oRequest = cRequestHandler(Url)
    oRequest.addHeaderEntry('Upgrade-Insecure-Requests', '1')
    sHtmlContent = oRequest.request()
    sPattern = 'data-title="([^"]+)" data-type="m4v" data-url="([^"]+)"'
    isMatch, aResult = cParser().parse(sHtmlContent, sPattern)
    name ='test'
    cooki = getUrl(Url, output='cookie').result
    if isMatch:
        for sTitle,sUrl in aResult:
            
    
   
             sTitle = alfabekodla(sTitle)         
             oOutputParameterHandler = cOutputParameterHandler()
             oOutputParameterHandler.addParameter('siteUrl',str(sUrl))
             oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
             oGui.addDir(SITE_IDENTIFIER , 'sayfaHosters', sTitle, 'tv.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()
                                                                                      


def getHosterUrl(sUrl=False):
    if sUrl.startswith('//'):
        sUrl = 'https:' + sUrl
    if 'apollostream' in sUrl or 'newcloud' in sUrl or 'kinoger.pw' in sUrl:
        return [{'streamUrl': sUrl + '|Referer=' + sUrl + '&User-Agent=Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0', 'resolved': True}]
    else:
        return [{'streamUrl': sUrl , 'resolved': False}]
def play__hdfilme():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    sTitle = alfabekodla(sTitle)
    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sTitle)
    oGuiElement.setMediaUrl(sUrl)
    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    oPlayer.startPlayer()
                                                                                            

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok       