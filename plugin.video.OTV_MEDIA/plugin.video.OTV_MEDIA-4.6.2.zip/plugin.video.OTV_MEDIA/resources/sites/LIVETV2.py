# Embedded file name: C:\Users\orhan\AppData\Roaming\Kodi\addons\plugin.video.OTV_MEDIA\resources\sayfalar\LIVETV.py
from resources.lib.otvhelper import *
SITE_IDENTIFIER = 'LIVETV2'
SITE_NAME = 'LIVE NET TV'
SPORT_SPORTS = (True, 'root')
from pyDes import des, PAD_PKCS5
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
from xbmcgui import ListItem
from routing import Plugin
import requests_cache
import sys
import os
import io
import time
import json
import requests
import datetime
from datetime import timedelta
from base64 import b64decode, urlsafe_b64encode
from itertools import chain
from routing import Plugin
try:
    from urllib.parse import quote as orig_quote
except ImportError:
    from urllib import quote as orig_quote


AddonID = 'plugin.video.OTV_MEDIA'
addon = xbmcaddon.Addon(AddonID)
plugin = Plugin()
s = requests.Session()
plugin.name = addon.getAddonInfo('name')
user_agent = 'stagefright/1.2 (Linux;Android 4.4.2)'
implemented = ['0',
 '38',
 '21',
 '48']
USER_DATA_DIR = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
ADDON_DATA_DIR = xbmc.translatePath(addon.getAddonInfo('path')).decode('utf-8')
RESOURCES_DIR = os.path.join(ADDON_DATA_DIR, 'resources')
user_file = os.path.join(RESOURCES_DIR, 'user.json')
channel_list_file = os.path.join(RESOURCES_DIR, 'channels.json')
app_config_file = os.path.join(RESOURCES_DIR, 'config.json')
data_time = int(addon.getSetting('data_time') or '0')
cache_time = int(addon.getSetting('cache_time') or '0')

user_id = addon.getSetting('user_id')
CACHE_TIME = int(addon.getSetting('cache_time'))
CACHE_FILE = os.path.join(USER_DATA_DIR, 'cache')
expire_after = timedelta(hours=CACHE_TIME)
player_user_agent = 'mediaPlayerhttp/2.4 (Linux;Android 5.1) ExoPlayerLib/2.6.1'
if not os.path.exists(USER_DATA_DIR):
    os.makedirs(USER_DATA_DIR)

def quote(s, safe = ''):
    return orig_quote(s.encode('utf-8'), safe.encode('utf-8'))


try:
    with io.open(user_file, 'r', encoding='utf-8') as f:
        user = json.loads(f.read())
except IOError:
    user = ''

current_time = int(time.time())
if current_time - data_time > cache_time * 60 * 60:
    try:
        new_config = rbtvConfig(user=user)
        app_config = new_config.get_data()
        with io.open(user_file, 'w', encoding='utf-8') as f:
            f.write(json.dumps(new_config.user, indent=2, sort_keys=True, ensure_ascii=False))
        with io.open(app_config_file, 'w', encoding='utf-8') as f:
            f.write(json.dumps(app_config, indent=2, sort_keys=True, ensure_ascii=False))
    except:
        with io.open(app_config_file, 'r', encoding='utf-8') as f:
            app_config = json.loads(f.read())

    try:
        new_channels = rbtvChannels(app_config, user_id)
        channel_list = new_channels.get_channel_list()
        addon.setSetting('user_id', new_channels.user)
        with io.open(channel_list_file, 'w', encoding='utf-8') as f:
            f.write(json.dumps(channel_list, indent=2, sort_keys=True, ensure_ascii=False))
    except:
        with io.open(channel_list_file, 'r', encoding='utf-8') as f:
            channel_list = json.loads(f.read())

    addon.setSetting('data_time', str(int(time.time())))
else:
    try:
        with io.open(app_config_file, 'r', encoding='utf-8') as f:
            app_config = json.loads(f.read())
    except IOError:
        app_config = ''

    try:
        with io.open(channel_list_file, 'r', encoding='utf-8') as f:
            channel_list = json.loads(f.read())
    except IOError:
        channel_list = ''

def fix_auth_date(auth):
    now = datetime.datetime.utcnow()
    _in = list(auth)
    _in.pop(len(_in) + 2 - 3 - int(str(now.year)[:2]))
    _in.pop(len(_in) + 3 - 4 - int(str(now.year)[2:]))
    _in.pop(len(_in) + 4 - 5 - (now.month - 1 + 1 + 10))
    _in.pop(len(_in) + 5 - 6 - now.day)
    return ''.join(_in)


def get_auth_token_38():
    wms_url = b64decode(app_config[0].get('YmVsZ2lfMzgw')[1:])
    auth = b64decode(app_config[0].get('Z2Vsb29mc2JyaWVm')[1:])
    mod_value = int(b64decode(app_config[0].get('TW9vbl9oaWsx')[1:]))
    modified = lambda value: ''.join(chain(*zip(str(int(time.time()) ^ value), '0123456789')))
    fix_auth = lambda auth: ''.join([auth[:-59],
     auth[-58:-52],
     auth[-51:-43],
     auth[-42:-34],
     auth[-33:]])
    req = requests.Request('GET', wms_url, headers={'User-Agent': user_agent,
     'Accept-Encoding': 'gzip',
     'Modified': modified(mod_value),
     'Authorization': auth})
    prq = req.prepare()
    r = s.send(prq)
    return fix_auth(r.text)


def get_auth_token_21():
    wms_url = b64decode(app_config[0].get('Y2FsYWFtb19pa3Mw')[1:])
    auth = b64decode(app_config[0].get('WXJfd3lmX3luX2JhaXMw')[1:])
    mod_value = int(b64decode(app_config[0].get('TW9vbl9oaWsx')[1:]))
    modified = lambda value: ''.join(chain(*zip(str(int(time.time()) ^ value), '0123456789')))
    req = requests.Request('GET', wms_url, headers={'User-Agent': user_agent,
     'Accept-Encoding': 'gzip',
     'Modified': modified(mod_value),
     'Authorization': auth})
    prq = req.prepare()
    r = s.send(prq)
    return r.text


def get_auth_token_48():
    wms_url = b64decode(app_config[0].get('Ym9ya3lsd3VyXzQ4')[1:])
    auth = b64decode(app_config[0].get('dGVydHRleWFj')[1:])
    mod_value = int(b64decode(app_config[0].get('TW9vbl9oaWsx')[1:]))
    modified = lambda value: ''.join(chain(*zip(str(int(time.time()) ^ value), '0123456789')))
    req = requests.Request('GET', wms_url, headers={'User-Agent': user_agent,
     'Accept-Encoding': 'gzip',
     'Modified': modified(mod_value),
     'Authorization': auth})
    prq = req.prepare()
    r = s.send(prq)
    return fix_auth_date(r.text)


def lrroootom():
    oGui = cGui()
    categories = channel_list.get('categories_list')
    for c in categories:
        sTitle = c.get('cat_name')
        url = c.get('cat_id')
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', url)
        oGui.addDir(SITE_IDENTIFIER, 'list_channels', sTitle, 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()
def list_channels():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    cat = oInputParameterHandler.getValue('siteUrl')
    list_items = []
    for channel in channel_list.get("eY2hhbm5lbHNfbGlzdA=="):
        if channel.get("cat_id") == cat:
            if len([stream for stream in channel.get("Qc3RyZWFtX2xpc3Q=") if b64decode(stream.get("AdG9rZW4=")[:-1]) in implemented]) == 0:
                continue

            title = b64decode(channel.get("ZY19uYW1l")[:-1])
            icon = b64decode(channel.get("abG9nb191cmw=")[1:])
            image = "{0}|User-Agent={1}".format(icon, quote(user_agent))
            c_id = channel.get("rY19pZA==")
           
            title  = alfabekodla(title)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', c_id)
            oOutputParameterHandler.addParameter('sMovieTitle', str(title))
            oOutputParameterHandler.addParameter('sThumbnail', image) #sortis du poster
            oGui.addMovie(SITE_IDENTIFIER, 'play', title , image, image, '', oOutputParameterHandler)
            


    oGui.setEndOfDirectory()

def play():
    for channel in channel_list.get("eY2hhbm5lbHNfbGlzdA=="):
        oInputParameterHandler = cInputParameterHandler()
        c_id = oInputParameterHandler.getValue('siteUrl')
        if channel.get("rY19pZA==") == c_id:
            selected_channel = channel
            break

    # stream_list = selected_channel.get("Qc3RyZWFtX2xpc3Q=")
    stream_list = [stream for stream in selected_channel.get("Qc3RyZWFtX2xpc3Q=") if b64decode(stream.get("AdG9rZW4=")[:-1]) in implemented]
    if len(stream_list) > 1:
        select_list = []
        for stream in stream_list:
            select_list.append(b64decode(stream.get("Bc3RyZWFtX3VybA==")[1:]))

        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose Stream", select_list)
        selected_stream = stream_list[ret]
    else:
        selected_stream = stream_list[0]

    if "AdG9rZW4=" in selected_stream:
        if b64decode(selected_stream.get("AdG9rZW4=")[:-1]) == "38":
            media_url = b64decode(selected_stream.get("Bc3RyZWFtX3VybA==")[1:]) + get_auth_token_38()
        elif b64decode(selected_stream.get("AdG9rZW4=")[:-1]) == "21":
            media_url = b64decode(selected_stream.get("Bc3RyZWFtX3VybA==")[1:]) + get_auth_token_21()
        elif b64decode(selected_stream.get("AdG9rZW4=")[:-1]) == "48":
            media_url = b64decode(selected_stream.get("Bc3RyZWFtX3VybA==")[1:]) + get_auth_token_48()
        elif b64decode(selected_stream.get("AdG9rZW4=")[:-1]) == "0":
            media_url = b64decode(selected_stream.get("Bc3RyZWFtX3VybA==")[1:])
    else:
        media_url = b64decode(selected_stream.get("Bc3RyZWFtX3VybA==")[1:])

    if selected_stream.get("player_user_agent", user_agent) == None \
    or selected_stream.get("player_user_agent", user_agent) == "null" \
    or selected_stream.get("player_user_agent", user_agent) == "":
        selected_stream["player_user_agent"] = user_agent

    media_url = "{0}|User-Agent={1}".format(media_url, quote(selected_stream.get("player_user_agent", user_agent)))

    title = b64decode(selected_channel.get("ZY19uYW1l")[:-1])
    icon = b64decode(selected_channel.get("abG9nb191cmw=")[1:])
    image = "{0}|User-Agent={1}".format(icon, quote(user_agent))

    if 'playlist.m3u8' in media_url:
         url = "{0}|User-Agent={1}".format(media_url, quote(selected_stream.get("player_user_agent")))
             
    else:
         url = '{0}|User-Agent={1}'.format(media_url, quote(user_agent))
              
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+title,url,'')     




def howHosters(media_url,name):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
   
    sThumb= oInputParameterHandler.getValue('sThumb')
   
    
    

   
    sHosterUrl = media_url
 
    #oHoster = __checkHoster(sHosterUrl)
    oHoster = cHosterGui().checkHoster(name)
    if (oHoster != False):
            oHoster.setDisplayName(sMovieTitle)
            oHoster.setFileName(sMovieTitle)
            cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()

     

def kshowHosters(url):
    name = 'true'
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]' + name, url, '')


def addLink(name, url, iconimage):
    ok = True
    liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title': name})
    liz.setProperty('IsPlayable', 'true')
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=str(url), listitem=liz)
    xbmc.Player().play(url, liz)
    sys.exit()
    return ok


def _m3u8Exit(self):
    import otv_kuresel
    otv_kuresel.yt_tmp_storage_dirty = True


s = requests_cache.CachedSession(CACHE_FILE, allowable_methods='POST', expire_after=expire_after, old_data_on_error=True)
s.hooks = {'response': lambda r, *args, **kwargs: r.raise_for_status()}
s.headers.update({'User-Agent': 'USER-AGENT-tvtap-APP-V2'})
token_url = 'http://tvtap.net/tvtap1/index_tvtappro.php?case=get_channel_link_with_token_tvtap_updated'
list_url = 'http://tvtap.net/tvtap1/index_tvtappro.php?case=get_all_channels'
User_Agent = 'Dalvik/2.1.0 (Linux; U; Android 5.1.1; AFTS Build/LVY48F)'

def quote(s, safe = ''):
    return orig_quote(s.encode('utf-8'), safe.encode('utf-8'))


def rooot():
    oGui = cGui()
    liste = []
    liste.append(['5', 'Sport'])
    liste.append(['6', 'Documentary'])
    liste.append(['10', 'UK & USA Channels'])
    liste.append(['1', 'Entertainment'])
    liste.append(['2', 'Movies'])
    liste.append(['4', 'News'])
    liste.append(['7', 'Kids'])
    liste.append(['8', 'Food'])
    liste.append(['9', 'Religious'])
    for sUrl, sTitle in liste:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oGui.addDir(SITE_IDENTIFIER, 'liste_channels', sTitle, 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def liste_channels():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    cat_id = oInputParameterHandler.getValue('siteUrl')
    r = s.post(list_url, headers={'app-token': '9120163167c05aed85f30bf88495bd89'}, data={'username': '603803577'}, timeout=15)
    if 'Could not connect' in r.content:
        s.cache.clear()
    ch = r.json()
    for c in ch['msg']['channels']:
        if c['cat_id'] == cat_id:
            image = 'http://tvtap.net/tvtap1/{0}|User-Agent={1}'.format(quote(c.get('img'), '/'), quote(User_Agent))
            title = '{0} - {1}'.format(c.get('country'), c.get('channel_name').rstrip('.,-'))
            c_id = c['pk_id']
            title = alfabekodla(title)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', c_id)
            oOutputParameterHandler.addParameter('sMovieTitle', str(title))
            oOutputParameterHandler.addParameter('sThumbnail', image)
            oGui.addMovie(SITE_IDENTIFIER, 'iplay', title, image, image, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def iplay():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    ch_id = oInputParameterHandler.getValue('siteUrl')
    title = oInputParameterHandler.getValue('sMovieTitle')
    key = '98221122'
    r = s.post(list_url, headers={'app-token': '9120163167c05aed85f30bf88495bd89'}, data={'username': '603803577'}, timeout=15)
    ch = r.json()
    for c in ch['msg']['channels']:
        if c['pk_id'] == ch_id:
            selected_channel = c
            break

    image = 'http://tvtap.net/tvtap1/{0}|User-Agent={1}'.format(quote(c.get('img'), '/'), quote(User_Agent))
    with s.cache_disabled():
        r = s.post(token_url, headers={'app-token': '9120163167c05aed85f30bf88495bd89'}, data={'channel_id': ch_id,
         'username': '603803577'}, timeout=15)
    links = []
    for stream in r.json()['msg']['channel'][0].keys():
        if 'stream' in stream or 'chrome_cast' in stream:
            d = des(key)
            link = d.decrypt(b64decode(r.json()['msg']['channel'][0][stream]), padmode=PAD_PKCS5)
            if link:
                link = link.decode('utf-8')
                if not link == 'dummytext' and link not in links:
                    links.append(link)

    if addon.getSetting('autoplay') == 'true':
        link = links[0]
    else:
        dialog = xbmcgui.Dialog()
        ret = dialog.select('Choose Stream', links)
        link = links[ret]
    if link.startswith('http'):
        media_url = '{0}|User-Agent={1}'.format(link, quote(player_user_agent))
    else:
        media_url = link
    title = alfabekodla(title)
    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(title)
    oGuiElement.setMediaUrl(media_url)
    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    oPlayer.startPlayer()