#-*- coding: utf-8 -*-
import urllib2, urllib,cookielib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, zipfile, re, stat, xbmcvfs, base64
from resources.lib.otvhelper import  gegetUrl,getUrl ,alfabekodla
from resources.lib.config import cConfig
import requests
import re,xbmcgui,unicodedata
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress, VSlog
import re 
import urllib, urllib2, re, sys, os
import xbmcplugin, xbmcgui
import urlparse
import codecs
import xbmcaddon
import xbmc
from resources.lib.player import cPlayer
from resources.lib.kplayer  import Player
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.common import addon_id
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
MOVIE_COMMENTS = (True, 'showplayer')
SITE_IDENTIFIER = 'turkvod_org'
import  socket, struct
import urllib
import urllib2
import re
import sys
import os
import cookielib

playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
TURKvod_headers = {'User-Agent': 'Mozilla/5.0 TURKvod-10 Kodi'}
def makemodule(url, sourcestr = '', modname = ''):
    modsource = urllib2.urlopen(urllib2.Request(url, data=None, headers=TURKvod_headers)).read()
    obj = compile(modsource, sourcestr, 'exec')
    module = imp.new_module(modname)
    exec (obj, module.__dict__)
    return module
	
from resources.lib.common import addon as Addon
def OPEN_URL(url):
	

	headers = {}
	headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'
	link = requests.session().get(url, headers=headers, verify=False).text
#	link = link.encode('ascii', 'ignore')
	return link
def version():
                ver='https://dl.dropboxusercontent.com/s/42gqn0eidqo619f/hdd.xml'
                vers=OPEN_URL(ver)
                
#                versi = re.findall('<addon id="plugin.video.turkvod".*?version="(.*?)".*?provider-name="berkenkey">', vers)[0]
#		r = re.search('<?xml version="1.0" encoding="utf-8"?><addons><addon id="plugin.video.turkvod"	   name="turkvod"	   version="(.*?)"(.*?)".*?provider-name="berkenkey">', vers.group(1))
	        url = re.findall('"UTF-8"version="(.*?)".*?"', vers, re.S)
                return url[0]                 
class track():
    def __init__(self, length, title, path, icon,data=''):
        self.length = length
        self.title = title
        self.path = path
        self.icon = icon
        self.data = data
    
def re_me(data, re_patten):
    match = ''
    m = re.search(re_patten, data)
    if m != None:
        match = m.group(1)
    else:
        match = ''
    return match

def getHwAddr(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    info = (s.fileno(), 0x8927,  struct.pack('256s', ifname[:15]))
    return ':'.join(['%02x' % ord(char) for char in info[18:24]])

thisPlugin = int(sys.argv[1])

import pickle
import xml.dom.minidom as mn
from urlparse import parse_qs
import hashlib
from urllib import unquote_plus

         
__settings__ = xbmcaddon.Addon(id='plugin.video.OTV_MEDIA')
__addondir__ = xbmc.translatePath(__settings__.getAddonInfo('profile'))
if not os.path.exists(__addondir__):
    os.mkdir(__addondir__)
cookiepath = os.path.join(__addondir__, 'plugin.video.kino-live.org.lwp')


std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}

def debug(obj, text = ''):
    print datetime.fromtimestamp(time()).strftime('[%H:%M:%S]')
    print '%s' % text + ' %s\n' % obj


def mod_request(url, param = None):
    
    url = 'http://' + url.replace('http://', '').replace(' ', '%20')
    html = ''
    try:
        debug(url, 'MODUL REQUEST URL')
        req = urllib2.Request(url, param, {'User-agent': UA,
         'Connection': 'Close'})
        html = urllib2.urlopen(req).read()
    except Exception as ex:
        print ex
        print 'REQUEST Exception'

    return html
import re
from uuid import getnode


original_mac_address = getnode()


mac= str(":".join(re.findall('..', '%012x' % original_mac_address)))+'_' +version()
addonId = "plugin.video.OTV_MEDIA"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
	
def showplayer():
    
    url = 'plugin://plugin.video.OTV_MEDIA/?mode=199' 
    xbmc.executebuiltin('XBMC.RunPlugin('+url+')')
    xbmc.executebuiltin('Dialog.Close(all, true)')    





import pickle
import xml.dom.minidom as mn
from urlparse import parse_qs
import hashlib
from urllib import unquote_plus

         

#mac =  "plugin.video.turkvod_9.17"	   
	   
addon = xbmcaddon.Addon(id=addonId)
adultPIN = addon.getSetting("adultPIN")       
adultPINonoff = addon.getSetting( "adultPINonoff" )
serverId = addon.getSetting( "serverId" )
listegorunumu = addon.getSetting( "listegorunumu" )

if addon.getSetting('serverId') == "true":
    server = 'me'
else:
    server = 'xyz'
if addon.getSetting('listegorunumu') == "true":
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
else:
    pass
#Host = 'http://mylist.obovse.ru/top?type=list'
                                           
Host = 'https://dl.dropboxusercontent.com/s/2eta4s4d9c99p4k/russlist.txt'
std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}

def construct_request(params):
	return '%s?%s' % (sys.argv[0], urllib.urlencode(params))
		
UA="Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6"
std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}

def construct_request(params):
	return '%s?%s' % (sys.argv[0], urllib.urlencode(params))
		
def _downloadUrl(url):
                url = re.findall("(.*?)&title.*?", url)[0]
		return url
def StartPort(url, mac = None):
    url = url.replace('TURKvodModul@','').replace('@m3u@TURKvod','')
    sign = '?'
    url = url.strip(' \t\n\r')
    if url.find('?') > -1:
        sign = '&'
    if mac != None:
        security_key = ""
        security_param = ""
        url = url + sign + 'box_mac=' + mac + security_key + security_param
    if url.find('|') > -1:
        parts = url.split('|')
        url = parts[0]
        cookie = parts[1]
        req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 TURKvod-10 Kodi',
        'Connection': 'Close',
        'Cookie': cookie})
    else:
        req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 TURKvod-10 Kodi',
        'Connection': 'Close'})
    xmlstream = urllib2.urlopen(req).read()
    return xmlstream
	
def ListeyeEkle(name, parameters={},pic="", description = ""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    li.setInfo(type = 'video', infoLabels={'plot': description})
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)
               
		     
		
yen= "aHR0cHM6Ly9kbC5kcm9wYm94dXNlcmNvbnRlbnQuY29tL3MvNDJncW4wZWlkcW82MTlmL2hkZC54bWw="
yeni =base64.b64decode(yen)
http = yeni+mac				
def terscevir(cba):
        oku = ""
        i = len(cba) - 1
        while i >= 0:
            oku += cba[i]
            i -= 1
        return oku        
def mTUrKVod():
                        
     Host = "http://mylist.obovse.ru/top?type=list"                   
     url = OPEN_URL(Host)
            
    
     name ='test'
     addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')   




	
def mTUrKVod():
    oGui = cGui()
    content =  StartPort(Host, mac)
    start = 0
    i = 0
    while i < 100:
        n1 = content.find("<channel>", start)
        if n1 < 0:
            break
        n2 = content.find("</channel>", start)
        if n2 < 0:
            break
        ch = content[n1:n2]
        regexvideo = '<title>(.*?)</title>.*?description>.*?>(.*?)</description>.*?<playlist_url>(.*?)</playlist_url>'
        match = re.compile(regexvideo,re.DOTALL).findall(ch)
        name = match[0][0]
        name = name.replace("<![CDATA[", "")
        name = name.replace("]]>", "")
        url = match[0][2]
        url = url.replace("<![CDATA[", "")
        url = url.replace("]]>", "")
        pic = ""
        description = match[0][1]
        description = description.replace("]]>", "")
        playlist(url)
        start = n2+5       
        i = i+1
    oGui.setEndOfDirectory()

def TUrKVod():
	oGui = cGui()
        
        start = Host
      
	if Addon.getSetting('mac') != None:
		box_mac = Addon.getSetting('mac')
	else:
		box_mac = None
	try: searchon = params['search']
	except: searchon = None
	try: 
		url=urllib.unquote(params['link'])
		if box_mac != None:
			sign = '?'
			if url.find('?') > -1:	
				sign = '&'
			url = url + sign + 'box_mac=' + box_mac
		else:
			url = url
	except:
		url = start
	xml = OPEN_URL(url)
	print 'HTTP LEN = [%s]' % len(xml)
	if url.find('m3u') > -1:
		m3u(xml)
	else:
			xml = mn.parseString(xml)
	n = 0
	if searchon == None:
		try: search = xml.getElementsByTagName('mmsearchon')[0].firstChild.data
		except: search = None	
	if search != None:
		kbd = xbmc.Keyboard()
		kbd.setDefault('')
		kbd.setHeading('Search')
		kbd.doModal()
		if kbd.isConfirmed():
			sts=kbd.getText();
			sign = '?'
			if url.find('?') > -1:	
				sign = '&'
			sts = sts.replace(' ','%20')
			url2 = url + sign + 'search=' + sts
			print url2
			xml = OPEN_URL(url2)
		else:
			xml = OPEN_URL(url)
		print 'HTTP LEN = [%s]' % len(xml)
		xml = mn.parseString(xml)
		playlist(xml)
	else:
		if url.find('m3u') > -1:
			m3u(xml)
		else:
			playlist(xml)
                oGui.setEndOfDirectory()		
def showGenre2():
	oGui = cGui()                             
        
        oInputParameterHandler = cInputParameterHandler()
        url = oInputParameterHandler.getValue('siteUrl')	
        if url.find('&title') > -1:
            url = _downloadUrl(url)
        start = url 
      
	if Addon.getSetting('mac') != None:
		box_mac = Addon.getSetting('mac')
	else:
		box_mac = None
	try: searchon = params['gsearch']
	except: searchon = None
	try: 
		url=urllib.unquote(params['link'])
		if box_mac != None:
			sign = '?'
			if url.find('?') > -1:	
				sign = '&'
			url = url + sign + 'box_mac=' + box_mac
		else:
			url = url
	except:
		url = start
	xml = OPEN_URL(url)
	print 'HTTP LEN = [%s]' % len(xml)
	if url.find('m3u') > -1:
		m3u(xml)
	else:
			xml = mn.parseString(xml)
	n = 0
	if searchon == None:
		try: search = xml.getElementsByTagName('gsearch_on')[0].firstChild.data
		except: search = None	
	if search != None:
		kbd = xbmc.Keyboard()
		kbd.setDefault('')
		kbd.setHeading('Search')
		kbd.doModal()
		if kbd.isConfirmed():
			sts=kbd.getText();
			sign = '?'
			if url.find('?') > -1:	
				sign = '&'
			sts = sts.replace(' ','%20')
			url2 = url + sign + 'search=' + sts
			print url2
			xml = OPEN_URL(url2)
		else:
			xml = OPEN_URL(url)
		print 'HTTP LEN = [%s]' % len(xml)
		xml = mn.parseString(xml)
		playlist(xml)
	else:
		if url.find('m3u') > -1:
			m3u(xml)
		else:
			playlist(xml)
                oGui.setEndOfDirectory()

	

def mTUrKVod():
		oGui = cGui()
	        xml =  StartPort(Host, mac)
                a = regex_get_all(xml,'<channel>','</channel>')

		
		sTitle = regex_from_to(a,'<title>','</title>').replace('<![cdata[','').replace(']]>','')
		
		
		
		playlist  = regex_from_to(a,'<playlist_url>','</playlist_url>').replace('<![CDATA[','').replace(']]>','')
                stream  = regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
		description = regex_from_to(a,'<description>','</description>').replace('<![CDATA[','').replace(']]>','')
		sPicture = re.findall('img .*?src="(.*?)"', description)
                
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', playlist)
                if playlist== 'http':
                  oGui.addMovie(SITE_IDENTIFIER, 'showGenre2',sTitle, sPicture, sPicture, '', oOutputParameterHandler)
                elif stream == 'http':
                  oGui.addMovie(SITE_IDENTIFIER, 'turkvodstreams',sTitle, sPicture, sPicture, '', oOutputParameterHandler)

                       
                                   
		oGui.setEndOfDirectory()                    
 
		
		
def regex_from_to(text, from_string, to_string, excluding=True):
	import re,string
	if excluding:
		try: r = re.search("(.*?)", text).group(1)
		except: r = ''
	else:
		try: r = re.search("(.*?)", text).group(1)
		except: r = ''
	return r


def regex_get_all(text, start_with, end_with):
	import re,string
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r

headers = {
    'User-Agent': 'Opera/9.80 (X11; Linux i686; U; ru) Presto/2.7.62 Version/11.00',
    'Accept': ' text/html, application/xml, application/xhtml+xml, image/png, image/jpeg, image/gif, image/x-xbitmap, */*',
    'Accept-Language': 'ru-RU,ru;q=0.9,en;q=0.8',
    'Accept-Charset': 'utf-8, utf-16, *;q=0.1',
    'Accept-Encoding': 'identity, *;q=0'
}


def GET(url, referer, post_params=None):
    headers['Referer'] = referer

    if post_params is not None:
        post_params = urllib.urlencode(post_params)
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
    elif headers.has_key('Content-Type'):
        del headers['Content-Type']

    jar = cookielib.LWPCookieJar(cookiepath)
    if os.path.isfile(cookiepath):
        jar.load()

    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(jar))
    urllib2.install_opener(opener)
    req = urllib2.Request(url, post_params, headers)

    response = opener.open(req)
    the_page = response.read()
    response.close()

    jar.save()

    return the_page



      		
         
def playlist(xml):
	n = 0                                                                                                                                                                          
	oGui = cGui()
        
        
        xml = xml
        for prev_page_url in xml.getElementsByTagName('prev_page_url'):
		prev_url = xml.getElementsByTagName('prev_page_url')[0].firstChild.data
		prev_title =  "[COLOR FFFFFF00]<-" + prev_page_url.getAttribute('text').encode('utf-8') +'[/COLOR]'
		prev_url = prev_url.replace('TURKvodModul@','')
                prev_title = alfabekodla(prev_title)
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', prev_url)
                oGui.addDir(SITE_IDENTIFIER, 'showGenre2',prev_title , 'next.png', oOutputParameterHandler)

	        
        for channel in xml.getElementsByTagName('channel'):
		try: title = channel.getElementsByTagName('title')[0].firstChild.data.encode('utf-8')
		except: title = 'No title or error'
		title = title.replace('<b>', '')
		title = title.replace('</b>', '')
		try:
			description = channel.getElementsByTagName('description')[0].firstChild.data.encode('utf-8')
			img_src_list = re.findall('img .*?src="(.*?)"', description)
			if len(img_src_list) > 0:
				img_src = img_src_list[0]
			else:
				img_src_list = re.findall("img .*?src='(.*?)'", description)
				if len(img_src_list) > 0:
					img_src = img_src_list[0]
				else:	
					img_src = 'DefaultVideo.png'
					       
			
                        description = description.replace('<br>', '\n')
			description = description.replace('<br/>', '\n')
			description = description.replace('</h1>', '</h1>\n')
			description = description.replace('</h2>', '</h2>\n')
			description = description.replace('&nbsp;', ' ')
			description4playlist_html = description
			text = re.compile('<[\\/\\!]*?[^<>]*?>')
			description = text.sub('', description)
			plot = description
		except: 
			description = 'No description'
			plot = description
			img_src = 'DefaultVideo.png'
		n = n+1
		try: 
			link = channel.getElementsByTagName('playlist_url')[0].firstChild.data
			link = link.replace('TURKvodModul@','')
                        oOutputParameterHandler = cOutputParameterHandler()
			oOutputParameterHandler.addParameter('siteUrl', link)
			oGui.addMovie(SITE_IDENTIFIER, 'showGenre2', title, img_src, img_src, '', oOutputParameterHandler)

		       
                except: link = None
		try: 
			stream = channel.getElementsByTagName('stream_url')[0].firstChild.data
	
			oOutputParameterHandler = cOutputParameterHandler()
			oOutputParameterHandler.addParameter('sMovieTitle', str(title))
                        oOutputParameterHandler.addParameter('siteUrl', stream)
			oGui.addMovie(SITE_IDENTIFIER, 'howHosters', title, img_src, img_src, '', oOutputParameterHandler)

                except: stream = None	
	for next_page_url in xml.getElementsByTagName('next_page_url'):
		next_url = xml.getElementsByTagName('next_page_url')[0].firstChild.data
		next_title =str(next_page_url)
		next_url = next_url.replace('TURKvodModul@','')
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', next_url)
                oGui.addDir(SITE_IDENTIFIER, 'showGenre2',next_title , 'next.png', oOutputParameterHandler)

	        oGui.setEndOfDirectory()

def nmm3u(xml):
        oGui = cGui()
        m3u = xml
	regex = re.findall('#EXTINF.*,(.*\\s)\\s*(.*)', m3u)
	if not len(regex) > 0:
		regex = re.findall('((.*.+)(.*))', m3u)
	for text in regex:
		title = text[0].strip()
		url = text[1].strip()
		oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('sMovieTitle', str(title))
                oOutputParameterHandler.addParameter('siteUrl', url)
                oGui.addDir(SITE_IDENTIFIER, 'otvplay__',title , 'next.png', oOutputParameterHandler)
        oGui.setEndOfDirectory()


          

def m3u(xml):
        oGui = cGui()
        m3u = xml
        regex = re.findall('#EXTINF.*,(.*\\s)\\s*(.*)', m3u)
	if not len(regex) > 0:
		regex = re.findall('((.*.+)(.*))', m3u)
	for text in regex:
		title = text[0].strip()
		url = text[1].strip()
		if   '#EXTGRP:' in  url:
                     url  = re.findall('#EXTGRP:.*?\n(.*?)\n', m3u)[0]
                
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('sMovieTitle', str(title))
                oOutputParameterHandler.addParameter('siteUrl', url)
                oGui.addDir(SITE_IDENTIFIER, 'otvplay__',title , 'next.png', oOutputParameterHandler)
        oGui.setEndOfDirectory()
           

    


def mmm3u(data):
                        
     Host = "http://mylist.obovse.ru/top?type=list"                   
     url = m3u_to_dict(data)
            
    
     name ='test'
     addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')   


def mbm3u(playlist):
      oGui = cGui()
      for line in playlist:
           if   '#EXTINF:-1 tvg-id=' in  line:
              regex = re.findall('tvg-logo="(.*?)" group-title="(.*?)\n(.*?)\n', line)
              (tump,title,url) = regex[0]
           if   '#EXTINF:-1 group-title=' in  line:
              regex = re.findall('group-title="(.*?)\n(.*?)\n', line)
              (title,url) = regex[0]
           if   '#EXTGRP:' in  line:
              regex = re.findall('tvg-logo="(.*?)".*?vg-name=".*?",(.*?)\n#EXTGRP:.*?\n(.*?)\n', line)
              (tump,title,url) = regex[0]
           else:
              m3u = playlist
              regex = re.findall('#EXTINF.*,(.*\\s)\\s*(.*)', m3u)
              if not len(regex) > 0:
		 regex = re.findall('((.*.+)(.*))', m3u)
              for text in regex:
		title = text[0].strip()
		url = text[1].strip()
        
		oOutputParameterHandler = cOutputParameterHandler()
		oOutputParameterHandler.addParameter('sMovieTitle', str(title))
		oOutputParameterHandler.addParameter('siteUrl', url)
		oGui.addDir(SITE_IDENTIFIER, 'otvplay__',title ,'next.png', oOutputParameterHandler)
      oGui.setEndOfDirectory()



def turkvodstreams():
                    oGui = cGui()
    
                    oInputParameterHandler = cInputParameterHandler()
                    url = oInputParameterHandler.getValue('siteUrl')
                    name = oInputParameterHandler.getValue('sMovieTitle')
                    streamurl =kshowHosters(url)
                    if not streamurl:
                            
                            playTurkvodplayer(name, url)
                    else:
                            playTurkvodplayer(name, url)
                            if url:
                              url = url
                            playTurkvodplayer(name, url)
                            if streamurl:
                              url=[]  
                              title=[]  
                              title=streamurl[2]
                              for o in streamurl[1]:
                                    url.append(str(o))
                              if len(url) == 1:
                                    url = url[0]
                              elif len(url) > 1:
                                    dialog2 = xbmcgui.Dialog()
                                    ret = dialog2.select('Select Quality',title)
                                    if (ret > -1):
                                       url = url[ret]
                                       for name in streamurl[2]:
                                          playTurkvodplayer(name, url)
                                          return False, False

def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    refUrl = oInputParameterHandler.getValue('refUrl')
    sUrl = oInputParameterHandler.getValue('sUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('Referer', refUrl)
    oRequestHandler.request()
    vUrl = oRequestHandler.getRealUrl()

    if vUrl:
        sHosterUrl = vUrl
        oHoster = cHosterGui().checkHoster(sHosterUrl)
        if (oHoster != False):
            oHoster.setDisplayName(sMovieTitle)
            oHoster.setFileName(sMovieTitle)
            cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()


def howHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb= oInputParameterHandler.getValue('sThumb')
    url = oInputParameterHandler.getValue('siteUrl')
    if 'Play m3u8'  in sMovieTitle:
         ottvplay__(url,sMovieTitle)
    
    
    

   
    sHosterUrl = url
 
    #oHoster = __checkHoster(sHosterUrl)
    oHoster = cHosterGui().checkHoster(sHosterUrl)
    if (oHoster != False):
            oHoster.setDisplayName(sMovieTitle)
            oHoster.setFileName(sMovieTitle)
            cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()


def kshowHosters(url):
    oGui = cGui()
    
    sMovieTitle = 'sMovieTitle'
    sThumbnail = 'sThumbnail'
   
    sHosterUrl = url
 
    #oHoster = __checkHoster(sHosterUrl)
    oHoster = cHosterGui().checkHoster(sHosterUrl)

    if (oHoster != False):
        
#        sMovieTitle = cUtil().DecoTitle(sMovieTitle)
        
        
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumbnail)

    oGui.setEndOfDirectory()




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok
def maddLink(name,url,iconimage):
        oGui = cGui()
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        oGui.setEndOfDirectory()
def playTurkvod2(params):
                    name = params['title']
                    url = urllib.unquote(params['stream'])
                    url = str(url).encode('utf-8', 'ignore')
                    try: img = params['img']
                    except: img = 'DefaultVideo.png'
                    playlist=xbmc.PlayList(xbmc.PLAYLIST_VIDEO); 
                    playlist.clear();
                    listitem1 = xbmcgui.ListItem(name)
                    playlist.add(url,listitem1);
                    player_type = sPlayerType()
                    xbmcPlayer = xbmc.Player (player_type); 
                    xbmcPlayer.play (playlist)       

def sPlayerType():
        
       
        oConfig = cConfig()
        sPlayerType = oConfig.getSetting('playerType')
        try:
            if (sPlayerType == '0'):
                cConfig().log("playertype from config: auto")
                return xbmc.PLAYER_CORE_AUTO

            if (sPlayerType == '1'):
                cConfig().log("playertype from config: mplayer")
                return xbmc.PLAYER_CORE_MPLAYER

            if (sPlayerType == '2'):
                cConfig().log("playertype from config: dvdplayer")
                return xbmc.PLAYER_CORE_DVDPLAYER
        except: return False
        
    

def ottv(sUrl):
    
     
     return sUrl
                                                                                            

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok 



def otvplay__():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    iconimage = 'https://upload.wikimedia.org/wikipedia/de/f/f6/Windows_Media_Player_11_Logo.png'
    name =  alfabekodla(sTitle)
    rl =  '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36'




#    sUrl  = ottv(sUrl)
    name =  alfabekodla(sTitle)
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    
    Player().play(sUrl+ '|Referer='+sUrl ,liz)


    

    