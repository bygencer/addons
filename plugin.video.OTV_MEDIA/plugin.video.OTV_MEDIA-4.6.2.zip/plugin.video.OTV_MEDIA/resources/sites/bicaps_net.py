#-*- coding: utf-8 -*-
import urllib2, urllib,cookielib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, zipfile, re, stat, xbmcvfs, base64
from resources.lib.otvhelper import  gegetUrl,getUrl ,alfabekodla
from resources.lib.config import cConfig
import requests
import re,xbmcgui,unicodedata              
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress, VSlog
from resources.lib.player import cPlayer
from resources.lib.kplayer  import Player
from resources.lib.gui.guiElement import cGuiElement


SITE_IDENTIFIER = 'bicaps_net'
SITE_NAME = 'Bicaps.net'
SITE_DESC = 'Films  streaming'

URL_MAIN = 'https://www.fullhdfilmizlesene.net/'







def load():
    oGui = cGui()
 
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://orhantv/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', 'Recherche', 'search.png', oOutputParameterHandler)
   
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_TURK[0])
    oGui.addDir(SITE_IDENTIFIER, MOVIE_TURK[1], 'showGenre', 'news.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_MOVIE[0])
    oGui.addDir(SITE_IDENTIFIER, MOVIE_MOVIE[1], 'Tout les films', 'films.png', oOutputParameterHandler)
   
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_GENRES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showGenre', 'Films par Genres', 'genres.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', SERIE_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, SERIE_NEWS[1], 'Séries nouveaute', 'series.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', SERIE_SERIES[0])
    oGui.addDir(SITE_IDENTIFIER, SERIE_SERIES[1], 'Séries liste complete', 'series.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', ANIM_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, ANIM_NEWS[1], 'Animes Nouveaute', 'series.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', ANIM_ANIMS[0])
    oGui.addDir(SITE_IDENTIFIER, ANIM_ANIMS[1], 'Animes Liste complete', 'series.png', oOutputParameterHandler)
           
    oGui.setEndOfDirectory()
 
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if (sSearchText != False):
        sUrl = 'https://www.fullhdfilmizlesene.net/arama?ara=' + sSearchText
        sUrl= sUrl.replace(' ','+')
        searchowMovies(sUrl)
        oGui.setEndOfDirectory()
        return
        
def AlphaSearch():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    
    dialog = cConfig().createDialog(SITE_NAME)
    
    for i in range(0,27) :
        cConfig().updateDialog(dialog, 36)
        
        if (i > 0):
            sTitle = chr(64+i)
        else:
            sTitle = '09'
            
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl + sTitle.upper() )
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal] Lettre [COLOR red]'+ sTitle +'[/COLOR][/COLOR]', 'genres.png', oOutputParameterHandler)
        
    cConfig().finishDialog(dialog)
    
    oGui.setEndOfDirectory()           
   
def bicaps(): #affiche les genres
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://orhantv/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', 'ARA', 'search.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://www.fullhdfilmizlesene.net/yeni-filmler')
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'YENI FILMLER', 'genres.png', oOutputParameterHandler)
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://www.fullhdfilmizlesene.net/en-cok-begenilen')
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'EN COK BEGENILENLER', 'genres.png', oOutputParameterHandler)
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://www.fullhdfilmizlesene.net/en-cok-izlenen')
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'EN COK IZLENENLER', 'genres.png', oOutputParameterHandler)
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://www.fullhdfilmizlesene.net/')
    oGui.addDir(SITE_IDENTIFIER, 'FilmT', 'Film T\xc3\xbcrleri-Genre', 'genres.png', oOutputParameterHandler)
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://www.fullhdfilmizlesene.net/filmizle/turkce-dublaj-film-izle')
    oGui.addDir(SITE_IDENTIFIER, 'Yillar', 'Yillar', 'genres.png', oOutputParameterHandler)

    sUrl = 'https://www.fullhdfilmizlesene.net/filmizle/turkce-dublaj-film-izle'

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    oParser = cParser()
    sPattern = '<h2>Filtreler</h2></div>(.+?)<div class="clear">'
   
    aResult = oParser.parse(sHtmlContent, sPattern)
    sHtmlContent = aResult
    sPattern = '<li><a href="(.+?)" title="(.+?)">.+?</a></li>'
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            sTitle = alfabekodla(aEntry[1])
           
            Link = aEntry[0]
           
            sTitle  = sTitle  + ' [COLOR skyblue]' + sTitle +'[/COLOR]'
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', Link)
            oGui.addTV(SITE_IDENTIFIER, 'showMovies', sTitle, '', '', '', oOutputParameterHandler)
        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory()    

def FilmT():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request();
    oParser = cParser()               
    sPattern = '<div class="orta-icerik">(.+?) <div class="clear"></div>'
  
    aResult = oParser.parse(sHtmlContent, sPattern)
    sHtmlContent = aResult
    sPattern = '<li><a href="(.+?)" title=".+?" >(.+?)</a></li>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            sTitle = alfabekodla(aEntry[1])
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', str(aEntry[0]))
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', str(sThumbnail))
            oGui.addTV(SITE_IDENTIFIER, 'showMovies',  sTitle, '', sThumbnail, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory()
def Yillar():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request();
    oParser = cParser()
    sPattern = '<ul class="yil">(.+?)<div class="clear">'
   
    aResult = oParser.parse(sHtmlContent, sPattern)
    sHtmlContent = aResult
    sPattern = '<li><a href="(.+?)" title="(.+?)">.+?</a></li>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            sTitle = alfabekodla(aEntry[1])
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', str(aEntry[0]))
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', str(sThumbnail))
            oGui.addTV(SITE_IDENTIFIER, 'showMovies',  sTitle, '', sThumbnail, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory()
def searchowMovies(sUrl):
    oGui = cGui()
   
    data = cRequestHandler(sUrl).request() 
                          
    sHtmlContent = re.findall('<img src="(.*?)" alt="(.*?)" width=".*?" height=".*?" class="afis">.*?<div class="dty">.*?<a href="(.*?)"', data, re.S)
         
    for sPicture,sTitle,sUrl in sHtmlContent:
             
                       
            sTitle = alfabekodla(sTitle)
            
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))            
            oOutputParameterHandler.addParameter('sThumbnail',  sPicture) 
            oGui.addMovie(SITE_IDENTIFIER, 'Hosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
         
    oGui.setEndOfDirectory()   
def showMovies(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'https://www.fullhdfilmizlesene.net/'
        request = urllib2.Request(sUrl,None,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()

        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern = '<img src="(.*?)" alt="(.*?)" width=".*?" height=".*?" class="afis">.*?<div class="dty">.*?<a href="(.*?)"'
 
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
   
        oRequestHandler = cRequestHandler(sUrl)
        sHtmlContent = oRequestHandler.request()

                        
                                                        
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '<img src="(.*?)" alt=".*?" width=".*?" height=".*?" class="afis">.*?<div class="dty">.*?<a href="(.*?)" title="(.*?)" class="title">.*?<span><a href=".*?" title=".*?">.*?</a></span>.*?<span>(.*?)</span>.*?<span>(.*?)</span>'
    
    sHtmlContent = sHtmlContent.replace('\n','')
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()                           
    
    oParser = cParser()                  
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = aEntry[2]+'-'+ aEntry[3]+ '-'+aEntry[4]
            sPicture = str(aEntry[0])
            if not 'http' in sPicture:
                sPicture = str(URL_MAIN) + sPicture
                
            sUrl = str(aEntry[1])
            if not 'http' in sUrl:
                sUrl = str(URL_MAIN) + sUrl
           
            #not found better way
            sTitle = alfabekodla(sTitle)
            #sTitle = sTitle.encode('ascii', 'ignore').decode('ascii')
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture) #sortis du poster
 
            if 'Dublaj / Altyaz' in aEntry[3]:
                oGui.addTV(SITE_IDENTIFIER, 'dHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'Hosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = __checkForNextPage(sHtmlContent)#cherche la page suivante
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next_Page >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()
 
def __checkForNextPage(sHtmlContent):
    sPattern = "<li class='secili'><a href='javascript:void.+?'>+?<a href='(.+?)'"
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        sUrl = aResult[1][0]
        return sUrl

    return False

					
def mHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    name= oInputParameterHandler.getValue('sMovieTitle')
    sUrl = oInputParameterHandler.getValue('siteUrl')
    data = cRequestHandler(sUrl).request() 
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,data,'')          
def aaddLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")                                                                  	

        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok  
def dHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request();
    oParser = cParser()
    sPattern = '<script>(.+?)<noscript><link'
   
    aResult = oParser.parse(sHtmlContent, sPattern)
    sHtmlContent = aResult
    sPattern = '"vidid":"(.*?)","name":"(.*?)","nameTxt":"(.*?)"'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            
            
            Title = alfabekodla(aEntry[1])
            sTitle = alfabekodla(aEntry[2])
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', str(aEntry[0]))
            oOutputParameterHandler.addParameter('sMovieTitle', str(Title))
            oOutputParameterHandler.addParameter('sThumbnail', str(sThumbnail))
            oGui.addTV(SITE_IDENTIFIER, 'ddstreams',  sTitle, '', sThumbnail, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory()
def ddstreams():
    oGui = cGui()                           
    oInputParameterHandler = cInputParameterHandler()
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    name = oInputParameterHandler.getValue('sMovieTitle')
    url = oInputParameterHandler.getValue('siteUrl')
    liste = []
    liste.append( ['TR Dublaj','tr'] ) 
    liste.append( ['Altyazi','en'] ) 

    for Title,sUrl2 in liste:
        
         urlm= 'https://www.fullhdfilmizlesene.net/player/api.php?id=%s&type=t&name=%s&get=video&pno=%s&format=json&ssl=true'%(url,name,sUrl2)
#        link =  cRequestHandler(urlm).request() 
#        link= link.replace('\\','')
#        urlll =re.findall('<ifram.+?[SRC|src]=["|\'](.*?)["|\']',link,re.DOTALL)[0]
         sTitle=name+'-'+ Title
	 oOutputParameterHandler = cOutputParameterHandler()
         oOutputParameterHandler.addParameter('siteUrl', urlm)
         oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
         oOutputParameterHandler.addParameter('sThumbnail', str(sThumbnail))
	 oGui.addDir(SITE_IDENTIFIER, 'lmstreams',  sTitle, 'genres.png', oOutputParameterHandler)
                   
                    
    oGui.setEndOfDirectory()  

def Hosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request();
    oParser = cParser()
    sPattern = '<script>(.+?)<noscript><link'
   
    aResult = oParser.parse(sHtmlContent, sPattern)
    sHtmlContent = aResult
    sPattern = '"vidid":"(.*?)","name":"(.*?)","nameTxt":"(.*?)"'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
	    Title = alfabekodla(aEntry[1])
            sTitle = alfabekodla(aEntry[2])   
	               
            urlm= 'https://www.fullhdfilmizlesene.net/player/api.php?id=%s&type=t&name=%s&get=video&format=json&ssl=true'%(str(aEntry[0]),Title)
	    oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', urlm)
            oOutputParameterHandler.addParameter('sitUrl', str(aEntry[0]))
	    oOutputParameterHandler.addParameter('sMovieTitle', str(Title))
            oOutputParameterHandler.addParameter('MovieTitle', str(sTitle))
	    oOutputParameterHandler.addParameter('sThumbnail', str(sThumbnail))
            if sTitle=='Vertex':
                oGui.addDir(SITE_IDENTIFIER, 'partstreams',  sTitle, 'genres.png', oOutputParameterHandler)
            elif sTitle=='Venus':
                oGui.addDir(SITE_IDENTIFIER, 'partstreams',  sTitle, 'genres.png', oOutputParameterHandler)

            else:
                oGui.addDir(SITE_IDENTIFIER, 'lmstreams',  sTitle, 'genres.png', oOutputParameterHandler)
 

    
        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory()
def partstreams():
    oGui = cGui()                           
    oInputParameterHandler = cInputParameterHandler()
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    name = oInputParameterHandler.getValue('sMovieTitle')
    url = oInputParameterHandler.getValue('sitUrl')
    eTitle = oInputParameterHandler.getValue('MovieTitle')
    liste = []
    liste.append( ['part 1','1'] ) 
    liste.append( ['part 2','2'] ) 
    liste.append( ['part 3','3'] ) 
    for Title,sUrl2 in liste:
        
         urlm= 'https://www.fullhdfilmizlesene.net/player/api.php?id=%s&type=p&name=%s&get=video&pno=%s&format=json&ssl=true'%(url,name,sUrl2)
#        link =  cRequestHandler(urlm).request() 
#        link= link.replace('\\','')
#        urlll =re.findall('<ifram.+?[SRC|src]=["|\'](.*?)["|\']',link,re.DOTALL)[0]
         sTitle=eTitle+'-'+ Title
	 oOutputParameterHandler = cOutputParameterHandler()
         oOutputParameterHandler.addParameter('siteUrl', urlm)
         oOutputParameterHandler.addParameter('MovieTitle', str(sTitle))
         oOutputParameterHandler.addParameter('sThumbnail', str(sThumbnail))
	 oGui.addDir(SITE_IDENTIFIER, 'lmstreams',  sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory()
def lmstreams():
        oGui = cGui()
        
        oInputParameterHandler = cInputParameterHandler()
        url = oInputParameterHandler.getValue('siteUrl')
#    Title = oInputParameterHandler.getValue('sMovieTitle')
        sThumb = oInputParameterHandler.getValue('sThumbnail')
        Title = oInputParameterHandler.getValue('MovieTitle')
        data = cRequestHandler(url).request()
   
        data= data.replace('\\','')
        link = re.findall('src=["\'](.*?)["\']', data)[0]
        if  '/player/okru/' in link:
            link= link.replace('https://www.fullhdfilmizlesene.net/player/okru/plysv2.php?id=','').replace('&','?')
	    link ='https://ok.ru/videoembed/'+ link
        if  'turkakisi.com/movie' in link:
            line =  cRequestHandler(link).request() 
            line= line.replace('\/\/cdn0','https://cdn0').replace('\/','/')
            urll =re.findall('"hls":"(.*?)"',line,re.DOTALL)[0]
            playOTV2(urll,Title,sThumb)
        if  'cdn.docbag.org' in link:
            line =  cRequestHandler(link).request()                         
	   
            urll =re.findall('"file":"(.*?)","ql":"1080p"',line,re.DOTALL)[0]+'|Accept-Encoding=identity;q=1, *;q=0&User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'
            playOTV2(urll,Title,sThumb)
            return
        if  'gov2a.php' in link:
	    #from adult_eu import *    
            urla= "https://www.fullhdfilmizlesene.net/"
            referer=[('Referer',urla)]                                      
            lin=gegetUrl(link,headers=referer)       
	    
            link2 = re.findall('skin:[\s\S]*?(eval[\s\S]*?}\)\));', lin)[0]
            lin1 =  cPacker().unpack(link2)
            lin1 = lin1.replace("\\'","'")
            lin2 =  cPacker().unpack(lin1)
            lin2 = lin2.replace("\\","").replace("x","")
            urll = re.findall('"file":"(.*?)"', lin2)[0].decode('hex')
            playOTV2(urll,Title,sThumb)
            return
        if  'awsbeta17.php' in link:
	    #from adult_eu import *    
            lin2= link
	    TIK='|User-Agent=Mozilla/5.0 (Windows NT 10.0; rv:67.0) Gecko/20100101 Firefox/67.0'
            
            urll =re.findall('https://.*?&f=(.*?)&ip=.*?', lin2)[0]+ TIK
            if 'BluRay' in urll:
	        urll = 'http://secourgeon.cf'+ urll
            else:
	        urll = 'http://fillingham.ga'+ urll
            playOTV2(urll,Title,sThumb)
            return
        sstreams(link)
	return

	
def aaddLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")                                                                  	

        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok  
def sstreams(urlll):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    sHosterUrl= urlll
            
    oHoster = cHosterGui().checkHoster(sHosterUrl)

    if (oHoster != False):
          sMovieTitle = cUtil().DecoTitle(sMovieTitle)
          cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumbnail)
    oGui.setEndOfDirectory()

def streams():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumbnail')
    urlm= 'https://www.fullhdfilmizlesene.net/player/api.php?id=%s&type=t&name=%s&get=video&format=json&callback=jQuery111203512659266764322_1561399057691&_=1561399057695'%(url,sMovieTitle)
    
    link =  cRequestHandler(urlm).request() 
    link= link.replace('\\','')
    sHosterUrl =re.findall('<ifram.+?[SRC|src]=["|\'](.*?)["|\']',link,re.DOTALL)[0]
            
    oHoster = cHosterGui().checkHoster(sHosterUrl)

    if (oHoster != False):
        oHoster.setDisplayName(sMovieTitle)
        oHoster.setFileName(sMovieTitle)
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()