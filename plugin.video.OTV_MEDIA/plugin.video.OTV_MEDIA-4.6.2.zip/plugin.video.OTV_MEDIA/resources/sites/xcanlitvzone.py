#-*- coding: utf-8 -*-
import urllib2, urllib,cookielib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, zipfile, re, stat, xbmcvfs, base64
from resources.lib.otvhelper import  gegetUrl,getUrl ,alfabekodla
from resources.lib.config import cConfig
import requests
import re,xbmcgui,unicodedata
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress, VSlog
import re 
from resources.lib.gui.guiElement import cGuiElement                   
from resources.lib.player import cPlayer
from resources.lib.kplayer  import Player
SITE_IDENTIFIER = 'xcanlitvzone'
SITE_NAME = 'Canlitvzone'
MOVIE_VIEWS = (True, 'Canlitvzone')



def Canlitvzone():
    oGui = cGui()
   
  
    
    sUrl ='http://canlitv.me/?sayfa=1'
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
    sPattern = '<li class="canlitvlist"><a href="(.*?)" title="(.*?)">.*?<img src="(.*?)"'
            
                                                     
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #prisNextPagent aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = aEntry[1]
            sPicture = aEntry[2]
            if not 'http' in sPicture:
                sPicture = str(urlkkmm) + sPicture   
            sUrl = str(aEntry[0])
            if not 'http' in sUrl:
                sUrl = str(urlkkmm) + sUrl
           
            sTitle = alfabekodla(sTitle)
            
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture) #sortis du poster
            oGui.addMovie(SITE_IDENTIFIER, 'sshowBox19', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
        sNextPage="http://canlitv.me/?sayfa=2"
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sNextPage)
        oGui.addDir(SITE_IDENTIFIER, 'Canlitvzone3', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
  
    oGui.setEndOfDirectory()


def Canlitvzone3():
    oGui = cGui()
   
  
    
    oInputParameterHandler = cInputParameterHandler()
    Url = oInputParameterHandler.getValue('siteUrl')
    
    oRequestHandler = cRequestHandler(Url)
    sHtmlContent = oRequestHandler.request()
    
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
    sPattern = '<li class="canlitvlist"><a href="(.*?)" title="(.*?)">.*?<img src="(.*?)"'
            
                                                     
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #prisNextPagent aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = aEntry[1]
            sPicture = aEntry[2]
            if not 'http' in sPicture:
                sPicture = str(urlkkmm) + sPicture   
            sUrl = str(aEntry[0])
            if not 'http' in sUrl:
                sUrl = str(urlkkmm) + sUrl
           
            sTitle = alfabekodla(sTitle)
            
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture) #sortis du poster
            oGui.addMovie(SITE_IDENTIFIER, 'sshowBox19', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
                      
    oGui.setEndOfDirectory()
from resources.lib.aadecode import AADecoder
def CheckAADecoder(str):
    aResult = re.search('<script>(.+?\(\'_\'\);)</script>', str, re.DOTALL | re.UNICODE)
    if (aResult):
        print('AA encryption')
        tmp = AADecoder(aResult.group(1)).decode()
        return str[:aResult.start()] + tmp + str[aResult.end():]

    return str

def sshowBox19():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    Url = oInputParameterHandler.getValue('siteUrl')
    name = oInputParameterHandler.getValue('sMovieTitle')
    sPicture = oInputParameterHandler.getValue('sThumbnail')
    name = alfabekodla(name)
                       
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36 OPR/41.0.2353.69', 'Referer': 'https://www.canlitv.zone/' , 'Connection': 'keep-alive', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
    data = requests.get(Url, headers = headers).text

       
    
    sUrl = re.findall('<iframe width="100%" height="100%" src="(.*?)"',data, re.S)[0]                 
#    sUrl = 'https://www.canlitv.me/yayin.php?kanal=show-tv-kesintisiz-izle&security=73ed196669f8431dccfac0a360c92a00'
#    header = {'Referer':Url,'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36 OPR/41.0.2353.69', 'Connection': 'keep-alive', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
    oRequest = cRequestHandler(Url)
    oRequest.addHeaderEntry('Referer', Url)
    oRequest.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36')
    oRequest.addHeaderEntry('Accept-Language', 'en-US,en;q=0.9,de;q=0.8')
#            oRequest.addHeaderEntry('Host', 'www.hdfilme.net')
#            oRequest.addHeaderEntry('Connection', 'keep-alive')
#            oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
#            oRequest.addHeaderEntry('Connection', 'keep-alive')
    sHtmlContent = oRequest.request()
    if not 'ﾟωﾟ' in  sHtmlContent:
      url= re.findall("file: '(.*?)'",sHtmlContent, re.S)[0]  
                       
    oParser = cParser()    
    sPattern =  '(?:[>;]\s*)(ﾟωﾟ.+?\(\'_\'\);)'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        for i in aResult[1]:
           sou = AADecoder(i).decode()
           ucu=  re.findall(".*?= '(.*?)';.*?= '(.*?)';",sou, re.S)
           (bir,uc)=ucu[0]
           iki = re.findall("file: ''.*?'(.*?)'.*?'',",sHtmlContent, re.S)[0]
           url= bir+iki+uc +'|User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Mobile Safari/537.36'

    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')     
 

      
def msshowBox19():
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36 OPR/41.0.2353.69', 'Referer': Url , 'Connection': 'keep-alive', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
    source = requests.get(sUrl, headers = headers).text
    
    rUrl = re.findall("file: '(.*?)'",source, re.S)[0]
#    sPicture ="https://www.canlitv.zone/logo/tivibu-spor_9147556.png"
    Header = '|User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Mobile Safari/537.36'
    url= rUrl + Header
     
    from resources.lib.hlsplayer import hlsproxy
    progress = xbmcgui.DialogProgress()
    import checkbad
    checkbad.do_block_check(False)
    stopPlaying=threading.Event()
    _bitrate =0
    f4m_proxy=hlsproxy()
    stopPlaying.clear()
    runningthread=thread.start_new_thread(f4m_proxy.start,(stopPlaying,))
    progress.create('Starting HLS Player')
    streamtype='HLSRETRY'                                                                   
    progress.update( 20, "", 'Loading local proxy', "" )
    url_to_play=f4m_proxy.prepare_url(url,proxy,use_proxy_for_chunks,maxbitrate=maxbitrate,simpleDownloader=simpleDownloader,auth=auth,streamtype=streamtype,swf=swf ,callbackpath=callbackpath,callbackparam=callbackparam)
    listitem = xbmcgui.ListItem(name,path=url_to_play, iconImage=iconImage, thumbnailImage=iconImage)
    listitem.setInfo('video', {'Title': name})
    if setResolved:
        return url_to_play, listitem
    mplayer = MyPlayer()    
    mplayer.stopPlaying = stopPlaying
    progress.close() 
    mplayer.play(url_to_play,listitem)

    firstTime=True
    played=False
    while True:
       if stopPlaying.isSet():
           break;
       if xbmc.Player().isPlaying():
           played=True
       xbmc.log('Sleeping...')
       xbmc.sleep(200)
                #if firstTime:
                #    xbmc.executebuiltin('Dialog.Close(all,True)')
                #    firstTime=False
            #stopPlaying.isSet()

    print 'Job done'
    return played
class MyPlayer (xbmc.Player):
    def __init__ (self):
        xbmc.Player.__init__(self)

    def play(self, url, listitem):
        print 'Now im playing... %s' % url
        self.stopPlaying.clear()
        xbmc.Player( ).play(url, listitem)
        
    def onPlayBackEnded( self ):
        # Will be called when xbmc stops playing a file
        print "seting event in onPlayBackEnded " 
        self.stopPlaying.set();
        print "stop Event is SET" 
    def onPlayBackStopped( self ):
        # Will be called when user stops xbmc playing a file
        print "seting event in onPlayBackStopped " 
        self.stopPlaying.set();
        print "stop Event is SET" 



def _m3u8Exit(self):
     import otv_kuresel
     otv_kuresel.yt_tmp_storage_dirty = True    

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok
				