#-*- coding: utf-8 -*-
import urllib2, urllib,cookielib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, zipfile, re, stat, xbmcvfs, base64
from resources.lib.otvhelper import  gegetUrl,getUrl ,alfabekodla
from resources.lib.config import cConfig
import requests
import re,xbmcgui,unicodedata              
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress, VSlog
from resources.lib.player import cPlayer
from resources.lib.kplayer  import Player
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.common import addon
from resources.lib.gui.guiElement import cGuiElement
from liveonlinetv247 import adultHosters                  

from t0mm0.common.net import Net
from base64 import b64encode, b64decode

from urlparse import urlparse
from LINETV import AdultLIVETV
SITE_IDENTIFIER = 'adult_eu'
SITE_NAME = 'ADULT'
ADULT_ADULT = (True, 'pincode')
phAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"

def append_headers(headers):
    return '|%s' % '&'.join(['%s=%s' % (key, urllib.quote_plus(headers[key])) for key in headers])
from resources.lib.common import addon

net = Net()
def pincode():
    oGui = cGui()
    pincode = oGui.pinKeyBoard()
    if addon.getSetting( "adultPIN" ) in pincode:  
            showGenre()
#http://live.redtraffic.xyz/pornstar.m3u8
#http://live.redtraffic.xyz/fetish.m3u8
#http://live.redtraffic.xyz/bigass.m3u8
#http://live.redtraffic.xyz/latina.m3u8
#http://live.redtraffic.xyz/pov.m3u8
#http://live.redtraffic.xyz/hardcore.m3u8
#http://live.redtraffic.xyz/cuckold.m3u8
#http://live.redtraffic.xyz/lesbian.m3u8
#http://live.redtraffic.xyz/teen.m3u8
def buyuktext(text):
    text = text.replace('ç','Ç').replace('i','İ').replace('ı','I').replace('ğ','Ğ').replace('ö','Ö').replace('ş','Ş').replace('ü','Ü')	
    text =text.upper()
    return text


class track():
    def __init__(self,page,data=''):
        self.page=page
        self.page =0
        self.page += 1
        self.data=data

def get_media_url(url, result_blacklist=None, patterns=None, generic_patterns=True):
    if patterns is None: patterns = []
    scheme = urlparse(url).scheme
    if result_blacklist is None:
        result_blacklist = []
    elif isinstance(result_blacklist, str):
        result_blacklist = [result_blacklist]

    result_blacklist = list(set(result_blacklist + ['.smil']))  # smil(not playable) contains potential sources, only blacklist when called from here
    net = common.Net()
    headers = {'User-Agent': common.RAND_UA}

    response = net.http_GET(url, headers=headers)
    response_headers = response.get_headers(as_dict=True)
    headers.update({'Referer': url})
    cookie = response_headers.get('Set-Cookie', None)
    if cookie:
        headers.update({'Cookie': cookie})
    html = response.content

    source_list = scrape_sources(html, result_blacklist, scheme, patterns, generic_patterns)
    source = pick_source(source_list)
    return source + append_headers(headers)

def get_HTML(url, post = None, ref = None):
    html = ''

    if ref == None:
        ref = 'https://adult-channels.com/dusk-tv-online/'

    request = urllib2.Request(urllib.unquote(url), post)

    request.add_header('User-Agent', 'Mozilla/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
    request.add_header('Host', (url))
    request.add_header('Accept', '*/*')
    request.add_header('Accept-Language', 'de-DE,de;q=0.8,en-US;q=0.6,en;q=0.4')
    request.add_header('Referer', ref)
    #request.add_header('Cookie', 'MG_6532=1')

    ret = 502
    idx = 5

    while ret == 502 and idx > 0:
        try:
            f = urllib2.urlopen(request)
            ret = 0
        except IOError, e:
            if hasattr(e, 'reason'):
                xbmc.log('We failed to reach a server. Reason: '+ str(e.reason))
            elif hasattr(e, 'code'):
                xbmc.log('The server couldn\'t fulfill the request. Error code: '+ str(e.code))
                ret = e.code

        if ret == 502:
            time.sleep(1)
        idx = idx -1

    if ret == 0:
        html = f.read()
        f.close()

    return html
def getPage(url, cookieJar=None,post=None, timeout=20, headers=None):

    cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)
    opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
    #opener = urllib2.install_opener(opener)
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36')
    if headers:
        for h,hv in headers:
            req.add_header(h,hv)

    response = opener.open(req,post,timeout=timeout)
    link=response.read()
    response.close()
    return link;


def load():
    linktv = cConfig().getSetting('pvr-view')
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom')
    oGui.addDir(SITE_IDENTIFIER, 'load', '[COLOR khaki]Pour Modifier ou  Ajouter des chaînes à FramaPad https://annuel.framapad.org/p/vstream [/COLOR]', 'tv.png', oOutputParameterHandler)

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', URL_FREE)
    oGui.addDir(SITE_IDENTIFIER, 'showWeb', 'FramaPad (Bêta)', 'tv.png', oOutputParameterHandler)

    # oOutputParameterHandler = cOutputParameterHandler()
    # oOutputParameterHandler.addParameter('siteUrl', URL_SFR)
    # oGui.addDir(SITE_IDENTIFIER, 'showWeb', 'Sfr TV', 'tv.png', oOutputParameterHandler)

    # oOutputParameterHandler = cOutputParameterHandler()
    # oOutputParameterHandler.addParameter('siteUrl', URL_ORANGE)
    # oGui.addDir(SITE_IDENTIFIER, 'showWeb', 'Orange TV', 'tv.png', oOutputParameterHandler)
    
    # oOutputParameterHandler = cOutputParameterHandler()
    # oOutputParameterHandler.addParameter('siteUrl', URL_BG)
    # oGui.addDir(SITE_IDENTIFIER, 'showWeb', 'Bouygues TV', 'tv.png', oOutputParameterHandler)

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', URL_WEB)
    oGui.addDir(SITE_IDENTIFIER, 'showWeb', 'Tv du web', 'tv.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom')
    oGui.addDir(SITE_IDENTIFIER, 'load', '[COLOR khaki]Tu veux voir ta chaîne sur Libretv.me alors partage ta chaîne![/COLOR]', 'libretv.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', URL_LIBRETV)
    oGui.addDir(SITE_IDENTIFIER, 'showLibreMenu', 'Libretv.me', 'libretv.png', oOutputParameterHandler)


    oGui.setEndOfDirectory()

 
def showSearch():
    oGui = cGui()

    sSearchText = oGui.showKeyBoard()
    if (sSearchText != False):
        #sSearchText = cUtil().urlEncode(sSearchText)
        sUrl = URL_SEARCH[0] + sSearchText+'/'
 
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return  

def showGenre():
    oGui = cGui()         
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://live.redtraffic.xyz/all.m3u')
    oGui.addDir(SITE_IDENTIFIER, 'AdultLIVETV','LiveTV', 'genres.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl','http://topplay.do.am/AdultsTopPlay.m3u')
    oGui.addDir(SITE_IDENTIFIER, 'liveGenre', 'LiveTV2', 'genres.png', oOutputParameterHandler)
    

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://live.redtraffic.xyz/all.m3u')
    oGui.addDir(SITE_IDENTIFIER, 'liveGenre', 'LiveTV3', 'genres.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://topplay.do.am/AdultsTopPlay.m3u')
    oGui.addDir(SITE_IDENTIFIER, 'adulttvlive','LiveTV4', 'genres.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', "http://hdporn.net/channels/")
    oGui.addDir(SITE_IDENTIFIER, 'showContentB1', 'VIDEOS', 'genres.png', oOutputParameterHandler)

    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', "http://hdporn.net/channels/")
    oGui.addDir(SITE_IDENTIFIER, 'GetPlayList', 'DBRAZZERS videos', 'genres.png', oOutputParameterHandler)

    
                       
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', "http://hdporn.net/channels/")
    oGui.addDir(SITE_IDENTIFIER, 'hdpornGenre', 'HDPorn', 'genres.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl',"http://www.redtube.com/categories")
    oGui.addDir(SITE_IDENTIFIER, 'redtubeGenre', 'RedTube', 'genres.png', oOutputParameterHandler)

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl',"http://www.pornhd.com/category")
    oGui.addDir(SITE_IDENTIFIER, 'pornhdGenre','PornHD', 'genres.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', "https://www.pornhub.com/categories")
    oGui.addDir(SITE_IDENTIFIER, 'pornhubGenre','PornHub', 'genres.png', oOutputParameterHandler)

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', "https://www.eporner.com/categories/")
    oGui.addDir(SITE_IDENTIFIER, 'epornhubGenre','Eporner', 'genres.png', oOutputParameterHandler)
                   
                    
    oGui.setEndOfDirectory()

def liveGenre():

    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl= oInputParameterHandler.getValue('siteUrl')
    
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36'}
    url= requests.get(sUrl, headers = headers).text
    url=url.replace('#extinf',"#EXTINF")
#    name = 'flashx.tv'
#    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')
#def lsmhowWeb():
#    oGui = cGui()
#    if data:
#        channels = re.findall('#EXTINF:-1 tvg-id="" tvg-name="(.*?)" tvg-logo="" group-title=".*?\n(.*?)\n', data, re.S)           
#    else:
    channels = re.findall('#EXTINF:(.*?)\n(.*?)\n', url, re.S)          
    for title, path in channels:                            
                                  
              sTitle =alfabekodla(title)[2:] 
              oOutputParameterHandler = cOutputParameterHandler()
              oOutputParameterHandler.addParameter('siteUrl', path)
              oOutputParameterHandler.addParameter('sMovieTitle',title)
              oGui.addDir(SITE_IDENTIFIER, 'liveplaylive', sTitle, 'genres.png', oOutputParameterHandler)
        
    oGui.setEndOfDirectory()

   
                                                                                                         	
                       
						
							              
  
def liveplaylive():
    oInputParameterHandler = cInputParameterHandler()
    name = oInputParameterHandler.getValue('sMovieTitle')[2:]                            
    Url = oInputParameterHandler.getValue('siteUrl')                                     
    TIK='|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'

    url=  Url+TIK 
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]' + name, url, '')
                                                                                        

def getUrl(url):
        pass#print "Here in getUrl url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; rv:67.0) Gecko/20100101 Firefox/67.0')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
	
def ultHosters():
        names = []
        urls = []
        names.append("Tivu Stream XXX")
        urls.append("https://patbuweb.com/iptv/e2liste/userbouquet.tivustream_adultxxx.tv") 
        i = 0
        for name in names:
                url = urls[i]
                pic = " "
                i = i+1
                addDirectoryItem(name, {"name":name, "url":url, "mode":"1"}, pic)
        xbmcplugin.endOfDirectory(hos)


def showContentB1(): 
                oGui = cGui()  
                Host="https://patbuweb.com/iptv/e2liste/userbouquet.tivustream_adultxxx.tv"
                content =cRequestHandler(Host).request() 
                        
                pass#print "content A =", content
                regexcat = '#DESCRIPTION ---(.*?)---'
                match = re.compile(regexcat,re.DOTALL).findall(content)
                pass#print "match A=", match
                i = 0
                for sTitle in match:
                        
                        if i < 3:
                              i = i+1
                              continue
                        i = i+1 
                        # if (not "ADULTI" in name) and (not "VINTAGE ITALIANO Film Completi" in name):
                              # continue     
                        url1 = Host
                        sPicture= " "
                        oOutputParameterHandler = cOutputParameterHandler()
                        oOutputParameterHandler.addParameter('siteUrl',  url1)
                        oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
                        oOutputParameterHandler.addParameter('sThumbnail', sPicture) #sortis du poster
 
                        oGui.addMovie(SITE_IDENTIFIER, 'showContentB2',sTitle, sPicture, sPicture, '', oOutputParameterHandler)

                oGui.setEndOfDirectory()

def showContentB2():
	oGui = cGui()
	oInputParameterHandler = cInputParameterHandler()
	url = oInputParameterHandler.getValue('siteUrl')
	name = oInputParameterHandler.getValue('sMovieTitle')
	content = cRequestHandler(url).request() 
	pass#print "content B =", content
	name = name.replace("+", " ")
	name = name.replace("%20", " ")
	pass#print "name B =", name
	n1 = content.find(name, 0)
	n2 = content.find("---", (n1+100))
	if n2 > -1:
                 content2 = content[n1:n2]
        else:          
                 content2 = content[n1:]
        pass#print "content2 =", content2         
	regexvideo = '#SERVICE 4097\:.*?\:.*?\:.*?\:.*?\:.*?\:.*?\:.*?\:.*?\:.*?\:(.*?)\:(.*?)#'
	match = re.compile(regexvideo,re.DOTALL).findall(content2)
        pass#print "match B=", match
        for url, name in match:
                 pic = " "
                 name = name[:-1]
                 name = name.replace('"', '')
                 name = name.replace('\n', '')
                 url = url.replace("%3a", ":")
                 Title = name
                 url1 = url
                 sPicture= " "
                 oOutputParameterHandler = cOutputParameterHandler()
                 oOutputParameterHandler.addParameter('siteUrl',  url1)
                 oOutputParameterHandler.addParameter('sMovieTitle', str(Title))
                 oOutputParameterHandler.addParameter('sThumbnail', sPicture) #sortis du poster
 
                 oGui.addMovie(SITE_IDENTIFIER, 'dizizleABC',Title, sPicture, sPicture, '', oOutputParameterHandler)

	oGui.setEndOfDirectory()


                
def playVideo(name, url):
                 
                 pass#print "In playVideo url =", url
                 player = xbmc.Player()
                 player.play(url)
                 

std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}  

def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)





def adulttvlive():
    oGui = cGui()
   
  
        #oInputParameterHandler = cInputParameterHandler()
        #sUrl = oInputParameterHandler.getValue('siteUrl')
    sUrl ='http://www.adulttvlive.net/channels/'
    url =cRequestHandler(sUrl).request() 
    url = url.replace('&nbsp;','')
 
       
    sPattern = '<tr><td valign="top"></td><td><a href="(.*?php)">(.*?).php</a> '
     
               
                                                                                
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(url, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sPicture ="https://tvshqip.tv/tv/wp-content/uploads/2016/05/logo.png"
                          
            sUrl = str(aEntry[0])
            if not 'http' in sUrl:
               sUrl ='http://www.adulttvlive.net/channels/'+ sUrl
            
            sTitle = alfabekodla(str(aEntry[1]))         
            sTitle =buyuktext(sTitle)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture) #sortis du poster
 
            oGui.addMovie(SITE_IDENTIFIER, 'play__adulttvlive', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        
    oGui.setEndOfDirectory()
def play__adulttvlive():
    oGui = cGui()
    UA='Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
   
    oInputParameterHandler = cInputParameterHandler()
    Url = oInputParameterHandler.getValue('siteUrl')
    referer = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    
    sTitle = alfabekodla(sTitle)                            
  
      
    TIK='|Referer='+referer+'&User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'

    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36','Host': 'www.adulttvlive.net','Referer': referer  }
    data= requests.get(Url, headers = headers).text
    if  'Clappr.Player' in data:        
        sHosterUrl = re.findall('source:"(.*?)"', data)[0]+TIK
    else:
        sHosterUrl = re.findall('file:"(.*?)"', data)[0]+TIK
        sHosterUrl =sHosterUrl.replace('playlist.m3u8','chunks.m3u8')             
        sPicture ="https://tvshqip.tv/tv/wp-content/uploads/2016/05/logo.png"
        sTitle = alfabekodla(sTitle)
        oGuiElement = cGuiElement()
        oGuiElement.setSiteName(SITE_IDENTIFIER)
        oGuiElement.setTitle(sTitle)
        oGuiElement.setMediaUrl(sHosterUrl)
        oPlayer = cPlayer()
        oPlayer.clearPlayList()
        oPlayer.addItemToPlaylist(oGuiElement)
        oPlayer.startPlayer()      
         
def LiveTV():
    oGui = cGui()
   

        #oInputParameterHandler = cInputParameterHandler()
        #sUrl = oInputParameterHandler.getValue('siteUrl')
    sUrl ='http://oklivetv.com/genre/adult-18/?orderby=likes'
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36 OPR/41.0.2353.69', 'Referer': 'http://miplayer.net/embed.php?id=ligtv1&width=650&height=480&autoplay=true', 'Connection': 'keep-alive', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
    url = requests.get(sUrl, headers = headers).text
#    url = unicode(url, 'latin-1')#converti en unicode
    url= unicodedata.normalize('NFD', url).encode('ascii', 'ignore')#vire accent
    url = url.encode( "utf-8")
    url = urllib.unquote_plus(url) 
    url = url.replace('�','')
 
       
    sPattern = '<div class="thumb">.*?<a class="clip-link" data-id=".*?" title="(.*?)" href="(.*?)">.*?<img src="(.*?)"'
     
   
                                                                                
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(url, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
           
            sPicture = str(aEntry[2])
                            
            sUrl = str(aEntry[1])
            if not 'http' in sUrl:
               sUrl ='http:'+ sUrl
            sTitle = alfabekodla(str(aEntry[0]))         
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture) #sortis du poster
 
            oGui.addMovie(SITE_IDENTIFIER, 'fatplaylive', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        
    oGui.setEndOfDirectory()
def fatplaylive():
    oInputParameterHandler = cInputParameterHandler()
    token =  "http://www.adulttvlive.net/channels/leotv.php"                             
                                         
#    url= cRequestHandler(token).request() 
    headers = {'Referer': 'http://www.adulttvlive.net/','User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'}
    sJson = requests.get(token, headers = headers).text    
    urll = re.findall('file:"(.*?)"',sJson , re.S)[0] +"|Referer="+token+"&User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36"
    name =  "https://goo.gl/wqsVrs"  
    url=  "http://live.redtraffic.xyz/teen.m3u8" 
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]' + name, url, '')
                                                                                        
   
def play__LiveTV2():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl= oInputParameterHandler.getValue('siteUrl')
    referer ='http://oklivetv.com/genre/adult-18/?orderby=likes'
    dat= cRequestHandler(sUrl).request()                                                                                                   	
    url = re.findall("<iframe style='width:100%;height:100%;background-color: #1A1A1A;' scrolling='no' frameborder='0' src='(.*?)'",dat, re.S)[0]
    if not 'http' in url:
         url ='http:'+ url                      
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','Referer': referer  }
    data= requests.get(url, headers = headers).text   
    data=data.replace('" class="current">','">')
    sPicture ="https://tvshqip.tv/tv/wp-content/uploads/2016/05/logo.png"
    tarzlistesi = re.findall('id="tab.*?" href="(.*?)">(.*?)</a>', data , re.S)
    for sUrl,sTitle in tarzlistesi:
        Url ='http://oklivetv.com/xplay/'+ sUrl
        sTitle = alfabekodla(sTitle)
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', Url)
        oGui.addMovie(SITE_IDENTIFIER, 'play__LiveTV3', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()   
       
    
def play__LiveTV3():
    oGui = cGui()
    UA='Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
   
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    referer = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    
    sTitle =  alfabekodla(sTitle)                            
 
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','Referer': referer  }
    data= requests.get(url, headers = headers).text
    data=data.replace('\r',"").replace('\s',"").replace('\n',"")
    if re.search('<div id="object_container"', data):    
               rUrl = re.findall('<script src="(.*?)"', data)[0]
               if not 'http' in rUrl:
                  rUrl = 'http:' + rUrl
               ptaweHosters(rUrl)
               
    if  'id="wrd"' in data:
          rUrl = re.findall('src="(.*?)"', data)[0]
          rUrl =rUrl.replace(' ', '%20')
          if not 'http' in rUrl:
                rUrl = 'http:' + rUrl
         
          
          
          headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','Referer': referer  }
          ata= requests.get(rUrl, headers = headers).text
          ata =ata.replace("\/",'/').replace("\\",'')  
        
            
          sHosterUrl =  ata
          #sHosterUrl='https://fash1043.cloudycdn.services/slive/_definst_/ftv_midnite_secrets_adaptive.smil/playlist.m3u8|Referer=http://oklivetv.com/xplay/4d6a5131.html&User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Mobile Safari/537.36'
   
    sPicture ="https://tvshqip.tv/tv/wp-content/uploads/2016/05/logo.png"
    sTitle = alfabekodla(sTitle)
    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sTitle)
    oGuiElement.setMediaUrl(sHosterUrl)
    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    oPlayer.startPlayer()      
  
def ptaweHosters(rUrl):
    oGui = cGui()


   
  
    referer ='http://oklivetv.com/'
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36','Referer': referer  }
    ata= requests.get(rUrl, headers = headers).text
    prUrl =re.findall("'(//pt.protoawe.com.*?)',", ata)[0]
          
    if not 'http' in prUrl:
         prUrl = 'http:' + prUrl 
    
    resp = net.http_GET(prUrl)
    data = resp.content                                                                                                        	
    data = data.replace('\/','/')
      
                               
    tarzlistesi = re.findall('gaLabel: "(.*?)".*?url: "(.*?)",', data , re.S)
    # 1 seul resultat et sur leur propre hebergeur
    for sTitle,sUrl in tarzlistesi:
        
       
            
    
    
        Header = 'User-Agent=Mozilla/5.0 (Linux; U; Android 2.2.1; en-us; Nexus One Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1'
    
        sTitle =  alfabekodla(sTitle)
        if not 'http' in sUrl:
           sUrl = 'http:' + sUrl  
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oGui.addDir(SITE_IDENTIFIER, 'play__', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory()
     
  

def GetPlayList():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    pos = oInputParameterHandler.getValue('sMovieTitle')
    img = oInputParameterHandler.getValue('sThumbnail')
    resp = net.http_GET(url)
    data = resp.content 
 
    s_url = ''
    s_num = 0
    for rec in re.compile('{(.+?)}', re.MULTILINE|re.DOTALL).findall(data.replace('{"playlist":[', '')):
        for par in rec.replace('"','').split(','):
            if par.split(':')[0]== 'comment':
                sTitle =' Video_'+  str(s_num+1) #par.split(':')[1]+' '
            if par.split(':')[0]== 'file':
                if 'http' in par.split(':')[1]:
                    s_url = par.split(':')[1]+':'+par.split(':')[2]
               
        s_num += 1

        if s_num >= pos :
                    sPicture='http://ero-tv.org/wp-content/uploads/2014/08/brazzers.gif'
                    sTitle = alfabekodla(sTitle)
                    liste = []
                    liste.append( [sTitle,s_url] )
                    oOutputParameterHandler = cOutputParameterHandler()
                    oOutputParameterHandler.addParameter('siteUrl', str(s_url))
                    oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
                    oOutputParameterHandler.addParameter('liste', str(liste))
                    oOutputParameterHandler.addParameter('sThumbnail', sPicture) #sortis du poster
                    oGui.addMovie(SITE_IDENTIFIER, 'otvplay__', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()
        
  
def sPlayerType():
        
       
        oConfig = cConfig()
        sPlayerType = oConfig.getSetting('playerType')
        try:
            if (sPlayerType == '0'):
                cConfig().log("playertype from config: auto")
                return xbmc.PLAYER_CORE_AUTO

            if (sPlayerType == '1'):
                cConfig().log("playertype from config: mplayer")
                return xbmc.PLAYER_CORE_MPLAYER

            if (sPlayerType == '2'):
                cConfig().log("playertype from config: dvdplayer")
                return xbmc.PLAYER_CORE_DVDPLAYER
        except: return False

def dizizleABC():
    oGui = cGui()
  
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    name =  alfabekodla(sTitle)       
        
  
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')
                                                                                            



def otvplay__():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    sTitle =  alfabekodla(sTitle)
    sHosterUrl = sUrl
    



    

    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sTitle)
    oGuiElement.setMediaUrl(sHosterUrl)
        

    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    oPlayer.startPlayer() 

def pornhdGenre():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    
    data = cRequestHandler(url).request()                                                                                                         	
                          
    if re.match('.*?<li class="category"', data, re.S):    
      data = data.replace("\n",'')
      tarzlistesi = re.findall('<li class="category"><a href="(.*?)".*?data-original="(.*?)".*?</span>(.*?)</a>', data , re.S)
      for sUrl,sPicture,sTitle in tarzlistesi:
        Url ='https://www.pornhd.com'+ sUrl
        sTitle = alfabekodla(sTitle)
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', Url)
        oGui.addMovie(SITE_IDENTIFIER, 'pornhdliste', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()  
def wpornhdliste():
   

    oInputParameterHandler = cInputParameterHandler()
    urll = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    name=  alfabekodla(sTitle)
    urla  = "https://www.pornhd.com/"
                     
    referer=[('Referer',urla)]
    url=gegetUrl(urll,headers=referer)  
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')

def pornhdliste():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
       
    urla  = "https://www.pornhd.com/"
                     
    referer=[('Referer',urla)]
    sHtmlContent=cRequestHandler(url).request()
 
    tarzlistesi = re.findall('data-mp4=".*?" data-webm=".*?" data-id=".*?" data-video=".*?" ><a class=".*?" href="(.*?)"><img alt="(.*?)"  src="(.*?)"', sHtmlContent , re.S)
    for sUrl,sTitle,sPicture in tarzlistesi:
        Url ='https://www.pornhd.com'+ sUrl
        sTitle = alfabekodla(sTitle)
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', Url)
        oGui.addMovie(SITE_IDENTIFIER, 'pornhdHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()    
  
def pornhdNextPage(sHtmlContent,sUrl):
    oGui = cGui()
    

                                 
      
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sPattern = '<li class="next ">.*?<span class="icon jsFilter js-link" data-query-key="page" data-query-value="(.*?)">'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        return str(sUrl)+'?page='+ aResult[1][0]
    return False


def hdpornGenre():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    
    data = cRequestHandler(url).request()                                                                                                        	
    
    if re.match('.*?<div id="main">', data, re.S):    
      data = data.replace("\n",'')
      tarzlistesi = re.findall('<div class="content">.*?<a href="(.*?)" title="(.*?)".*?src="(.*?)"', data , re.S)
      for sUrl,sTitle,sPicture in tarzlistesi:
        Url ='http://hdporn.net'+ sUrl
        sTitle = alfabekodla(sTitle)
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', Url)
        oGui.addMovie(SITE_IDENTIFIER, 'hdpornliste', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()  



def hdpornliste():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
       
                                                                                                                                       
    sHtmlContent = cRequestHandler(url).request() 
    tarzlistesi = re.findall('<div class="content col-xs-12 col-sm-4 col-md-3">.*?<a  href=".*?" title="(.*?)" target="_self">.*?src="(.*?)".*?this.src="(.*?.mp4)/.*?.mp4-.*?.jpg"', sHtmlContent , re.S)
    for sTitle,sPicture,sUrl in tarzlistesi:
        Header = 'User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Mobile Safari/537.36'
        sTitle = alfabekodla(sTitle)
        Url = sUrl.replace('thumbs','videos')+ '|' + Header 
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('sThumbnail', sPicture) 
        oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
        oOutputParameterHandler.addParameter('siteUrl', Url)
        oGui.addMovie(SITE_IDENTIFIER, 'play__', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()  

def hdpornNextPage(sHtmlContent,url):
    oGui = cGui()
    

    
      
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sPattern = '<div id="pagination">.*?<span>.*?</span><a href="(.*?)">'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        return str(sUrl)+ aResult[1][0]
    return False


def redtubeGenre():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
                                                                                  
                        
    sHtmlContent = cRequestHandler(url).request()
    sHtmlContent = sHtmlContent.replace("\n",'').replace("//cdne",'http://cdne')
    tarzlistesi = re.findall('<button class="dropdown_option js_drpd_item" type="button" data-value="(.*?)">(.*?)</button>', sHtmlContent , re.S)
    for sUrl,sTitle  in tarzlistesi:
        Url ='http://www.redtube.com/redtube/'+ sUrl
        
        sPicture='https://ei.rdtcdn.com/www-static/cdn_files/redtube/images/pc/category/'+ sUrl+'_001.jpg'
        sTitle = alfabekodla(sTitle)
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', Url)
        oGui.addMovie(SITE_IDENTIFIER, 'redtubeliste', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()    
     
def redtubeliste(sSearch = ''):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    
    data = cRequestHandler(url).request()                                                                                                       	
    data = data.replace("\n",'')
      
     
         
         
         
                          
    tarzlistesi = re.findall('<img id="img_browse_(.*?)".*?src="(.*?)".*?alt="(.*?)"', data , re.S)
    for sUrl,sPicture,sTitle in tarzlistesi:
        Url ='https://www.redtube.com/'+ sUrl
        sTitle = alfabekodla(sTitle)
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', Url)
        
        oGui.addMovie(SITE_IDENTIFIER, 'redtubeHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()  
def redtubeNextPage(sHtmlContent,sUrl):
    oGui = cGui()
    
    
    
    kUrl ='http://www.redtube.com'  
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sPattern = 'id="currentPageNum"><b>.*?</b></a>.*?<a href="(.*?)" title=".*?" onclick="trackByCookie.*?'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        return str(kUrl)+ aResult[1][0]
    return False



def pornhubGenre():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
   
    data = cRequestHandler(url).request()                                                                                                       	

						                                                                                                                                                        
							                 
    tarzlistesi = re.findall('<a class="js-mixpanel" data-mixpanel-listing="" href="(.*?)" onclick="ga.*?;" alt="(.*?)">.*?<img class="js-menuSwap" data-image="(.*?)"', data , re.S)
    for sUrl,sTitle,sPicture in tarzlistesi:
        Url ='https://de.pornhub.com'+ sUrl
        sTitle = alfabekodla(sTitle)
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', Url)
        oGui.addMovie(SITE_IDENTIFIER, 'pornhubliste', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
    oGui.setEndOfDirectory() 
def pornhubliste(sSearch = ''):
   
    oGui = cGui()
       
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'http://www.fox.com.tr/bolum-izle'
        request = urllib2.Request(url,data,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
         
       #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern = "<div class='videoThmp'><a href='(.*?)' title='.*?'><img class='lazy' data-original='.*?' src='(.*?)' width='100%' alt='(.*?)'"                    
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl= oInputParameterHandler.getValue('siteUrl')
        oRequestHandler = cRequestHandler(sUrl)
        sHtmlContent = oRequestHandler.request()  
        
   

                                            
			                                                                                                     	
                                            
                               
        sPattern = '<div class="phimage">.*?<a href="(.*?)" title="(.*?)".*?data-mediumthumb="(.*?)"'
                                         
    sHtmlContent = sHtmlContent
    sHtmlContent = alfabekodla(sHtmlContent)
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
   
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = alfabekodla(aEntry[1]) 
           
            sPicture = aEntry[2]
                
            Url ='http://www.pornhub.com'+ aEntry[0]+'&utm_source=twitter&utm_medium=social'
            
            #not found better way
            #sTitle = unicode(sTitle, errors='replace')
            #sTitle = sTitle.encode('ascii', 'ignore').decode('ascii')
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', Url)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture) #sortis du poster
 
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/anime/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'redtubeHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog) 
        
           
        if not sSearch:
          
            sNextPage = pornhubNextPage(sHtmlContent,sUrl)#cherche la page suivante
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'pornhubliste', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                              #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()
def pornhubNextPage(sHtmlContent,sUrl):
    oGui = cGui()
                 
   
    sHtmlContent =sHtmlContent.replace('amp;','')
    kUrl ='http://www.pornhub.com'                                      
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sPattern = ' <li class="page_current"><span class="greyButton">.*?<li class="page_number"><a class="greyButton" href="(.*?)">'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        return str(kUrl)+ aResult[1][0]
    return False                 
def __checkForNextPage(sHtmlContent):
    oGui = cGui()
    

    
      
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sPattern = '<li class=\'active\'><a href=".*?">.*?</a></li>.*?<li ><a href="(.*?)">.*?</a></li>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        return str(URL_MAIN)+ aResult[1][0]
    return False


def mpornhdHosters():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('Thumbnail')
    
    
    sHtmlContent =  cRequestHandler(url).request()
    sHtmlContent = sHtmlContent.replace('\/','/')
    sTitle = cUtil().DecoTitle(sTitle)       
    sPattern = '"720p":"(.*?)"'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
          
    if (aResult[0] == True):
        
        
            
        sUrl= '' + aResult[1][0]
           
        

        oGuiElement = cGuiElement()
        oGuiElement.setSiteName(SITE_IDENTIFIER)
        oGuiElement.setTitle(sTitle)
        oGuiElement.setMediaUrl(sUrl)
        oGuiElement.setThumbnail(sThumbnail)

        oPlayer = cPlayer()
        oPlayer.clearPlayList()
        oPlayer.addItemToPlaylist(oGuiElement)
        oPlayer.startPlayer()
        return
        
    oGui.setEndOfDirectory()    
def play__():
   

    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    name=  alfabekodla(sTitle)
      
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')
def playVideo(isAutoplay = False):
        oInputParameterHandler = cInputParameterHandler()
        urlll = oInputParameterHandler.getValue('siteUrl')
        title = oInputParameterHandler.getValue('sMovieTitle')
        if title:
            listitem.setInfo('video', {'title': title})

        if not isAutoplay:
            xbmcplugin.setResolvedUrl(self.handle, True, listitem)
        else:
            url = urllib.unquote_plus(urlll)
            xbmc.Player().play(url, listitem)                                                                                            

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok

def play2():
    

    oInputParameterHandler = cInputParameterHandler()
    rest = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    Header = 'User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Mobile Safari/537.36'
    sHosterUrl= rest + '|User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Mobile Safari/537.36' + Header    

    sTitle =  alfabekodla(sTitle)
    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sTitle)
    oGuiElement.setMediaUrl(sHosterUrl)
        

    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    oPlayer.startPlayer() 
    
def redtubeHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
        
    resp = net.http_GET(url)
    sHtmlContent = resp.content
    sHtmlContent = sHtmlContent.replace('\/','/')
    tarzlistesi = re.findall('"quality":"(.*?)","videoUrl":"(.*?)"', sHtmlContent , re.S)
    for sTitle,Url in tarzlistesi:
        Header = 'User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Mobile Safari/537.36'
    
        MAIN = 'http:'
        Url = str(Url)
        if not 'http' in Url:
                Url = str(MAIN) + Url + '|' + Header 
        sPicture  = "http://cdne-st.redtubefiles.com/images/logos/logo_RT_premium.png?v=5d9a2e0cf0b93d9f391d915e19214fe37f64c3501481841392"
        sTitle =  alfabekodla(sTitle)
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
        oOutputParameterHandler.addParameter('siteUrl', Url)
        oGui.addMovie(SITE_IDENTIFIER, 'play__', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

    oGui.setEndOfDirectory() 
def mmmredtubeHosters():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
   
  
    url = oInputParameterHandler.getValue('siteUrl')
    resp = net.http_GET(url)
    data = resp.content                                                                                                        	
    data = data.replace('\/','/')
      
                               
    tarzlistesi = re.findall('sources: ."480":"(.*?)".*?videoTitle: "(.*?)"', data , re.S)
    # 1 seul resultat et sur leur propre hebergeur
    for sUrl,sTitle in tarzlistesi:
        
       
            
    
    
        Header = 'User-Agent=Mozilla/5.0 (Linux; U; Android 2.2.1; en-us; Nexus One Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1'
    
        sTitle =  alfabekodla(sTitle)
        sHosterUrl = sHosterUrl + '|' + Header  
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oGui.addDir(SITE_IDENTIFIER, 'play__', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory()
     
 
def pornhdHosters():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle= oInputParameterHandler.getValue('sMovieTitle')
    iconimage = oInputParameterHandler.getValue('sThumbnail')
   
    oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('Host', 'www.pornhd.com')
    oRequest.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; rv:67.0) Gecko/20100101 Firefox/67.0')
    oRequest.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
    oRequest.addHeaderEntry('Accept-Language', 'en-US,en;q=0.5')
    oRequest.addHeaderEntry('Accept-Encoding', 'gzip, deflate, br')
    oRequest.addHeaderEntry('Referer', sUrl)
    oRequest.addHeaderEntry('Connection', 'keep-alive')
    oRequest.addHeaderEntry('Cookie', '_ga=GA1.2.143518839.1559884905; _gid=GA1.2.955783398.1559884905; webpSupported=1; phd-ses=7rgpj80t3trht0ebh7tp6r87aa; _csrf-frontend=85e2c4571974ef97b3683f46331e0e01184f88c725aea9a192104bcbd7541cffa%3A2%3A%7Bi%3A0%3Bs%3A14%3A%22_csrf-frontend%22%3Bi%3A1%3Bs%3A32%3A%22a3QNbitrgKW6DvfUKFY9csabdXhhk8qM%22%3B%7D; g36FastPopSessionRequestNumber=1')
    oRequest.addHeaderEntry('Upgrade-Insecure-Requests', '1')
    oRequest.addHeaderEntry('Cache-Control', 'max-age=0')
    sHtmlContent = oRequest.request()
    sHtmlContent = sHtmlContent.replace('\/','/')
    oParser = cParser()
    
  
    sPattern =  '"720p":"(.*?)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
     
    # 1 seul resultat et sur leur propre hebergeur
    if (aResult[0] == True):
        
        
       
         
       
#        url =requests.get(new_url, allow_redirects=False)
    
#        encoded='eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0.eyJpc3MiOiJodHRwczpcL1wvd3d3LnBvcm5oZC5jb20iLCJhdWQiOiJodHRwczpcL1wvd3d3LnBvcm5oZC5jb20iLCJqdGkiOiI0MjIwNCIsImlhdCI6MTU1OTkxMTU1MSwiZXhwIjoxNTU5OTEzMzUxLCJ1cmwiOiJwOUVRWFBjYVNEZlE3UXZtQXJuQ0V3T29qZ2FOalludFdseFE2Ykl3c2JXVmVkN0Z0eHJndzJDK1wvd3hpN0dwNllvSlhsUjB5TFhrN0E0VmFub3EzSitzVVozbmxcL1wvRXRTZVhTWGVCVUhXWE5UV1paWkxvWFlUck9lNUJBbnozMCIsInZpZGVvSWQiOjQyMjA0fQ.","480p":"\/gvf\/eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0.eyJpc3MiOiJodHRwczpcL1wvd3d3LnBvcm5oZC5jb20iLCJhdWQiOiJodHRwczpcL1wvd3d3LnBvcm5oZC5jb20iLCJqdGkiOiI0MjIwNCIsImlhdCI6MTU1OTkxMTU1MSwiZXhwIjoxNTU5OTEzMzUxLCJ1cmwiOiJwOUVRWFBjYVNEZlE3UXZtQXJuQ0V3T29qZ2FOalludFdseFE2Ykl3c2JYRjBuU1VoS1wvRE90YjVxMmozS1ozcGRvZHViVnF2U2g4ank2aTdsTWxBOGVWOEMzTFJtREc2UW9cLzVjN1BDczRlR1VxeExIdDBvb3c0RFhLYW9HUGhmIiwidmlkZW9JZCI6NDIyMDR9'
#        jwt.decode(encoded, 'secret', algorithms=['HS256'])
              
        
        res = urllib2.urlopen(sUrl, timeout=12)
        cookie = res.info()['Set-Cookie']
        TIK='|Cookie='+ cookie

        sTitle =  alfabekodla(sTitle)    
        link ='https://www.pornhd.com'+aResult[1][0] #+TIK
#        encoded =  b64decode(he) 
#        Url =jwt.decode(encoded, 'secret', algorithms=['HS256'])
        
  
#        Url =urla  = "https://www.pornhd.com/"                            Range: bytes=0-
        
      
     
        
      
        Url = link +TIK
       
        name =  "https://goo.gl/wqsVrs"  
        addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]' + name, Url, '')
     
             
  
    
def GetRealUrl(url):
    oParser = cParser()
    sPattern = '\[REGEX\](.+?)\[URL\](.+$)'
    aResult = oParser.parse(url, sPattern)
    
    if (aResult):
        reg = aResult[1][0][0]
        url2 = aResult[1][0][1]
        oRequestHandler = cRequestHandler(url2)
        sHtmlContent = oRequestHandler.request()
        
        aResult = oParser.parse(sHtmlContent, reg)
        if (aResult):
            url = aResult[1][0]
            
            oRequestHandler = cRequestHandler(url)
            sHtmlContent = oRequestHandler.request()
        
    return url
def sPlayerType():
        oConfig = cConfig()
        sPlayerType = oConfig.getSetting('playerType')
        
        try:
            if (sPlayerType == '0'):
                cConfig().log("playertype from config: auto")
                return xbmc.PLAYER_CORE_AUTO

            if (sPlayerType == '1'):
                cConfig().log("playertype from config: mplayer")
                return xbmc.PLAYER_CORE_MPLAYER

            if (sPlayerType == '2'):
                cConfig().log("playertype from config: dvdplayer")
                return xbmc.PLAYER_CORE_DVDPLAYER
        except: return False
    

def epornhubGenre():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    Url = oInputParameterHandler.getValue('siteUrl')
    data = requests.get(Url).content
                                                                                                         	

						
							              
    tarzlistesi = re.findall('<div class="categoriesbox" id=".*?"> <div class="ctbinner"> <a href="(.*?)" title=".*?"> <img src="(.*?)" alt="(.*?)">', data , re.S)
    for sUrl,sPicture,sTitle in tarzlistesi:
        Url ='http://www.eporner.com'+ sUrl
        sTitle = alfabekodla(sTitle)
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', Url)
        oGui.addMovie(SITE_IDENTIFIER, 'epornhubliste', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
    oGui.setEndOfDirectory() 
def epornhubliste(sSearch = ''):
   
    oGui = cGui()
       
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'http://www.fox.com.tr/bolum-izle'
        request = urllib2.Request(url,data,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
         
       #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern = "<div class='videoThmp'><a href='(.*?)' title='.*?'><img class='lazy' data-original='.*?' src='(.*?)' width='100%' alt='(.*?)'"                    
    else:
        oInputParameterHandler = cInputParameterHandler()
        url = oInputParameterHandler.getValue('siteUrl')
        sUrl=url
        resp = net.http_GET(url)
	sHtmlContent = resp.content
        
   

                                            
                                          
                                             
			                                                                                                     	
                                            
                               
        sPattern = 'class="mb.*?>\s*<a\shref="(.*?)"\stitle="(.*?)".*?src="(.*?)"'
                                         
    sHtmlContent = sHtmlContent
    sHtmlContent = alfabekodla(sHtmlContent)
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
   
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = alfabekodla(aEntry[1]) 
           
            sPicture = aEntry[2]
                
            Url ='http://www.eporner.com'+ aEntry[0]
            
            #not found better way
            #sTitle = unicode(sTitle, errors='replace')
            #sTitle = sTitle.encode('ascii', 'ignore').decode('ascii')
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', Url)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            #sortis du poster
 
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/anime/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'epornerHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog) 
        
           
        if not sSearch:
          
            sNextPage = pornhubNextPage(sHtmlContent,sUrl)#cherche la page suivante
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'pornhubliste', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                              #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()

def mepornerHosters():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    
   
  
    url = oInputParameterHandler.getValue('siteUrl')
    resp = net.http_GET(url)
    data = resp.content                                                                                                        	
    data = data.replace('\/','/')
      
                              
    tarzlistesi = re.findall('</td> </tr> <tr> <td style="vertical-align:top;"><strong>(.*?)</strong></td> <td> <a href="(.*?)">Download MP4.*?</a> </td>', data , re.S)
    # 1 seul resultat et sur leur propre hebergeur
    for sTitle,sUrl in tarzlistesi:
        
       
            
        Header = 'User-Agent=Mozilla/5.0 (Linux; U; Android 2.2.1; en-us; Nexus One Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1'
    
    
        sTitle =  alfabekodla(sTitle)    
        Url ='http://www.eporner.com'+sUrl
        Url = Url + '|' + Header  
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', Url)
        oGui.addDir(SITE_IDENTIFIER, 'play__', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory()
     
def epornerHosters():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    
   
  
    url = oInputParameterHandler.getValue('siteUrl')
    resp = net.http_GET(url)
    data = resp.content                                                                                                        	
    data = data.replace('\/','/')
      
                                                
    tarzlistesi = re.findall('<td style="vertical-align:top;"><strong>(.*?)</strong></td> <td> <a href="(.*?)"', data , re.S)
    # 1 seul resultat et sur leur propre hebergeur
    for sTitle,sUrl in tarzlistesi:
        
       
            
        Header = 'User-Agent=Mozilla/5.0 (Linux; U; Android 2.2.1; en-us; Nexus One Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1'
    
    
        sTitle =  alfabekodla(sTitle)    
        Url ='http://www.eporner.com'+sUrl
        Url = Url + '|' + Header  
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', Url)
        oGui.addDir(SITE_IDENTIFIER, 'play__', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory()
     
   
