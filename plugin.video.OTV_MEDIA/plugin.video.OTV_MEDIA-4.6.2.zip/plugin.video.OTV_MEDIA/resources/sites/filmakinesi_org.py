#-*- coding: utf-8 -*-
import urllib2, urllib,cookielib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, zipfile, re, stat, xbmcvfs, base64
from resources.lib.otvhelper import  gegetUrl,getUrl ,alfabekodla
from resources.lib.config import cConfig
import requests
import re,xbmcgui,unicodedata              
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress, VSlog
from resources.lib.player import cPlayer
from resources.lib.kplayer  import Player
from resources.lib.gui.guiElement import cGuiElement





                
SITE_IDENTIFIER = 'filmakinesi_org'
SITE_NAME = 'Filmakinesi.org'
SITE_DESC = 'Films streaming'

TURK_SINEMA= (True, 'showGenre') 
URL_MAIN = 'http://filmakinesi.net/'

MOVIE_COMMENTS = (True, 'showGenre')
def encode_for_logging(c, encoding='ascii'):
    if isinstance(c, basestring):
        return c.encode(encoding, 'replace')
    elif isinstance(c, Iterable):
        c_ = []
        for v in c:
            c_.append(encode_for_logging(v, encoding))
        return c_
    else:
        return encode_for_logging(unicode(c))
 
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if (sSearchText != False):
        sUrl = 'https://filmakinesi.net/?s=' + sSearchText
        sUrl= sUrl.replace(' ','+')
        searchowMovies(sUrl)
        oGui.setEndOfDirectory()
        return
        
def AlphaSearch():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    
    dialog = cConfig().createDialog(SITE_NAME)
    
    for i in range(0,27) :
        cConfig().updateDialog(dialog, 36)
        
        if (i > 0):
            sTitle = chr(64+i)
        else:
            sTitle = '09'
            
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl + sTitle.upper() )
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR azure] Lettre [COLOR teal]'+ sTitle +'[/COLOR][/COLOR]', 'genres.png', oOutputParameterHandler)
        
    cConfig().finishDialog(dialog)
    
    oGui.setEndOfDirectory()           
    
def filmakinesi(): #affiche les genres
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', 'ARA', 'search.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://filmakinesi.org/')
    oGui.addDir(SITE_IDENTIFIER, 'sshowMovies', 'Yeni Filmler', 'genres.png', oOutputParameterHandler)

    sUrl='https://filmakinesi.net/'
    

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    
    
    
    oParser = cParser()
             
    sPattern = '<li id="menu-item-.*?" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-.*?"><h4><a href="(.*?)">(.*?)</a>'
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            
            sGenre = alfabekodla(aEntry[1])
            
            Link =aEntry[0]
           
            sTitle = alfabekodla(aEntry[1])
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', Link)
            oGui.addTV(SITE_IDENTIFIER, 'showMovies', sGenre, '', '', '', oOutputParameterHandler)
            
        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory()    

def searchowMovies(sUrl):
    oGui = cGui()
    resp = net.http_GET(sUrl)
    data = resp.content                   
                                
    sHtmlContent = re.findall('<article class="post-.*? film">.*?<a href="(.*?)".*?<img src=".*?" data-src="(.*?)" class="lazyload" alt="(.*?)"', data, re.S)
         
    for sUrl,sPicture,sTitle in sHtmlContent:
             
                       
            sTitle = alfabekodla(sTitle)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))            
            oOutputParameterHandler.addParameter('sThumbnail',  sPicture) 
            oGui.addMovie(SITE_IDENTIFIER, 'Hosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
         
    oGui.setEndOfDirectory()  
def sshowMovies(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'http://www.voirfilms.org/rechercher'
        request = urllib2.Request(url,data,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
        sPattern = '<div class="post-.*? film">.*?<a href="(.*?)".*?<img src="(.*?)" alt="(.*?)"'
                    
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
   
        oRequestHandler = cRequestHandler(sUrl)
        sHtmlContent = oRequestHandler.request()
        sHtmlContent = sHtmlContent.replace('.html','.html/9')
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '<div class="post-.*? film">.*?<a href="(.*?)".*?<img.*?data-src="(.*?)".*?alt="(.*?)".*?<div class="dubla.*?">(.*?)</div>'
    
    
  
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            
            sUrl = str(aEntry[0])
            if not 'http' in sUrl:
                sUrl = str(URL_MAIN) + sUrl
            sThumbnail = str(aEntry[1])
            if not 'http' in  sThumbnail:
                 sThumbnail = str(URL_MAIN) +  sThumbnail
                
            
            sTitle =aEntry[2] + ' [COLOR limegreen]' + aEntry[3] +'[/COLOR]'
          
            sTitle = alfabekodla(sTitle)
             
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail',  sThumbnail) #sortis du poster
            oGui.addTV(SITE_IDENTIFIER, 'Hosters', sTitle, '', sThumbnail, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = __checkForNextPage(sHtmlContent)#cherche la page suivante
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()
   




def showMovies(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'http://www.voirfilms.org/rechercher'
        request = urllib2.Request(url,data,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()

        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern = '<article class="post-.*? film">.*?<a href="(.*?)".*?<img src="(.*?)" alt="(.*?)"'
                    
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
   
        oRequestHandler = cRequestHandler(sUrl)
        sHtmlContent = oRequestHandler.request()
        sHtmlContent = sHtmlContent.replace('.html','.html/9')
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '<article class="post-.*? film">.*?<a href="(.*?)".*?<img.*?data-src="(.*?)".*?alt="(.*?)"'
    
    
  
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            
            sUrl = str(aEntry[0])
            if not 'http' in sUrl:
                sUrl = str(URL_MAIN) + sUrl
            sThumbnail = str(aEntry[1])
            if not 'http' in  sThumbnail:
                 sThumbnail = str(URL_MAIN) +  sThumbnail
                
            
           
          
            sTitle = aEntry[2]
            sTitle = alfabekodla(sTitle)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail',  sThumbnail) #sortis du poster
            oGui.addTV(SITE_IDENTIFIER, 'Hosters', sTitle, '', sThumbnail, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = __checkForNextPage(sHtmlContent)#cherche la page suivante
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()
   
   
   
def __checkForNextPage(sHtmlContent):                     
    sPattern = '<ul><li class="page_info">.+?">.+?</a></li>.+?<li><a href="(.+?)">.+?</a></li>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        sUrl = aResult[1][0]
        return sUrl

    return False
def kodu(iyi):
    while iyi!=[1000]:
      
      iyi=iyi
      return iyi 

def Hosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl') 
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request();
    oParser = cParser()
    sPattern = '<div class="film_part hidden-mobile">(.+?)</body>'
 
    aResult = oParser.parse(sHtmlContent, sPattern)
    sHtmlContent = aResult
                 
    sPattern = '<a href="(.*?)" class="post-page-numbers"><span>(.*?)</span></a>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    for urlm in aResult[1]:
        sUrl2 = urlm[0]                         
        if 'respond' in sUrl2: 
               LshowHosters(sUrl2)
        
        sTitle = urlm[1]
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl2)
        oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle )
        if sTitle == 'PROGRAMLAR':
             oGui.addDir(SITE_IDENTIFIER, 'showSinema',  sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'KLASİK DİZİLER':
             oGui.addDir(SITE_IDENTIFIER, 'ArshowSinema', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'YENİ DİZİLER':
             oGui.addDir(SITE_IDENTIFIER, 'showSinema', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'KLASİK DİZİLER ABC':
             oGui.addDir(SITE_IDENTIFIER, 'klasikdizizleABC', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'ATV YEDEK':
             oGui.addDir(SITE_IDENTIFIER, 'canlitvzoneBox', sTitle, 'genres.png', oOutputParameterHandler)

        else:
             oGui.addDir(SITE_IDENTIFIER, 'streams',  sTitle, 'genres.png', oOutputParameterHandler)
           

    oGui.setEndOfDirectory()
    
def ODKosters():
    oGui = cGui()       
             
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    sHtmlContent = sHtmlContent.replace('<iframe src="http://www.promoliens.net','')
    sHtmlContent = sHtmlContent.replace("<iframe src='cache_vote.php",'')
                
    sPattern = '<p><!--baslik:(.*?)--><iframe width="640" height="360" allowfullscreen src="(.*?)"'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break

           
            Url = str(aEntry[1])            
            Title = str(aEntry[0])
             
            referer=[('Referer',sUrl)]
            streamurl=gegetUrl(Url,headers=referer)                    
                          
            
                
            sHoster = re.findall('<iframe.*?src="(.*?)"', streamurl) 
            Title = alfabekodla(Title)
            HosterUrl= "https://m.ok.ru/video/%s" % sHoster[0]
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl',HosterUrl)
            oGui.addTV(SITE_IDENTIFIER, 'mokru', Title, '', '', '', oOutputParameterHandler)   
                               
        cConfig().finishDialog(dialog) 

    oGui.setEndOfDirectory()
def _substitute_entity(match):
        ent = match.group(3)
        if match.group(1) == '#':
            # decoding by number
            if match.group(2) == '':
                # number is in decimal
                return unichr(int(ent))
            elif match.group(2) == 'x':
                # number is in hex
                return unichr(int('0x' + ent, 16))
        else:
            # they were using a name
            cp = n2cp.get(ent)
            if cp: return unichr(cp)
            else: return match.group()

def decode_html(data):
	try:
		if not type(data) == unicode:
			data = unicode(data, 'utf-8', errors='ignore')
		entity_re = re.compile(r'&(#?)(x?)(\w+);')
    		return entity_re.subn(_substitute_entity, data)[0]
	except:
		traceback.print_exc()
		#print [data]
		return data


def MAKNEHosters():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    sHtmlContent = sHtmlContent.replace('<iframe src="http://www.promoliens.net','')
    sHtmlContent = sHtmlContent.replace("<iframe src='cache_vote.php",'')
                
    sPattern = '<!--baslik:Tek MAKİNE--><iframe src="(.*?)"'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break

            #si url cryptee mangacity algo
            Url = str(aEntry)            
           
           
            referer=[('Referer',sUrl)]
            streamurl=gegetUrl(Url,headers=referer)                    
            sHosterUrl = re.findall('src="(https://drive.google.com.*?)"', streamurl)
            sMovieTitle = alfabekodla(sMovieTitle) 
            
            oHoster = cHosterGui().checkHoster(sHosterUrl[0])

            if (oHoster != False):
                sDisplayTitle = cUtil().DecoTitle(sMovieTitle)
               
                
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumbnail)

        cConfig().finishDialog(dialog) 

    oGui.setEndOfDirectory()

def showHosters():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    sHtmlContent = sHtmlContent.replace('<iframe src="http://www.promoliens.net','')
    sHtmlContent = sHtmlContent.replace("<iframe src='cache_vote.php",'')
                
    sPattern = '<!--baslik:.*?--><.*?[SRC|src]=["|\'](.*?)["|\']'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break

            #si url cryptee mangacity algo
            sHosterUrl = str(aEntry)            
                                
            #xbmc.log( 'fini :' + str(sHosterUrl)) 
            
            #oHoster = __checkHoster(sHosterUrl)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sHosterUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle )
            oOutputParameterHandler.addParameter('sThumbnail', sThumbnail)
            oGui.addTV(SITE_IDENTIFIER, 'streams', sMovieTitle, '', sThumbnail, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog) 

    oGui.setEndOfDirectory()

   



def terscevir(cba):
        oku = ""
        i = len(cba) - 1
        while i >= 0:
            oku += cba[i]
            i -= 1
        return oku        


def streams():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    sHtmlContent = sHtmlContent.replace('<iframe src="http://www.promoliens.net','')
    sHtmlContent = sHtmlContent.replace("<iframe src='cache_vote.php",'')
                
   
    sPattern = '<!--baslik:.*?--><.*?[SRC|src]=["|\'](.*?)["|\']'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break

            
            sHosterUrl = str(aEntry)            
            if 'https://filmakinesi.net' in sHosterUrl:
                sHosterUrl=sHosterUrl.replace("https://filmakinesi.net/player/url/","")
                        
                        
                url1="%s" % (sHosterUrl) 
                print url1
                url2 = base64.b64decode(url1)
                print url2
                url3 = terscevir(url2)            
                streamurl=base64.b64decode(url3) 
                print streamurl                    
                if "ok/" in streamurl:
                               streamurl=streamurl.replace('g�',"")  
                               sHosterUrl= "http://m.ok.ru/video/%s" % (streamurl.replace("ok/",""))
                               
                if "mail/" in streamurl:                     
                               streamurl=streamurl.replace('mailg�',"") 
                               urlan = re.findall('mail/(.*?)/(.*?)/', streamurl)
                               if urlan:         
                                     for (url1),(url2) in urlan:
                                
                               
                                                                                            
                                          sHosterUrl= "https://my.mail.ru/mail/%s/video/embed/_myvideo/%s?" % (url1,url2)
                                                    
                                              
                                              
                                    			                                  
                if "vk/" in streamurl:     
                                   streamurl=streamurl.replace('g�',"")  
                                   urlan = re.findall('vk/(.*?)/(.*?)/([a-z0-9]+)', streamurl)
                                   if urlan:         
                                           for (url1),(url2),(url3) in urlan:
                                
                               
                                                sHosterUrl= "http://vk.com/video_ext.php?oid=%s&id=%s&hash=%s" % (url1,url2,url3)
                                                
                if "uptostream/" in streamurl:     
                                      streamurl=streamurl.replace('g�',"")  
                                      streamurl=streamurl.replace("uptostream/","") 
                                      
                                      sHosterUrl= "http://uptostream.com/iframe/%s" % (streamurl)
                                                         
                if "openload/" in streamurl:     
                                      streamurl=streamurl.replace('g�',"")  
                                      streamurl=streamurl.replace("openload/","") 
                                      
                                      sHosterUrl= "https://openload.co/embed/%s" % (streamurl)
                                      
                if "vidmoly/" in streamurl:     
                                      streamurl=streamurl.replace('g�',"")  
                                      streamurl=streamurl.replace("vidmoly/","") 
                                      
                                      sHosterUrl= "https://vidmoly.me/embed-%s.html" % (streamurl)
                
                                      
                if "vidmoly/" in streamurl:     
                                      streamurl=streamurl.replace('g�',"")  
                                      streamurl=streamurl.replace("vidmoly/","") 
                                      
                                      sHosterUrl= "https://vidmoly.me/embed-%s.html" % (streamurl)
                            
              
             
                     
                         
                      
	     
            
           
            
            
            oHoster = cHosterGui().checkHoster(sHosterUrl)

            if (oHoster != False):
                sDisplayTitle = cUtil().DecoTitle(sMovieTitle)
                oHoster.setDisplayName(sDisplayTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumbnail)

        cConfig().finishDialog(dialog) 

    oGui.setEndOfDirectory()

def MMMfflashx2(sUrl):
      Url = re.findall('<iframe.*?src="(.*?)"',  sUrl[0])
      name = 'flashx.tv'
      addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,Url,'')
 

def mfflashx2():
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        data=data.replace('#respond">Yorum+yap</a></span>+',"") 
        if '<title>ok</title>' in data:
              Url= parseDOM(data, 'script', ret='path')[0]
        if "uptostream.com" in data:      
              Url= parseDOM(data, 'script', ret='videoId')[0]
        if '><!--baslik:Tek+Close-->< ' in data:      
              
              Url= parseDOM(data, 'iframe', ret='src')[0]       

        name = 'flashx.tv'
        addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,sUrl,'')
def fflashx2():
        oGui = cGui()
        oInputParameterHandler = cInputParameterHandler()
        sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
        sThumbnail = oInputParameterHandler.getValue('sThumbnail')
        sUrl = oInputParameterHandler.getValue('siteUrl')
        data=cRequestHandler(sUrl).request()
        Url = re.findall('<!--baslik:.*?-->.*?[SRC|src]=["|\'](.*?)["|\']', data)[0]
        if "filmakinesi.net" in Url: 
          datam=cRequestHandler(Url).request()
          if "uptostream.com" in datam: 
              rl = re.findall("videoId = '(.*?)';",  datam)[0]
              Url ='https://uptostream.com/'+rl
          if '<title>ok</title>' in datam: 
              rl = re.findall('path:"(.*?)"',  datam)[0]
              Url ='https://ok.ru'+rl
          if '><!--baslik:Tek+Close-->< ' in datam:
              Url = re.findall('<iframe.*?src="(.*?)"',  datam)[0]
        if not 'http' in Url:
            Url = 'https:' + Url
        dLink(Url,sMovieTitle,sThumbnail)
       
                                                                                                                                             
                                                                               
def mfflashx2():
        oGui = cGui()
        oInputParameterHandler = cInputParameterHandler()
        sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
        sThumbnail = oInputParameterHandler.getValue('sThumbnail')
        sUrl = oInputParameterHandler.getValue('siteUrl')
        data=cRequestHandler(sUrl).request()
        Url = re.findall('<!--baslik:.*?-->.*?[SRC|src]=["|\'](.*?)["|\']', data)[0]
                
        
        if not 'http' in Url:
            Url = 'https:' + Url
        dLink(Url,sMovieTitle,sThumbnail)
        
        
        
def dLink(Url,sMovieTitle,sThumbnail):         
        
      name = 'flashx.tv'
      addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,Url,'')
 


def addLink(name,url,iconimage):                                                                      
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )                                                                                                                                                     
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok


                      


def showHostersRR():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    sPattern = '<!--baslik:.*?--><.*?[SRC|src]=["|\'](.*?)["|\']'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break

            #si url cryptee mangacity algo
 
    sHoster =  aEntry
    sHoster=sHoster.replace("https://filmakinesi.org/player/url/","")
                
                        
                        
    url1=sHoster
              
    url2 = base64.b64decode(url1)
               
    url3 = terscevir(url2)            
    url3 =url3
    streamurl=base64.b64decode(url3)
    streamurl=streamurl.replace('g�',"")  
    streamurl=streamurl.replace("openload/","") 
                                      
    sHosterUrl= "https://openload.co/embed/%s" % (streamurl)

    sMovieTitle = alfabekodla(sMovieTitle) 
    oHoster = cHosterGui().checkHoster(sHosterUrl)

    if (oHoster != False):
        
        sMovieTitle = cUtil().DecoTitle(sMovieTitle)
        
        
        
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumbnail)

    oGui.setEndOfDirectory()
def kshowHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
   
    sHosterUrl = sUrl
 
    #oHoster = __checkHoster(sHosterUrl)
    oHoster = cHosterGui().checkHoster(sHosterUrl)

    if (oHoster != False):
        

        
        
        
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumbnail)

    oGui.setEndOfDirectory()
def LshowHosters(sUrl):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
  
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
   
    sHosterUrl = sUrl
 
    #oHoster = __checkHoster(sHosterUrl)
    oHoster = cHosterGui().checkHoster(sHosterUrl)

    if (oHoster != False):
        

        
        
        
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumbnail)

    oGui.setEndOfDirectory()
    