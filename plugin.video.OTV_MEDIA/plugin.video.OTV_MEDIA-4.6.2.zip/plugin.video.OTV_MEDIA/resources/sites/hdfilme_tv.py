#-*- coding: utf-8 -*-
import urllib2, urllib,cookielib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, zipfile, re, stat, xbmcvfs, base64
from resources.lib.otvhelper import  gegetUrl,getUrl ,alfabekodla
from resources.lib.config import cConfig
import requests
import re,xbmcgui,unicodedata              
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress, VSlog
from resources.lib.player import cPlayer
from resources.lib.kplayer  import Player
from resources.lib.gui.guiElement import cGuiElement

SITE_IDENTIFIER = 'hdfilme_tv'
SITE_NAME = 'HDfilme'
SITE_DESC = 'Replay TV'
MOVIE_diziizle = 'http://www.diziizle.net/sinemalar/'
import urllib2,urllib,cgi, re
import cookielib
cj = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
HEADER_USER_AGENT = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
from core import httptools

BASE_URL = 'https://hdfilme.cc/'
ALMAN_SINEMA = (True, 'showGenre')
baseurl = 'https://hdfilme.cc'
streamurl = 'https://hdfilme.cc/filme1?page=1'
serienurl = 'https://hdfilme.cc/serien1?page=1'
URL_MAIN = 'https://hdfilme.net'
URL_MOVIES = 'https://hdfilme.cc/filme1?page=1'
URL_SHOWS =  'https://hdfilme.cc/serien1?page=1'
URL_SEARCH = URL_MAIN + '/search?key=%s'

addon = xbmcaddon.Addon(id='plugin.video.OTV_MEDIA')                                                                                                        
s = requests.Session()
jsUrl='https://ajax.cloudflare.com/cdn-cgi/scripts/a2bd7673/cloudflare-static/rocket-loader.min.js'

def msEcho():                                                                                       
    js =cRequestHandler(jsUrl).request()
    
#    js = re.findall('(.*?)', data, re.S)    
    urljs = str(js2py.eval_js(js))
    return urljs


def sEcho(s):
    if not '?page=' in s:
        s = s +'?page=1'
    if '=1' in s:
        s = s.replace('=1', '=2')
        return s
    if '=2' in s:
        s = s.replace('=2', '=3')
        return s
    if '=3' in s:
        s = s.replace('=3', '=4')
        return s
    if '=4' in s:
        s = s.replace('=4', '=5')
        return s
    if '=5' in s:
        s = s.replace('=5', '=6')
        return s
    if '=6' in s:
        s = s.replace('=6', '=7')
        return s
    if '=7' in s:
        s = s.replace('=7', '=8')
        return s
    if '=8' in s:
        s = s.replace('=8', '=9')
        return s
    if '=9' in s:
        s = s.replace('=9', '=10')
        return s
    if '=10' in s:
        s = s.replace('=10', '=11')
        return s
    if '=11' in s:
        s = s.replace('=11', '=12')
        return s
    if '=12' in s:
        s = s.replace('=12', '=13')
        return s
    if '=13' in s:
        s = s.replace('=13', '=14')
        return s
    if '=14' in s:
        s = s.replace('=14', '=15')
        return s
    if '=15' in s:
        s = s.replace('=15', '=16')
        return s
    if '=16' in s:
        s = s.replace('=16', '=17')
        return s
    if '=17' in s:
        s = s.replace('=17', '=18')
        return s
    if '=18' in s:
        s = s.replace('=18', '=19')
        return s
    if '=19' in s:
        s = s.replace('=19', '=20')
        return s
    if '=20' in s:
        s = s.replace('=20', '=21')
        return s
    if '=21' in s:
        s = s.replace('=21', '=22')
        return s
    if '=22' in s:
        s = s.replace('=22', '=23')
        return s
    if '=23' in s:
        s = s.replace('=23', '=24')
        return s
    if '=24' in s:
        s = s.replace('=24', '=25')
        return s
    if '=25' in s:
        s = s.replace('=25', '=26')
        return s
    if '=26' in s:
        s = s.replace('=26', '=27')
        return s
    if '=27' in s:
        s = s.replace('=27', '=28')
        return s
    if '=28' in s:
        s = s.replace('=28', '=29')
        return s
    if '=29' in s:
        s = s.replace('=29', '=30')
        return s
    if '=30' in s:
        s = s.replace('=30', '=31')
        return s
    if '=31' in s:
        s = s.replace('=31', '=32')
        return s
    if '=32' in s:
        s = s.replace('=32', '=33')
        return s
    if '=33' in s:
        s = s.replace('=33', '=34')
        return s
    if '=34' in s:
        s = s.replace('=34', '=35')
        return s
    if '=35' in s:
        s = s.replace('=35', '=36')
        return s
    if '=36' in s:
        s = s.replace('=36', '=37')
        return s
    if '=37' in s:
        s = s.replace('=37', '=38')
        return s
    if '=38' in s:
        s = s.replace('=38', '=39')
        return s
    if '=39' in s:
        s = s.replace('=39', '=40')
        return s
    if '=40' in s:
        s = s.replace('=40', '=41')
        return s
    if '=41' in s:
        s = s.replace('=41', '=42')
        return s
    if '=42' in s:
        s = s.replace('=42', '=43')
        return s
    if '=43' in s:
        s = s.replace('=43', '=44')
        return s
    if '=44' in s:
        s = s.replace('=44', '=45')
        return s
    if '=45' in s:
        s = s.replace('=45', '=46')
        return s
    if '=46' in s:
        s = s.replace('=46', '=47')
        return s
    if '=47' in s:
        s = s.replace('=47', '=48')
        return s
    if '=48' in s:
        s = s.replace('=48', '=49')
        return s
    if '=49' in s:
        s = s.replace('=49', '=50')
        return s
    return False
           

def showSearch():
    oGui = cGui()
    sSearchText = oGui.showKeyBoard()
    if sSearchText != False:
        sUrl = 'https://hdfilme.cc/search?key=' + sSearchText
        sUrl = sUrl.replace(' ', '%20')
        searchowMovies(sUrl)
        oGui.setEndOfDirectory()
        return
        

def load():
    
    oGui = cGui()
    from resources.lib.handler.ParameterHandler import ParameterHandler
    params = ParameterHandler()
    params.setParam('siteUrl', URL_MOVIES)
    oGui.addFolder(cGuiElement('Filme', SITE_IDENTIFIER, 'showMenu'), params)
    params.setParam('siteUrl', URL_SHOWS)
    oGui.addFolder(cGuiElement('Serien', SITE_IDENTIFIER, 'sshowMenu'), params)
    
    oGui.addFolder(cGuiElement('Suche', SITE_IDENTIFIER, 'showSearch'))
    oGui.setEndOfDirectory()
def sshowMenu():
    oGui = cGui()
    from resources.lib.handler.ParameterHandler import ParameterHandler
    params = ParameterHandler()
    baseURL = params.getValue('siteUrl')
    params.setParam('siteUrl',serienurl )
    oGui.addFolder(cGuiElement('Neu hinzugefügt', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('siteUrl', serienurl )
    oGui.addFolder(cGuiElement('Herstellungsjahr', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('siteUrl', serienurl )
    oGui.addFolder(cGuiElement('Alphabetisch', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('siteUrl', serienurl )
    oGui.addFolder(cGuiElement('Top Aufrufe', SITE_IDENTIFIER, 'mshowEntries'), params)
    params.setParam('siteUrl', serienurl)
    oGui.addFolder(cGuiElement('IMDB Punkt', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('siteUrl', serienurl )
    oGui.addFolder(cGuiElement('Bewertung HDFilme', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('siteUrl', serienurl)
    oGui.addFolder(cGuiElement('country Genre', SITE_IDENTIFIER, 'LandGenre'), params)

    params.setParam('siteUrl', serienurl)
    oGui.addFolder(cGuiElement('Genre', SITE_IDENTIFIER, 'showGenre'), params)
    oGui.setEndOfDirectory()


def showMenu():
    oGui = cGui()
    from resources.lib.handler.ParameterHandler import ParameterHandler
    params = ParameterHandler()
    baseURL = params.getValue('siteUrl')
    params.setParam('siteUrl',streamurl )
    oGui.addFolder(cGuiElement('Neu hinzugefügt', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('siteUrl', streamurl )
    oGui.addFolder(cGuiElement('Herstellungsjahr', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('siteUrl', streamurl )
    oGui.addFolder(cGuiElement('Alphabetisch', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('siteUrl', streamurl )
    oGui.addFolder(cGuiElement('Top Aufrufe', SITE_IDENTIFIER, 'mshowEntries'), params)
    params.setParam('siteUrl', streamurl )
    oGui.addFolder(cGuiElement('IMDB Punkt', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('siteUrl', streamurl )
    oGui.addFolder(cGuiElement('Bewertung HDFilme', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('siteUrl', streamurl)
    oGui.addFolder(cGuiElement('country Genre', SITE_IDENTIFIER, 'LandGenre'), params)

    params.setParam('siteUrl', streamurl)
    oGui.addFolder(cGuiElement('Genre', SITE_IDENTIFIER, 'showGenre'), params)
    oGui.setEndOfDirectory()

def ddizizleABC():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    urll = oInputParameterHandler.getValue('siteUrl')
    url = HTTPKIR(urll)
    name = 'test'
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]' + name, url, '')


def addLink(name, url, iconimage):
    ok = True
    liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title': name})
    liz.setProperty('IsPlayable', 'true')
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=str(url), listitem=liz)
    xbmc.Player().play(url, liz)
    sys.exit()
    return ok


def LandGenre():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    sHtmlContent =cRequestHandler(url).request()
    sHtmlContent = sHtmlContent.replace('\\s', '').replace('\r', '').replace('\n', '')
    oParser = cParser()
    sPattern = 'name="country">(.*?)</select>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    sHtmlContent = aResult
    sPattern = '<option value="(.*?)">(.*?)</option>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if not aResult[0] == False:
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            myMode = 'sort'
            sTitle = aEntry[1]
            sPicture = aEntry[0]
            sUrl = str(aEntry[0])
          
            sTitle = alfabekodla(sTitle)
            Url = '&category=&country=%s&sort=&key=&sort_type=desc' % (sUrl)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', url)
            oOutputParameterHandler.addParameter('sitesm', Url)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture)
            oGui.addMovie(SITE_IDENTIFIER, 'lhowGenre', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)
    oGui.setEndOfDirectory()
def lhowGenre():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    site = oInputParameterHandler.getValue('sitesm')
    sHtmlContent = cRequestHandler(url).request()
    sHtmlContent = sHtmlContent.replace('\\s', '').replace('\r', '').replace('\n', '')
    oParser = cParser()
    sPattern = '>Genre</option>(.*?)</select>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    sHtmlContent = aResult
    sPattern = '<option value="(.*?)">(.*?)</option>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if not aResult[0] == False:
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            sTitle = aEntry[1]
            sPicture = aEntry[0]
            sUrl = str(aEntry[0])
            sTitle = alfabekodla(sTitle)
            site = site.replace('category=&', 'category=%s&')
            Url = url+site % (sUrl)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', Url)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture)
            oGui.addMovie(SITE_IDENTIFIER, 'Movies', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)
       
    oGui.setEndOfDirectory()


def showGenre():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    sHtmlContent = cRequestHandler(url).request()
    sHtmlContent = sHtmlContent.replace('\\s', '').replace('\r', '').replace('\n', '')
    oParser = cParser()
    sPattern = '>Genre</option>(.*?)</select>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    sHtmlContent = aResult
    sPattern = '<option value="(.*?)">(.*?)</option>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if not aResult[0] == False:
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            sTitle = aEntry[1]
            sPicture = aEntry[0]
            sUrl = str(aEntry[0])
            sTitle = alfabekodla(sTitle)
          
            
            Url = url+'&category=%s&country=germany&sort=&key=&sort_type=desc' % (sUrl)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', Url)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture)
            oGui.addMovie(SITE_IDENTIFIER, 'Movies', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)
    
    oGui.setEndOfDirectory()
    
def Movies():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()                                                                
    sUrl = oInputParameterHandler.getValue('siteUrl')
    
        
   
                      
    
    postdata='load=full-page'

    
    sHtmlContent =cRequestHandler(sUrl,postdata).postrequest()    
    oParser = cParser()
#    sPattern = '<div class="body-section">(.*?)<div class="title-product">'
#    aResult = oParser.parse(sHtmlContent, sPattern)
#    sHtmlContent = aResult            
    sPattern = '<div class="box-product clearfix" data-popover.*?href="([^"]+).*?data-src="([^"]+).*?title=".*?">([^<]+)'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if not aResult[0] == False:
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            sTitle = aEntry[2]
            sPicture = aEntry[1]
            sUrl = str(aEntry[0])
            sTitle = alfabekodla(sTitle)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture)
            oGui.addMovie(SITE_IDENTIFIER, 'MOVIEHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)
        sNextPage = sEcho(str(sUrl))
        if sNextPage != False:
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'Movies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

    
def searchowMovies(sUrl):
    oGui = cGui()
    data = cRequestHandler(sUrl).request()       
    
    sHtmlContent = re.findall('<div class="box-product clearfix" data-popover="movie-data-popover-.*?">.*?href="([^"]+).*?data-src="([^"]+).*?title=".*?">([^<]+)', data, re.S)
    for sUrl, sPicture, sTitle in sHtmlContent:
        sTitle = alfabekodla(sTitle)
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
        oGui.addMovie(SITE_IDENTIFIER, 'MOVIEHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def showSHOW(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sSearch = urllib2.unquote(sSearch)
        query_args = {'do': 'search',
         'subaction': 'search',
         'story': str(sSearch),
         'x': '0',
         'y': '0'}
        data = urllib.urlencode(query_args)
        headers = {'User-Agent': 'Mozilla 5.10'}
        url = 'http://hdfilme.tv/'
        request = urllib2.Request(url, data, headers)
        try:
            reponse = urllib2.urlopen(request)
        except URLError as e:
            print e.read()
            print e.reason

        sHtmlContent = reponse.read()
        sPattern = '<div class="box-product clearfix" data-popover="movie-data-popover-(.*?)">.*?<img class="img" src="(.*?)" onerror="this.src=.*?" alt="(.*?)">'
    else:
        oInputParameterHandler = cInputParameterHandler()
        url = oInputParameterHandler.getValue('siteUrl')
        postdata='load=full-page'

    
        sHtmlContent =cRequestHandler(sUrl,postdata).postrequest()
    sPattern = '<div class="box-product clearfix" data-popover.*?href="([^"]+).*?data-src="([^"]+).*?title=".*?">([^<]+)'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if not aResult[0] == False:
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            sTitle = cUtil().unescape(aEntry[3]) + '-episode-' + aEntry[4]
            sPicture = str(aEntry[2])
            Url = str(aEntry[1])
            Urlid = str(aEntry[0])
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', Url)
            oOutputParameterHandler.addParameter('siteid', Urlid)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture)
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/anime/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'Moviesshow', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)
        if not sSearch:
            sNextPage = sEcho(str(url))
            if sNextPage != False:
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showSHOW', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
    if not sSearch:
        oGui.setEndOfDirectory()


def Moviesshow():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    Urlid = oInputParameterHandler.getValue('siteid')
    sPicture = oInputParameterHandler.getValue('sThumbnail')
    url = oInputParameterHandler.getValue('siteUrl')
   
    data =  cRequestHandler(url).request()
    sHtmlContent = re.findall('class="new.*?-([\d]+)-stream.*?data-episode-id="([\d]+).*?([\d]+)', data, re.S)
    for sUrl, sTitle in sHtmlContent:
        sTitle = 'episode : ' + sTitle
        Urll = 'https://hdfilme.cc/movie/load-stream/' + Urlid + '/' + sUrl
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', Urll)
        oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
        oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def mshowEntries(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sSearch = urllib2.unquote(sSearch)
        query_args = {'do': 'search',
         'subaction': 'search',
         'story': str(sSearch),
         'x': '0',
         'y': '0'}
        data = urllib.urlencode(query_args)
        headers = {'User-Agent': 'Mozilla 5.10'}
        url = 'http://hdfilme.tv/'
        request = urllib2.Request(url, data, headers)
        try:
            reponse = urllib2.urlopen(request)
        except URLError as e:
            print e.read()
            print e.reason

        sHtmlContent = reponse.read()
        sPattern = '<div class="box-product clearfix" data-popover="movie-data-popover-(.*?)">.*?<img class="img" src="(.*?)" onerror="this.src=.*?" alt="(.*?)">'
    else:
        oInputParameterHandler = cInputParameterHandler()
        url = oInputParameterHandler.getValue('sUrl')
        sHtmlContent = cRequestHandler(url).request()
    sPattern = '<div class="box-product clearfix">.*?href="([^"]+).*?data-src="([^"]+).*?title=".*?">([^<]+)'
    sHtmlContent = sHtmlContent
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if not aResult[0] == False:
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            sTitle = cUtil().unescape(aEntry[2])
            sPicture = str(aEntry[1])
            Url = str(aEntry[0])
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', Url)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/anime/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'MOVIEHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)
        if not sSearch:
            sNextPage = sEcho(str(url))
            if sNextPage != False:
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
    if not sSearch:
        oGui.setEndOfDirectory()


def showEntries():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    postdata='load=full-page'

    sHtmlContent =cRequestHandler(url,postdata).postrequest()
    sPattern = '<div class="box-product clearfix" data-popover.*?href="([^"]+).*?data-src="([^"]+).*?title=".*?">([^<]+)'
    sHtmlContent = sHtmlContent
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if not aResult[0] == False:
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            sTitle = cUtil().unescape(aEntry[2])
            sPicture = str(aEntry[1])
            Url = str(aEntry[0])
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', Url)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/anime/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'MOVIEHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)
        
        sNextPage = sEcho(str(url))
        if sNextPage != False:
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showEntries', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def __NextPage(sHtmlContent, url):
    sPattern = '<li class="active">.*?<a href="javascript:void(0)" data-page="(.*?)">'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0] == True:
        url = url + '?page=' + aResult[1][0]
        if 'desc' in url:
            url = url + '&page=' + aResult[1][0]
        return str(url)


def __checkForNextPage(sHtmlContent):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sPattern = '</a> <a href="(.*?)" class="syfno">Sonraki Sayfa &raquo;</a>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0] == True:
        return str(sUrl) + aResult[1][0]
    return False


def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    Url = oInputParameterHandler.getValue('siteUrl')
    Urlk = 'https://hdfilme.cc'
    referer = [('Referer', Urlk)]
    adata = gegetUrl(Url, headers=referer)
    cookie = getUrl(Url, output='cookie').result
    sHtmlContent = base64.b64decode(adata)
    sPattern = '"file":"(.*?)","label":"(.*?)"'              
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0] == True:
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
                     
            sTitle =aEntry[1]
            sUrl = aEntry[0].replace('\\/', '/') + TUK
            if not 'http' in sUrl:
                sUrl = 'https:'+ sUrl 
            sTitle = alfabekodla(sTitle)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oGui.addTV(SITE_IDENTIFIER, 'play__hdfilme', sTitle, '', '', '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)
    oGui.setEndOfDirectory()


def MOVIEHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    URL = oInputParameterHandler.getValue('siteUrl')
    sHtmlContent = cRequestHandler(URL).request()
#    pattern = 'class="new.*?-([\d]+)-stream.*?data-episode-id="([\d]+).*?([\d]+)'
    oParser = cParser()
    eID = re.findall('data-episode-id="(.*?)"', sHtmlContent )
    sID = re.findall('data-movie-id="(.*?)"', sHtmlContent )
                            
#    total = len(aResult)
   
    Url = 'https://hdfilme.cc/movie/load-stream/' + sID[0] + '/' + eID[0] +  '?'
    hUrl =miptvplay_info(Url,URL)
    url = cParser().urlparse(hUrl)
    oRequest = cRequestHandler(hUrl)
    sHtmlContent = oRequest.request()
    url = cParser().urlparse(hUrl)
    sPattern = 'RESOLUTION=\d+x([\d]+)([^#]+)'        
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0] == True:
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
           
            sGenre = cUtil().unescape(aEntry[0])
            sUrl = aEntry[1]
            
            if not 'http' in sUrl:
                sUrl = 'http://' +url+ sUrl  

            
            sTitle = aEntry[1].decode('latin-1').encode('utf-8')
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sMovieTitle', sGenre)
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oGui.addTV(SITE_IDENTIFIER, 'play__hdfilme', sGenre, '', '', '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)
    oGui.setEndOfDirectory()


def play__hdfilme():
 
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    title = oInputParameterHandler.getValue('sMovieTitle')
   
    url =url+ '|' + 'Origin=https%3A%2F%2Fhdfilme.net%2F&Accept-Language=de-de,de;q=0.8,en-us;q=0.5,en;q=0.3&Accept-Encoding=gzip&Referer=https%3A%2F%2Fhdfilme.net%2F'
   
    aaddLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+title,url,'')
                                                                                            

def addLink(sTitle,sUrl,iconimage):
    from resources.lib.pplayer import cPlayer
    sTitle = alfabekodla(sTitle)
    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sTitle)
    oGuiElement.setMediaUrl(sUrl)
    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    oPlayer.startPlayer()


def mshowHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    streamid = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    sUrl = getStreamSRC(streamid)
    sHosterUrl = sUrl
    oHoster = cHosterGui().checkHoster(sHosterUrl)
    if oHoster != False:
        sMovieTitle = cUtil().DecoTitle(sMovieTitle)
        oHoster.setDisplayName(sMovieTitle)
        oHoster.setFileName(sMovieTitle)
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumbnail)
        
  
  
    oGui.setEndOfDirectory()
    
def kodu(iyi):
    while iyi!=[0]:
      
      iyi=iyi
      return iyi


def miptvplay_info(Url,URL): #affiche les genres
    
            
            oRequest = cRequestHandler(Url)
            oRequest.addHeaderEntry('Referer', URL)
#            oRequest.addHeaderEntry('Accept', 'text/html, */*; q=0.01')
#            oRequest.addHeaderEntry('Accept-Language', 'en-US,en;q=0.5')
#            oRequest.addHeaderEntry('Host', 'www.hdfilme.net')
#            oRequest.addHeaderEntry('Connection', 'keep-alive')
            oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
#            oRequest.addHeaderEntry('Connection', 'keep-alive')
            url = oRequest.request()
            url= url.replace('\r', '')
            url= url.replace('\s', '')
            url= url.replace('\n', '')
            Url = re.findall('window.urlVideo = "(.*?)"',  OTVye().OTVgir(url), re.S)[0]  
            return Url 

def aaddLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")                                                                  	

        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok  

 
def mmmMovies():
    
 
                                                                  
    oInputParameterHandler = cInputParameterHandler()                                                                
    sUrl = oInputParameterHandler.getValue('sUrl')
    post_data = {"page": "5"}
    url= scraper.get(sUrl)
    
#    url=scraper.get(sUrl).content
    name = 'https'
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url ,'')  
