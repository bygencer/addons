#-*- coding: utf-8 -*-
import urllib2, urllib,cookielib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, zipfile, re, stat, xbmcvfs, base64
from resources.lib.otvhelper import  gegetUrl,getUrl ,alfabekodla
from resources.lib.config import cConfig
import requests
import re,xbmcgui,unicodedata              
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress, VSlog
from resources.lib.player import cPlayer
from resources.lib.kplayer  import Player
from resources.lib.gui.guiElement import cGuiElement

SITE_IDENTIFIER = 'kanald_com_tr'
SITE_NAME = 'KANAL D'
SITE_DESC = 'Replay TV'
NURL_MAIN= 'http://www.netd.com'
MOVIE_diziizle = 'https://www.kanald.com.tr'
URL_MAIN = 'http://www.netd.com/dizi'
URL_DMAIN = 'https://www.kanald.com.tr'
URL_PIC = 'http://assets.dogannet.tv/img/75/327x183/'
MOVIE_VIEWS = (True, 'showGenre')
MOVIE_HD = (True, 'showGenre')
URL_engelsiz = 'http://engelsiz.kanald.com.tr'
URL_engelsizpic = 'http://engelsiz.kanald.com.tr/'                  
def CleanTitle(title):
    title = cUtil().unescape(title)
    title = cUtil().removeHtmlTags(title)
    try:
        #title = unicode(title, 'utf-8')
        title = unicode(title, 'iso-8859-1')
    except:
        pass
    title = unicodedata.normalize('NFD', title).encode('ascii', 'ignore')
    
    return title.encode( "utf-8")
ua = "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36"

import requests
s = requests.Session()
def BluEcho(s):
      s=s
      if '=0' in s:
	s=s.replace('=0','=24')
        return s 
      if '=24' in s:	
        s=s.replace('=24','=48')
        return s 
      if '=48' in s:	
        s=s.replace('=48','=72')
        return s 
      if '=72' in s:	
        s=s.replace('=72','=96')
        return s 
      if '=96' in s:	
        s=s.replace('=96','=120')
        return s 
      if '=120' in s:	
        s=s.replace('=120','=144')
        return s 
      if '=144' in s:	
        s=s.replace('=144','=168')
        return s 
      return False 



def turkTV():
        oGui = cGui()
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://')
        oGui.addDir('fox_com_tr', 'foxcomtr', 'FOX TV Sayfa', 'fox_com_tr.png', oOutputParameterHandler)

        
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://')
        oGui.addDir(SITE_IDENTIFIER, 'kanald', 'Kanal D Sayfa', 'kanald_com_tr.png', oOutputParameterHandler)

        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://')
        oGui.addDir('atv_com_tr', 'atvcomtr','ATV Sayfa', 'startv_com_tr.png', oOutputParameterHandler)


        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://')
        oGui.addDir('showtv_com_tr', 'showtvcomtr','SHOW TV Sayfa', 'showtv_com_tr.png', oOutputParameterHandler)
        
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://')
        oGui.addDir('tv8_com_tr', 'tv8comtr','TV 8 Sayfa', 'tv8_com_tr.png', oOutputParameterHandler)
        
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://')
        oGui.addDir('trt_net_tr', 'trtnettr', 'TRT Sayfa', 'trt_net_tr.png', oOutputParameterHandler)
        
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://')
        oGui.addDir('startv_com_tr', 'startvcomtr','STAR TV Sayfa', 'startv_com_tr.png', oOutputParameterHandler)
        
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://')
        oGui.addDir(SITE_IDENTIFIER, 'blutv', 'BluTV Sayfa', 'BluTV_Logo.png', oOutputParameterHandler)
          
        
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'https://www.kanald.com.tr/actions/content/media/542410a361361f36f4c3fcf1')
        oGui.addDir(SITE_IDENTIFIER, 'blutv_1','BLUTV Canli Yayin', 'BluTV_Logo.png', oOutputParameterHandler)
        
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://')
        oGui.addDir('xcanlitvzone', 'Canlitvzone','Canli TV zone', 'canlitvzone.png', oOutputParameterHandler)
        
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://')
        oGui.addDir('xCanLiTVlive', 'CanLiTVlive','Canli TV live', 'canlitvs.png', oOutputParameterHandler)
        
        
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://')
        oGui.addDir('xstreamcanlitv', 'iostreamcanlitv2','Canli TV live.IO', 'canliio.png', oOutputParameterHandler)
        oGui.setEndOfDirectory()

  
def blutv():
    oGui = cGui()
    tarzlistesi= []                                                                                                                                                  
    tarzlistesi.append(("Canli Yayin",  "https://www.kanald.com.tr/actions/content/media/542410a361361f36f4c3fcf1"))
    tarzlistesi.append(("Dizi",  "https://www.blutv.com.tr/quark/content/getresults?category=dizi&order=&platform=com.blu.lama&query=&segment=default&skip=0"))
    tarzlistesi.append(("Film",  "https://www.blutv.com.tr/quark/content/getresults?category=film&order=&platform=com.blu.lama&query=&segment=default&skip=0"))
    for sTitle,sUrl in tarzlistesi:
       
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        if 'Canli Yayin' in sTitle:
            oGui.addDir(SITE_IDENTIFIER, 'blutv_1', '[COLOR FFAFEEEE] '+ sTitle +'[/COLOR]', 'genres.png', oOutputParameterHandler)
        elif 'Dizi' in sTitle:
            oGui.addDir(SITE_IDENTIFIER, 'Diziblutv', '[COLOR FFAFEEEE]  '+ sTitle +'[/COLOR]', 'genres.png', oOutputParameterHandler)
        else:
            oGui.addDir(SITE_IDENTIFIER, 'blutv_d1', '[COLOR FFAFEEEE]'+ sTitle +'[/COLOR]', 'genres.png', oOutputParameterHandler)


       
    oGui.setEndOfDirectory()

def Diziblutv():
    oGui = cGui()
    tarzlistesi= []                                                                                                                                                  
    tarzlistesi.append(("Aile",  "tum-aile-dizileri"))
    tarzlistesi.append(("Aksiyon - Macera",  "tum-aksiyon-macera-dizileri"))
    tarzlistesi.append(("Drama",  "tum-drama-dizileri"))
    tarzlistesi.append(("Komedi",  "tum-komedi-dizileri"))
    tarzlistesi.append(("Polisiye - Suc - Macera",  "tum-polisiye-suc-dizileri"))
    tarzlistesi.append(("Romantik",  "tum-romantik-diziler"))

    for sTitle,sUrl in tarzlistesi:
        surl ="https://www.blutv.com.tr/quark/content/getresults?category=%s&order=&platform=com.blu.lama&query=&segment=default&skip=0"%  sUrl
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
        oOutputParameterHandler.addParameter('siteUrl', surl)
        if 'Canli Yayin' in sTitle:
            oGui.addDir(SITE_IDENTIFIER, 'blutv_1', '[COLOR FFAFEEEE] '+ sTitle +'[/COLOR]', 'genres.png', oOutputParameterHandler)
        elif '/sinemalar/' in sTitle:
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR FFAFEEEE]  '+ sTitle +'[/COLOR]', 'genres.png', oOutputParameterHandler)
        else:
            oGui.addDir(SITE_IDENTIFIER, 'blutv_d1', '[COLOR FFAFEEEE]'+ sTitle +'[/COLOR]', 'genres.png', oOutputParameterHandler)


       
    oGui.setEndOfDirectory()

def blutv_d1():
    oGui = cGui()
    


    
    oInputParameterHandler = cInputParameterHandler()
    item = oInputParameterHandler.getValue('siteUrl')
    sUrl= oInputParameterHandler.getValue('siteUrl')
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    
    sHtmlContent =sHtmlContent.replace('\\/', '/')
    oParser = cParser()
    sPattern = '"Title":"(.*?)","Name":".*?".*?"CustomUrl":"(.*?)","Target":null,"SelfPath":null,"CDN":".*?","Color":null,"SubTitle":null,"Image":"(.*?)"'
                                
    aResult = oParser.parse(sHtmlContent, sPattern)          
    
    if (aResult[0] == True):                                                                               
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
                
            Url=aEntry[1]
            Url =Url.replace('/', '%2F')
            surl ="https://www.blutv.com.tr/quark/content/getcontent?platform=com.blu.lama&segment=default&url="+   Url
            
            sTitle = aEntry[0]
            
       
            sTitle = alfabekodla(sTitle)
            img ="https://dhaym0822ddy8.cloudfront.net/q/t/i/bluv2/85/600x338/"+ aEntry[2]
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', surl)
            
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            
            if  'zamanlar-adanada' in aEntry[1]:
                oGui.addDir(SITE_IDENTIFIER, 'sifirbirchannel_list', sTitle, 'kanald_com_tr.png', oOutputParameterHandler)
            else: 
               oGui.addTV(SITE_IDENTIFIER, 'blutv_d2', sTitle, '',img, '', oOutputParameterHandler)
        cConfig().finishDialog(dialog)
        sNextPage =BluEcho(str(sUrl))#cherche la page suivante
        if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'blutv_d1', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()     
def blutv_d2():
    oGui = cGui()

    
    oInputParameterHandler = cInputParameterHandler()
    sUrl= oInputParameterHandler.getValue('siteUrl')
    
    oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('Referer', 'https://www.blutv.com.tr/')
    
    oRequest.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 10 Build/MOB31T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36')
    sHtmlContent = oRequest.request()
    
    sHtmlContent =sHtmlContent.replace('\\/', '/').replace('Url":null', 'Url"http://www.blutv.com.tr/media/5b4774c5866ac3040ce492ac.clear"')
    oParser = cParser()                                       
                                       
    sPattern = '"Poster":"(.*?)","Source":"(.*?)","Url"(.*?)".*?"SeasonNumber":(.*?),"StartDate":".*?","Title":"(.*?)"'
    aResult = oParser.parse(sHtmlContent, sPattern)          
    
    if (aResult[0] == True):                                                                               
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)                                                              
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
                
            
            surl = aEntry[1]
            if  'zamanlar-adanada/3-sezon' in aEntry[1]:
                 surl='https://blutv.akamaized.net/CHLS/SIFIR_BIR_SZN_'+ aEntry[3]+'_BLM_0'+ aEntry[4]+'_1080_RVZ/SIFIR_BIR_SZN_'+ aEntry[2]+'_BLM_0'+ aEntry[3]+'_1080_RVZ.m3u8'
                 #surl='https://apicache.blutv.com.tr/q/t/c/bluv2/5a00525dfbead333d44c1c3a.m3u8'
            elif  'zamanlar-adanada/1-sezon' in aEntry[1]:

                 surl='https://blutv.akamaized.net/CHLS/SIFIR_BIR_BIR_ZAMANLAR_ADANADA_S_1_B_1_2500_1_layer01/SIFIR_BIR_BIR_ZAMANLAR_ADANADA_S_1_B_1_2500_1_layer01.m3u8'
            
            
            sTitle ='Sezon-'+ aEntry[3]+' '+ aEntry[4]                                                           
            Referer = aEntry[2]
            sTitle = alfabekodla(sTitle)
            img = aEntry[0]
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', surl)
            oOutputParameterHandler.addParameter('Referer', Referer)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oGui.addTV(SITE_IDENTIFIER, 'play_Dblutv', sTitle, '',img, '', oOutputParameterHandler)
        cConfig().finishDialog(dialog)
        
    oGui.setEndOfDirectory()     


def mblutv_d2():
    oGui = cGui()

    
    oInputParameterHandler = cInputParameterHandler()
    sUrl= oInputParameterHandler.getValue('siteUrl')
  
    oRequestHandler = cRequestHandler(sUrl)
    sUrl = oRequestHandler.request()
    
    import requests,json
    open = requests.get(sUrl,headers={'User-Agent':'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 10 Build/MOB31T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36'}).text
    son = json.loads(open)
    
    for a in son['Model']:
            surl   = a['PlayUrl']
            sTitle = a['Title']
            img = a['Poster']
            
            
            name = a['SeasonNumber']
            catid   = a['EpisodeNumber']
	



#            if  'bir-zamanlar-adanada'in sUrl or '3' in aEntry[2]:
#                 surl='https://blutv.akamaized.net/CHLS/SIFIR_BIR_SZN_'+ aEntry[2]+'_BLM_0'+ aEntry[3]+'_1080_RVZ/SIFIR_BIR_SZN_'+ aEntry[2]+'_BLM_0'+ aEntry[3]+'_1080_RVZ.m3u8'
#                 surl='https://apicache.blutv.com.tr/q/t/c/bluv2/5a00525dfbead333d44c1c3a.m3u8'
            sTitle ='Sezon-'+ name+'  B�l�m-'+ catid                                                           
#            Referer = aEntry[1]
            sTitle = alfabekodla(sTitle)
#            img = aEntry[0]
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', surl)
            oOutputParameterHandler.addParameter('Referer', Referer)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oGui.addTV(SITE_IDENTIFIER, 'play_Dblutv', sTitle, '',img, '', oOutputParameterHandler)
      
        
    oGui.setEndOfDirectory()     

def blutv_3():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    UrlL = oInputParameterHandler.getValue('siteUrl')
    cooki = getUrl(UrlL, output='cookie').result
    Referer = oInputParameterHandler.getValue('Referer')
#    urllm = re.findall('(https.*?)/', urll[0])
    h = '|Referer=http://www.blutv.com.tr&User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36 OPR/41.0.2353.69'
    ua='Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
    Content=requests.get(UrlL,headers={'Cookie':cooki,'User-Agent':ua,'Referer':' https://www.blutv.com.tr/int/','Accept':'/*','Connection':'keep-alive','Origin': 'https://hdfilme.tv','Accept-Language': 'de,en-US;q=0.7,en;q=0.3'}).text
    Content = Content.replace(',AUDIO="aac",SUBTITLES="subs"', '')
    sHtmlContent = re.findall('#EXT-X-STREAM-INF:.*?,RESOLUTION=.*?x(.*?)\n(.*?)\n', Content, re.S)
    for sTitle,Url  in sHtmlContent:    

            
           
            Title = alfabekodla(sTitle)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sMovieTitle', Title)
            oOutputParameterHandler.addParameter('Referer', Referer)
            oOutputParameterHandler.addParameter('siteUrl', Url)
            oOutputParameterHandler.addParameter('UrlL', UrlL)
            oGui.addTV(SITE_IDENTIFIER, 'play_blutv', Title, '', '', '', oOutputParameterHandler)

        
    oGui.setEndOfDirectory()

def play_Dblutv():
        oGui = cGui()
        oInputParameterHandler = cInputParameterHandler()
        h = '|User-Agent=Mozilla/5.0 (Windows NT 10.0; rv:62.0) Gecko/20100101&Referer=https://hdfilme.tv/&Accept=/*&Connection=keep-alive&Origin=https://hdfilme.tv&Accept-Language=de,en-US;q=0.7,en;q=0.3'
        Referer = oInputParameterHandler.getValue('Referer')
      
        
        Url = oInputParameterHandler.getValue('siteUrl')#Referer:'+ Referer +'&User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0
#    ua='Mozilla/5.0 (Windows NT 10.0; rv:62.0) Gecko/20100101'
#    url=requests.get(urll,headers={'User-Agent':ua,'Referer':'https://hdfilme.tv/','Accept':'/*','Connection':'keep-alive','Origin': 'https://hdfilme.tv','Accept-Language': 'de,en-US;q=0.7,en;q=0.3'}).text
                                  
        sHosterUrl =Url+'|Refererr='+Referer+'&User-Agentr=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:61.0) Gecko/20100101 Firefox/'+Url
        sTitle = oInputParameterHandler.getValue('sMovieTitle')
              
        sTitle = alfabekodla(sTitle) 
        oGuiElement = cGuiElement()
        oGuiElement.setSiteName(SITE_IDENTIFIER)
        oGuiElement.setTitle(sTitle)
        oGuiElement.setMediaUrl(sHosterUrl)
        

        oPlayer = cPlayer()
        oPlayer.clearPlayList()
        oPlayer.addItemToPlaylist(oGuiElement)
        oPlayer.startPlayer()  

def blutv_1():
    oGui = cGui()
    
    
    oOutputParameterHandler = cOutputParameterHandler() 
    oOutputParameterHandler.addParameter('siteUrl', 'https://blutv-beta.akamaized.net/kanaldhd/kanaldhd.smil/playlist.m3u8') 
    oOutputParameterHandler.addParameter('Referer', 'http://www.blutv.com.tr/media/569cafd6058d024688a14441.clear')
    oGui.addMovie(SITE_IDENTIFIER, 'blutv_2',  'Kanal D', 'https://upload.wikimedia.org/wikipedia/tr/thumb/c/ca/Kanal_D_logo.svg/943px-Kanal_D_logo.svg.png', 'https://upload.wikimedia.org/wikipedia/tr/thumb/c/ca/Kanal_D_logo.svg/943px-Kanal_D_logo.svg.png', '', oOutputParameterHandler)

    #rajout listage film nouveauté   
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://blutv-beta.akamaized.net/tv8hd/tv8hd.smil/playlist.m3u8')
    oOutputParameterHandler.addParameter('Referer','http://www.blutv.com.tr/media/54773060f5ac7613f46f398b.clear')
    oGui.addMovie(SITE_IDENTIFIER, 'blutv_2',  'TV8 HD', 'https://img.tv8.com.tr/s/template/v2/img/tv8-logo.png', 'https://img.tv8.com.tr/s/template/v2/img/tv8-logo.png', '', oOutputParameterHandler)
        
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://blutv-beta.akamaized.net/tv8.5hd/tv8.5hd.smil/playlist.m3u8')
    oOutputParameterHandler.addParameter('Referer','http://www.blutv.com.tr/media/589c1396058d02b288a8cf71.clear')
    oGui.addMovie(SITE_IDENTIFIER, 'blutv_2',  'TV 8,5', 'https://www.haberoran.com/files/uploads/news/default/26-nisan-carsamba-tv-eff9539d4cb9c7959f38.png', 'https://www.haberoran.com/files/uploads/news/default/26-nisan-carsamba-tv-eff9539d4cb9c7959f38.png', '', oOutputParameterHandler)


    
    oInputParameterHandler = cInputParameterHandler()
    item = oInputParameterHandler.getValue('siteUrl')
    sUrl = 'https://www.blutv.com.tr/quark/content/getpage?platform=com.blu.lama&segment=default&url=%2Fcanli-yayin'
  
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    
    sHtmlContent =sHtmlContent.replace('\\/', '/')
    oParser = cParser()
    sPattern = '"SubTitle":null,"Image":"(.*?)".*?"Title":"(.*?)","ContentType":"application\/x-mpegURL","Poster":null,"Source":"(.*?)","Url":"(.*?)","DRM'
    aResult = oParser.parse(sHtmlContent, sPattern)          
    
    if (aResult[0] == True):                                                                               
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
                
            
            surl =  aEntry[2]
            sTitle = aEntry[1]
            Referer = aEntry[3]
            sTitle = alfabekodla(sTitle)
            img ="https://dhaym0822ddy8.cloudfront.net/q/t/i/bluv2/100/0x0/"+ aEntry[0]
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', surl)
            oOutputParameterHandler.addParameter('Referer', Referer)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oGui.addTV(SITE_IDENTIFIER, 'blutv_2', sTitle, '',img, '', oOutputParameterHandler)
        cConfig().finishDialog(dialog)
        
    oGui.setEndOfDirectory()     
def blutv_2():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    UrlL = oInputParameterHandler.getValue('siteUrl')
    cooki = getUrl(UrlL, output='cookie').result
    Referer = oInputParameterHandler.getValue('Referer')
    
    h = '|Referer=http://www.blutv.com.tr&User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36 OPR/41.0.2353.69'
    ua='Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
    Content=requests.get(UrlL,headers={'Cookie': cooki,'User-Agent': ua,'Referer': 'https://www.blutv.com.tr/','Accept':'/*','Connection':'keep-alive','Origin': 'https://www.blutv.com.tr','Accept-Language': 'de,en-US;q=0.7,en;q=0.3'}).text
    
#   hi = '|Host=2s1d0z.stream&User-Agent=Mozilla/5.0 (Windows NT 10.0; rv:62.0) Gecko/20100101&Referer=https://hdfilme.tv/&Accept=/*&Connection=keep-alive&Origin=https://hdfilme.tv&Accept-Language=de,en-US;q=0.7,en;q=0.3'
    
#    sPattern = '#EXT-X-STREAM-INF:BANDWIDTH=(.*?),RESOLUTION=(.*?)\n(.*?)\n'           
#    sPattern = '"file":"(.*?)".*?"label":"(.*?)"'             
    sHtmlContent = re.findall('#EXT-X-STREAM-INF:BANDWIDTH=.*?,RESOLUTION=.*?x(.*?)\n(.*?)\n', Content, re.S)
    for sTitle,Url  in sHtmlContent:          
                              

            
            UrlL =UrlL.replace('playlist.m3u8','').replace('https://blutv-beta.akamaized.net/','https://mn-nl.mncdn.com/blutv_live/')
            Uurl= UrlL+ Url
            Title = alfabekodla(sTitle)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sMovieTitle', Title)
            oOutputParameterHandler.addParameter('Referer', Referer)
            oOutputParameterHandler.addParameter('siteUrl', Uurl)
            oOutputParameterHandler.addParameter('UrlL', UrlL)
            oGui.addTV(SITE_IDENTIFIER, 'play_blutv', Title, '', '', '', oOutputParameterHandler)

        
    oGui.setEndOfDirectory()
        

def play_blutv():
        oGui = cGui()
        oInputParameterHandler = cInputParameterHandler()
        h = '|User-Agent=Mozilla/5.0 (Windows NT 10.0; rv:62.0) Gecko/20100101&Referer=https://hdfilme.tv/&Accept=/*&Connection=keep-alive&Origin=https://hdfilme.tv&Accept-Language=de,en-US;q=0.7,en;q=0.3'
        Referer = oInputParameterHandler.getValue('Referer')
        sUrl = oInputParameterHandler.getValue('UrlL')
#        sUrl =sUrl.replace('playlist.m3u8','')
        Url = oInputParameterHandler.getValue('siteUrl')#Referer:'+ Referer +'&User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0
#    ua='Mozilla/5.0 (Windows NT 10.0; rv:62.0) Gecko/20100101'
#    url=requests.get(urll,headers={'User-Agent':ua,'Referer':'https://hdfilme.tv/','Accept':'/*','Connection':'keep-alive','Origin': 'https://hdfilme.tv','Accept-Language': 'de,en-US;q=0.7,en;q=0.3'}).text
                                  
        sHosterUrl =Url+'|Refererr='+ Referer +'&User-Agentr=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:61.0) Gecko/20100101 Firefox/'+Url
        sTitle = oInputParameterHandler.getValue('sMovieTitle')
              
        sTitle = alfabekodla(sTitle) 
        oGuiElement = cGuiElement()
        oGuiElement.setSiteName(SITE_IDENTIFIER)
        oGuiElement.setTitle(sTitle)
        oGuiElement.setMediaUrl(sHosterUrl)
        

        oPlayer = cPlayer()
        oPlayer.clearPlayList()
        oPlayer.addItemToPlaylist(oGuiElement)
        oPlayer.startPlayer()  
def showSearch():
    oGui = cGui()

    sSearchText = oGui.showKeyBoard()
    if (sSearchText != False):
        #sSearchText = cUtil().urlEncode(sSearchText)
        sUrl = URL_SEARCH[0] + sSearchText+'/'
 
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return  

def app_login():
        
    UrlL='https://www.blutv.com.tr/diziler/yerli/sifir-bir-bir-zamanlar-adanada'
    Url = "https://stats.blutv.com/stats/pageview"
            

    data=json.dumps({"ai": "com.blu", "asi": "0e8f9186-38b0-402c-87f5-c9741babc208","av": "1.40.28","di": "21fae11e8a378aa3fa24cd4afcb91e306fa652c12f5e98a6b5d1de1c3adb20bd","re": "https://www.blutv.com.tr//media//59d4bfb4058d0212c4a6d884","sn": "/diziler/yerli/sifir-bir-bir-zamanlar-adanada","sr": "1536x864","ti": "","tv": "1.0.0","ui": "","uui": "6d9b48c5e666ba902cf1130d4379262cddfbaa624e6ea7a0bb1b0675dafd1003"})
#        headers={"Content-Type": "application/json","Origin": "https://www.blutv.com.tr","Referer": "https://www.blutv.com.tr/int/diziler/yerli/sifir-bir-bir-zamanlar-adanada","User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Mobile Safari/537.36"}
#        url =requests.get(urll, headers=headers )
#            url = net.http_POST(urll, info).content 
    name='http://media.netd.com.tr/'
#    query_args = (('do', 'search'), ('subaction', 'search'), ('story', sSearch), ('titleonly', '3'))

    cooki = getUrl(UrlL, output='cookie').result

#    urllm = re.findall('(https.*?)/', urll[0])
    h = '|Referer=http://www.blutv.com.tr&User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36 OPR/41.0.2353.69'
    ua='Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
    url=s.post(Url, data=data,headers={'Cookie':cooki,'User-Agent':ua,'Referer':UrlL,'Origin': 'https://hdfilme.tv','Accept-Language': 'de,en-US;q=0.7,en;q=0.3'}).text
        
        
        
        
       
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')
            

def sifirbirchannel_list():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url =  "https://dl.dropboxusercontent.com/s/1cq9anwx0lfv27g/sh.xml"                             
    
  
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'}
    data = requests.get(url, headers = headers).text
    data =data.replace('[COLOR blue]D[/COLOR]ONATION [COLOR blue]RS[/COLOR]IPTV',"")                              
                                         
    datadata= re.findall('<string name="s6023767_seccs">(.*?)</string>',data, re.S)
    datadata=str(datadata).replace('>',",").replace('<',",")                                 
                  
    title= re.findall('(\d+)',datadata, re.S)
    for dat in title:
               
                          sTitle= re.findall('<string name="s'+dat+'_tit">(.*?)</string>',data, re.S)[0] 
                          sTitle = alfabekodla(sTitle).replace('[COLOR blue]A[/COLOR]UTO',"")
                          
                          
                          sUrl ='s' + dat
                          oOutputParameterHandler = cOutputParameterHandler()
                          oOutputParameterHandler.addParameter('siteUrl', sUrl)
                         
                          oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
                          oGui.addDir(SITE_IDENTIFIER, 'channellist', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory() 
def channellist():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    cat_id = oInputParameterHandler.getValue('siteUrl')
    url =  "https://dl.dropboxusercontent.com/s/1cq9anwx0lfv27g/sh.xml"                             
    
  
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'}
    data = requests.get(url, headers = headers).text
    data =data.replace('[COLOR blue]D[/COLOR]ONATION [COLOR blue]RS[/COLOR]IPTV',"")                              
                                         
    datadata= re.findall('<string name="'+cat_id+'_seccs">(.*?)</string>',data, re.S)
    datadata=str(datadata).replace('>',",").replace('<',",")                                 
                  
    title= re.findall('(\d+)',datadata, re.S)
    for dat in title:
                          
                          sTitle= re.findall('<string name="s'+dat+'_tit">(.*?)</string>',data, re.S)[0] 
                          sTitle = alfabekodla(sTitle).replace('[COLOR blue]A[/COLOR]UTO',"")
                          sUrl= re.findall('<string name="s'+dat+'_url">(.*?)</string>',data, re.S)[0] 
                          if 'yadi.sk' in sUrl:
                                headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'}
                                datak = requests.get(sUrl, headers = headers).text
                                sUrl= re.findall('"dimension":"adaptive","size":.*?,"url":"(.*?)"',datak, re.S)[0] 
                          oOutputParameterHandler = cOutputParameterHandler()
                          oOutputParameterHandler.addParameter('siteUrl', sUrl)
                         
                          oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
                          oGui.addDir(SITE_IDENTIFIER, 'pplay__rabictv', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory() 
   
def pplay__rabictv():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
#    sUrl = sUrl+"|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36"
    iconimage= oInputParameterHandler.getValue('sMovieTitle')
    name =  alfabekodla(sTitle)
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    
    Player().play(sUrl,liz)            



def partnext(s):
      s=s
      if 'part=1-6' in s:
	s=s.replace('part=1-6','part=1-6')
        return s 
      if 'part=1-6' in s:
	s=s.replace('part=1-6','part=2-6')
        return s 
      if 'part=2-6' in s:
	s=s.replace('part=2-6','part=3-6')
        return s 
      if 'part=3-6' in s:	
        s=s.replace('part=3-6','part=4-6')
        return s 
      if 'part=4-6' in s:	
        s=s.replace('part=4-6','part=5-6')
        return s 
      if 'part=5-6' in s:	
        s=s.replace('part=5-6','part=6-6')
        return s 
      return False 
def sEcho(s):
      s=s
      if '=1' in s:
	s=s.replace('=1','=2')
        return s 
      if '=2' in s:
	s=s.replace('=2','=3')
        return s 
      if '=3' in s:	
        s=s.replace('=3','=4')
        return s 
      if '=4' in s:	
        s=s.replace('=4','=5')
        return s 
      if '=5' in s:	
        s=s.replace('=5','=6')
        return s 
      if '=6' in s:	
        s=s.replace('=6','=7')
        return s 
      if '=7' in s:	
        s=s.replace('=7','=8')
        return s 
      if '=8' in s:	
        s=s.replace('=8','=9')
        return s 
      if '=9' in s:	
        s=s.replace('=9','=10')
        return s 
      if '=10' in s:	
        s=s.replace('=10','=11')
        return s 
      if '=11' in s:	
        s=s.replace('=11','=12')
        return s 
      if '=12' in s:	
        s=s.replace('=12','=13')
        return s 
      if '=13' in s:	
        s=s.replace('=13','=14')
        return s 
      if '=14' in s:	
        s=s.replace('=14','=15')
        return s 
      if '=15' in s:	
        s=s.replace('=15','=16')
        return s 
      if '=16' in s:	
        s=s.replace('=16','=17')
        return s
      if '=17' in s:	
        s=s.replace('=17','=18')
        return s 
      if '=18' in s:	
        s=s.replace('=18','=19')
        return s 
      if '=19' in s:	
        s=s.replace('=19','=20')
        return s 
      if '=20' in s:	
        s=s.replace('=20','=21')
        return s 
      if '=21' in s:	
        s=s.replace('=21','=22')
        return s 
      if '=22' in s:	
        s=s.replace('=22','=23')
        return s 
      if '=23' in s:	
        s=s.replace('=23','=24')
        return s 
      if '=24' in s:	
        s=s.replace('=24','=25')
        return s 
      if '=25' in s:	
        s=s.replace('=25','=26')
        return s 
      if '=26' in s:	
        s=s.replace('=26','=27')
        return s 
      if '=27' in s:	
        s=s.replace('=27','=28')
        return s 
      if '=28' in s:	
        s=s.replace('=28','=29')
        return s 
      if '=29' in s:	
        s=s.replace('=29','=30')
        return s 
      if '=30' in s:	
        s=s.replace('=30','=31')
        return s 
      if '=31' in s:	
        s=s.replace('=31','=32')
        return s 
      if '=32' in s:	
        s=s.replace('=32','=33')
        return s 
      if '=33' in s:	
        s=s.replace('=33','=34')
        return s 
      if '=34' in s:	
        s=s.replace('=34','=35')
        return s 
      if '=35' in s:	
        s=s.replace('=35','=36')
        return s 
      if '=36' in s:	
        s=s.replace('=36','=37')
        return s 
      if '=37' in s:	
        s=s.replace('=37','=38')
        return s 
      if '=38' in s:	
        s=s.replace('=38','=39')
        return s 
      if '=39' in s:	
        s=s.replace('=39','=40')
        return s 
      if '=40' in s:	
        s=s.replace('=40','=41')
        return s 
      if '=41' in s:	
        s=s.replace('=41','=42')
        return s 
      if '=42' in s:	
        s=s.replace('=42','=43')
        return s 
      if '=43' in s:	
        s=s.replace('=43','=44')
        return s 
      if '=44' in s:	
        s=s.replace('=44','=45')
        return s 
      if '=45' in s:	
        s=s.replace('=45','=46')
        return s 
      if '=46' in s:	
        s=s.replace('=46','=47')
        return s 
      if '=47' in s:	
        s=s.replace('=47','=48')
        return s 
      if '=48' in s:	
        s=s.replace('=48','=49')
        return s 
      if '=49' in s:	
        s=s.replace('=49','=50')
        return s 
      return False 


          

def kanald():
    oGui = cGui()
    tarzlistesi= []
    tarzlistesi.append(("KANAL D CANLI.TV", "http://orhantv"))
    
    
    tarzlistesi.append(("Yeni DIZILER", "https://www.kanald.com.tr/diziler"))
    tarzlistesi.append(("Tüm Arşiv Dizileri", "https://www.kanald.com.tr/diziler/arsiv"))
    tarzlistesi.append(("Görme ve Işitme Engelliler için DIZILER", "http://engelsiz.kanald.com.tr/"))
    for sTitle,sUrl2 in tarzlistesi:
        sTitle = alfabekodla(sTitle)   
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl2)
        if sTitle == 'KANAL D CANLI.TV':
             oGui.addDir(SITE_IDENTIFIER, 'kanaldTV', sTitle, 'genres.png', oOutputParameterHandler)

        elif sTitle == 'MUZIK':
             oGui.addDir(SITE_IDENTIFIER, 'showMUZIK', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'Yeni DIZILER':
             oGui.addDir(SITE_IDENTIFIER, 'pageshowMovies', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'Tüm Arşiv Dizileri':
             oGui.addDir(SITE_IDENTIFIER, 'dpageshowMovies', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'Görme ve Işitme Engelliler için DIZILER':
             oGui.addDir(SITE_IDENTIFIER, 'showengelsiz', sTitle, 'genres.png', oOutputParameterHandler)

        else:
             oGui.addDir(SITE_IDENTIFIER, 'pageshowMovies', sTitle, 'genres.png', oOutputParameterHandler)
                   
                    
    oGui.setEndOfDirectory()
  
def kanaldTV():
    oGui = cGui()
    tarzlistesi= []                                                                                                                                                  
    tarzlistesi.append(("Kanal D Canlı Yayın", "https://s.kanald.com.tr/ps/kanald_proxy/assets/img/kanal-d.png?v=2", "https://www.kanald.com.tr/actions/content/media/542410a361361f36f4c3fcf1"))
    tarzlistesi.append(("CNN T�RK Canlı Yayın", "http://i.cnnturk.com/ps/cnnturk_proxy/ContentMainPage/frontEnd/images/cnnturk-logo.png", "http://www.cnnturk.com/action/media/51cc1dbd32dc9f19b8bc77cf"))
    tarzlistesi.append(("TV2 Canlı Yayın", "http://www.tv2.com.tr/assets/img/logo.png", "http://www.teve2.com.tr/action/media/564da04ef5ac761dbc5e0a13"))
    tarzlistesi.append(("Dream Turk Canlı Yayın", "http://dreamq.dogannet.tv/images/100/800x450/571f37e3980ea80bc034ee2b", "http://dreamturk.com.tr/actions/content/media/566ab958980ea810b4658d96"))
    tarzlistesi.append(("Dream TV Canlı Yayın", "http://www.dreamtv.com.tr/content/frontEnd/images/dream-tv-logo.png", "http://www.dreamtv.com.tr/actions/content/media/5565d197f5ac76262cb2bba5"))
    tarzlistesi.append(("Tay TV Canlı Yayın", "http://www.dreamturk.com.tr/content/frontEnd/images/dream-turk-logo.png", "http://www.dreamtv.com.tr/actions/content/media/5565d197f5ac76262cb2bba5"))
    tarzlistesi.append(("Disney", "https://s.kanald.com.tr/ps/kanald_proxy/assets/img/d-smart-v2.png", "http://www.tv2.com.tr/actions/content/media/564da04ef5ac761dbc5e0a13"))
    for sTitle,sPicture,sUrl in tarzlistesi:
        sUrl = alfabekodla(sUrl)
        sTitle = alfabekodla(sTitle) 
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oGui.addMovie(SITE_IDENTIFIER, 'sshowBox2', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

       
    oGui.setEndOfDirectory()
        
def mshowengelsiz():       
        name='http://media.netd.com.tr/' 
        sUrl ='http://engelsiz.kanald.com.tr/'
   
        url = cRequestHandler(sUrl).request()  
        addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')
def showengelsiz(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'http://www.voirfilms.org/rechercher'
        request = urllib2.Request(url,data,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
        
 
        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern = '<div class="resim" id=".*?"><a href="(.*?)" title=".*?"><img src="(.*?)" width=".*?" height=".*?"  alt="(.*?)"'
                    
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl ='http://engelsiz.kanald.com.tr/'
   
        sHtmlContent = cRequestHandler(sUrl).request()                     
        
        
        sPattern = '<li><a href="(.*?)" title="(.*?)">.*?<img src="(.*?)"'
                



    
    #fh = open('c:\\test.txt', "w")                        
    #fh.write(sHtmlContent)
    #fh.close()
          
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
                  
            sTitle = aEntry[1]
            sPicture = str(aEntry[2])
            if not 'http' in sPicture:
                sPicture = str(URL_engelsizpic) + sPicture
                
            sUrl = str(aEntry[0])
            if not 'http' in sUrl:
                sUrl = str(URL_engelsiz) + sUrl
           
           
           
            sTitle = alfabekodla(sTitle)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', str(sPicture))
 
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/sinemalar/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'pageshowMovies', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'engelsizparca', sTitle, sPicture, sPicture,  'genres.png', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = __NextPage(sHtmlContent)#cherche la page suivante
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'engelsizparca', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()


def engelsizparca():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sPicture= oInputParameterHandler.getValue('sThumbnail')
    sHtmlContent = cRequestHandler(sUrl).request()
    sHtmlContent = sHtmlContent.replace('\t', '').replace('\r', '').replace('\n', '').replace('" selected>', '" >')
    parse = re.search('<div class="list">(.*?)</select>', sHtmlContent, re.S)
    if parse:
        cats = re.findall('<option value="(.*?)" >(.*?)</option>', parse.group(1), re.S)
	for tagid,sTitle in cats:

            
            wq = 'http://engelsiz.kanald.com.tr/Video/Detail/'+tagid+'/1'
            sTitle = alfabekodla(sTitle)
            
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', wq)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture)
            oGui.addMovie(SITE_IDENTIFIER, 'engelsizBox', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

        
    oGui.setEndOfDirectory()
def engelsizBox():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    Url = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    
    
    
    urla  = "https://www.kanald.com.tr"
     
                                      
    referer=[('Referer',urla)]
    data=gegetUrl(Url,headers=referer) 
    key= re.findall("key: '(.*?)'", data)[0]   
    Server= re.findall("url: '(mp4:engelsiz/.*?.mp4)'", data)[0]
    sUrl = "rtmp://213.243.32.91:1935/vod/%s" %( Server)
     
 
   
                                                                               
    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sTitle)
    oGuiElement.setMediaUrl(sUrl)
    

    #cConfig().log("Hoster - play " + str(sTitle))
    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    #tout repetter
    #xbmc.executebuiltin("xbmc.playercontrol(RepeatAll)")
    
    oPlayer.startPlayer()

def showMUZIK(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'http://www.voirfilms.org/rechercher'
        request = urllib2.Request(url,data,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
        
 
        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern = '<div class="resim" id=".*?"><a href="(.*?)" title=".*?"><img src="(.*?)" width=".*?" height=".*?"  alt="(.*?)"'
                    
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
   
        oRequestHandler = cRequestHandler(sUrl)
        sHtmlContent = oRequestHandler.request()                      
        
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '<noscript><img src="(.*?)".*?<a href="(.*?)">.*?<b>(.*?)</span>'
    
    sHtmlContent = sHtmlContent.replace('\n','')
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
          
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
                  
            sTitle = aEntry[2]+' [COLOR lightblue]'
            sPicture = str(aEntry[0])
            if not 'http' in sPicture:
                sPicture = str(URL_PIC) + sPicture
                
            sUrl = str(aEntry[1])
            if not 'http' in sUrl:
                sUrl = str(URL_MAIN) + sUrl
           
           
           
            sTitle = alfabekodla(sTitle)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('Picture', str(sTitle))
 
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/sinemalar/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'pageshowMovies', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'showMovies', sTitle, sPicture, sPicture,  'genres.png', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = __NextPage(sHtmlContent)#cherche la page suivante
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showMUZIK', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()

def showMovies():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    Url = oInputParameterHandler.getValue('siteUrl')

    urla  = "https://www.kanald.com.tr/"
                      
    referer=[('Referer',urla)]
    data=gegetUrl(Url,headers=referer) 
       
    streamDaten = re.findall('<i class="fa fa-fw fa-embed"></i></a><a class="flat action-add" data-id="(.*?)"', data, re.S) 
    sUrl = "http://www.netd.com/muzik/actions/music/getmusicvideo/%s"  % (streamDaten[0])       
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
        
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
    sPattern = '"Title":"(.*?)","Url":"(.*?)".*?"Image":"(.*?)"'
    
    sHtmlContent = sHtmlContent
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            sTitle = alfabekodla(aEntry[0])
            sPicture = str(aEntry[2])
            if not 'http' in sPicture:
                sPicture = str(URL_PIC) + sPicture
                
            sUrl = str(aEntry[1])
            if not 'http' in sUrl:
                sUrl = str(URL_MAIN) + sUrl
           
           
           
            
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oGui.addMovie(SITE_IDENTIFIER, 'sshowBox2', sTitle, sPicture, sPicture,  'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory()

def dpageshowMovies(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'http://www.voirfilms.org/rechercher'
        request = urllib2.Request(url,data,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
         
        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern = '<div class="film">.*?<a href="(.*?)" title=".*?"><img src="(.*?)" width=".*?" height=".*?"  alt="(.*?)"'
                    
    else:
        oInputParameterHandler = cInputParameterHandler()
        url = oInputParameterHandler.getValue('siteUrl')
        urla= ":https://www.kanald.com.tr/"
        referer=[('Referer',urla)]
             
        sHtmlContent=gegetUrl(url,headers=referer)           

                                                                      
                                                                                                                    
                                                                                                                    
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '<div id="tab-.*?" class="tab-pane">.*?<div class=".*?">.*?<a href="(.*?)" class="thumbnail" title=".*?">.*?<img src=".*?" data-src="(.*?)" alt="(.*?)" title="(.*?)"'
        
                                                     
                                                               
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    sHtmlContent = sHtmlContent.replace('u002F', "").replace('\\', "/")
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = aEntry[2]
            sPicture ='http:' +str(aEntry[1])
            
            sTitle = alfabekodla(sTitle)    
            sUrl = str(aEntry[0])
            if not 'http' in sUrl:
                sUrl = str(URL_DMAIN) + sUrl + '/bolumler?page=1'
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
          
 
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/sinemalar/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'pageshowMovies', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'pageshowDizi', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = __NextPage(sHtmlContent)#cherche la page suivante
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'pageshowMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()

def pageshowMovies(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'http://www.voirfilms.org/rechercher'
        request = urllib2.Request(url,data,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
         
        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern = '<div class="film">.*?<a href="(.*?)" title=".*?"><img src="(.*?)" width=".*?" height=".*?"  alt="(.*?)"'
                    
    else:
        oInputParameterHandler = cInputParameterHandler()
        url = oInputParameterHandler.getValue('siteUrl')
        urla= "https://www.kanald.com.tr/"
        referer=[('Referer',urla)]
             
        sHtmlContent=gegetUrl(url,headers=referer)           
        sHtmlContent = sHtmlContent.replace('&nbsp;', " saat:").replace('YAKINDA', "Yakinda Kanal D'de!")

                    
                                      
                     

        sPattern = '<div class="col-md-4 col-sm-4 col-xs-12 series-container-item clearfix">.*?<a href="(.*?)" title=".*?">.*?<img src="(.*?)" alt="(.*?)"'
        
    
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = aEntry[2]
            
           
            sPicture ='http:' +str(aEntry[1])
            
                
            sUrl = str(aEntry[0])
            if not 'http' in sUrl:
                sUrl = str(URL_DMAIN) + sUrl + '/bolumler?page=1'
                                                                
            sTitle = alfabekodla(sTitle)
                                                  
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', str(sUrl))
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('Picture', sPicture)
 
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/sinemalar/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'pageshowMovies', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'pageshowDizi', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = __NextPage(sHtmlContent)#cherche la page suivante
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'pageshowMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()




def pageshowDizi(sSearch = ''):
    oGui = cGui()
    
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'http://www.voirfilms.org/rechercher'
        request = urllib2.Request(url,data,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
         
        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern = '<div class="film">.*?<a href="(.*?)" title=".*?"><img src="(.*?)" width=".*?" height=".*?"  alt="(.*?)"'
                    
    else:
        
        oInputParameterHandler = cInputParameterHandler()
        Pagen = oInputParameterHandler.getValue('siteUrl')
        sPicture = oInputParameterHandler.getValue('Picture')
        sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
        if  'Yakinda' in sMovieTitle:
                showMessage("Yakinda Kanal D'de!")
           
                                             
       
        oRequestHandler = cRequestHandler(Pagen)
        sHtmlContent = oRequestHandler.request()       
#        sHtmlContent = sHtmlContent.replace('[]', "").replace('u002F', "").replace('\\', "/").replace('\u002Fp', "").replace('\u003C', "").replace('\u003Cp', "").replace('\u003E', "")
                                                                      
                                                                                                                                 
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '<div class="row">.*?<div class="col-lg-12">.*?<div class="bg clearfix">.*?<a href="(.*?)".*?data-src="(.*?)" alt="(.*?)"'
                                          
                                                               
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
                                                                                   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
           
                                                      
            
            sTitle = alfabekodla(aEntry[2])
                                                  
                           
#            sUrl ='http://www.netd.com'+ str(aEntry[1])+'/2500/prog_index.m3u8?'
            sPicture =  aEntry[1]
            sUrl ='https://www.kanald.com.tr'+ str(aEntry[0])
            if not 'http' in sUrl:
                sUrl ='https://www.kanald.com.tr'+ str(aEntry[1])
           
            
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            
            oGui.addTV(SITE_IDENTIFIER, 'DDizioynat', sTitle, '', sPicture, sPicture, oOutputParameterHandler)
        cConfig().finishDialog(dialog)
           
        if not sSearch:                                          
            
               sNextPage =sEcho(str(Pagen))
               if (sNextPage != False):
                  oOutputParameterHandler = cOutputParameterHandler()
                  oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                  oGui.addDir(SITE_IDENTIFIER, 'pageshowDizi2', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()
def DDizioynat():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    ua='Mozilla/5.0 (Linux; Android 6.0.1; Nexus 10 Build/MOB31T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36'
    
    Urll = oInputParameterHandler.getValue('siteUrl')
    name = oInputParameterHandler.getValue('sMovieTitle')
    Cooki = getUrl(Urll, output='cookie').result

    data=requests.get(Urll,headers={'Referer':Urll ,'Cookie':Cooki ,'User-Agent':ua}).text

       
   

    Server= re.findall('<link itemprop="embedURL" href="https://www.kanald.com.tr/embed/(.*?)" />', data)[0]  
    UUrl = "https://www.kanald.com.tr/actions/content/media/%s" %( Server)
                      
    urla= "https://www.kanald.com.tr/"
    referer=[('Referer',urla)]
             
    dat=gegetUrl(UUrl,headers=referer) 
    TIK='|User-Agent=Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'

    Serv= re.findall('"SecurePath":"(.*?)"', dat)[0]
    if not 'http' in Serv:
           sUrl = "https://soledge4.dogannet.tv//%s" %( Serv.replace('\u0026', "&").replace('&part=6-6', "&part=1-6"))  
    sUrl =sUrl+TIK                           
    playlist=xbmc.PlayList(xbmc.PLAYLIST_VIDEO); 
    playlist.clear();
    listitem1 = xbmcgui.ListItem(''+name)
    playlist.add(sUrl.replace('part=1-6','part=1-6'),listitem1);
    listitem2 = xbmcgui.ListItem(''+name)
    playlist.add(sUrl.replace('part=1-6','part=2-6'),listitem2);
    listitem3 = xbmcgui.ListItem(''+name)
    playlist.add(sUrl.replace('part=1-6','part=3-6'),listitem3);
    listitem4 = xbmcgui.ListItem(''+name)
    playlist.add(sUrl.replace('part=1-6','part=4-6'),listitem4);
    listitem5 = xbmcgui.ListItem(''+name)
    playlist.add(sUrl.replace('part=1-6','part=5-6'),listitem5);                                                                         
    listitem6 = xbmcgui.ListItem(''+name)
    playlist.add(sUrl.replace('part=1-6','part=6-6'),listitem6);
    
    player_type = sPlayerType()
    xbmcPlayer = xbmc.Player (player_type); 
    xbmcPlayer.play (playlist)       

def sPlayerType():
        
       
        oConfig = cConfig()
        sPlayerType = oConfig.getSetting('playerType')
        try:
            if (sPlayerType == '0'):
                cConfig().log("playertype from config: auto")
                return xbmc.PLAYER_CORE_AUTO

            if (sPlayerType == '1'):
                cConfig().log("playertype from config: mplayer")
                return xbmc.PLAYER_CORE_MPLAYER

            if (sPlayerType == '2'):
                cConfig().log("playertype from config: dvdplayer")
                return xbmc.PLAYER_CORE_DVDPLAYER
        except: return False

def __createDisplayStart(iPage):
    return (1 * int(iPage)) - 1
         
def pageshowDizi2():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    Url = oInputParameterHandler.getValue('siteUrl')
    
    urla  = "http://www.netd.com/"
                      
    referer=[('Referer',urla)]
    sHtmlContent=gegetUrl(Url,headers=referer)     
    

        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
#    sPattern = '"video":."description":".*?","title":"(.*?)","sys":.*?"domain_id":"(.*?)","membership_id":"netd".,"colors":.*?"uploadDate":".*?","_id":"(.*?)","metadata":."application".*?"value":"(.*?)"'
    sPattern = '"video":."description":".*?","title":"(.*?)".*?"value":"(.*?)".*?"_id":"(.*?)"'
  
    sHtmlContent = sHtmlContent.replace('u002F', "")
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            sTitle = alfabekodla(aEntry[0])
            sPicture = 'http://assets.dogannet.tv/img/75/327x183/'+ str(aEntry[2])
                           
#            sUrl ='http://www.netd.com'+ str(aEntry[1])+'/2500/prog_index.m3u8?'
            
           
           
            sUrl = str(aEntry[1])
            if not 'http' in sUrl:
                sUrl ='http://media.netd.com.tr/'+ str(aEntry[1])
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oGui.addMovie(SITE_IDENTIFIER, 'play__', sTitle, sPicture, sPicture,  'genres.png', oOutputParameterHandler)
        cConfig().finishDialog(dialog)
        sNextPage =sEcho(str(Url))
        if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                
                oGui.addDir(SITE_IDENTIFIER, 'pageshowDizi2', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
 
    
        oGui.setEndOfDirectory()

def __checkForNextPage(sHtmlContent):
    
    sPattern = '<li class="active"><a href=".*?" class="nuxt-link-exact-active active">.*?</a></li><li><a href="(.*?)"'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        sUrl ="http://www.netd.com"+ aResult[1][0] 
        return sUrl
               
 

 
def udizizleABC():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    
    Url = oInputParameterHandler.getValue('siteUrl')

    urla  = "http://www.netd.com/"
                      
    referer=[('Referer',urla)]
    data=gegetUrl(Url,headers=referer) 
       
    streamDaten = re.findall('<div class="col-md-3 col-sm-6"><div class="thumbnail thumbnail-play"><span><!----><a href="(.*?)"', data, re.S) 
    sUrl = "http://www.netd.com%s"  % (streamDaten[0])      
    oRequestHandler = cRequestHandler(sUrl)
    Server = oRequestHandler.request()
  
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
#    s
    aResult= re.findall('"video":."description":".*?","title":"(.*?)".*?"value":"(.*?)"',Server, re.S|re.I)
    for name,sHosterUrl in aResult:
    
        url='http://media.netd.com.tr/' +sHosterUrl
      
        addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')
                                                                                            
                               
def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok  
def pageshowABC(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'http://www.voirfilms.org/rechercher'
        request = urllib2.Request(url,data,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
         
        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern = '<div class="film">.*?<a href="(.*?)" title=".*?"><img src="(.*?)" width=".*?" height=".*?"  alt="(.*?)"'
                    
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
   
        oRequestHandler = cRequestHandler(sUrl)
        sHtmlContent = oRequestHandler.request()
        
        
         
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '"title":"(.*?)".*?"type":"applicationx-mpegURL","value":"(.*?)"'
    
    sHtmlContent = sHtmlContent
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle =alfabekodla(aEntry[0])
            sPicture = picpic
            
                
            sUrl = aEntry[1]
            if not 'http' in sUrl:
                sUrl =URL_MAIN + sUrl
           
            
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle',sTitle)
          
 
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/sinemalar/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'pageshowMovies', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'sshowBox3', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = __NextPage(sHtmlContent)#cherche la page suivante
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'pageshowDizi', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()
 

def __NextPage(sHtmlContent):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sUrl =sUrl.replace('amp;', "")
    sPattern = 'data-url="(/actions/control/episodes.*?)"'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        return str(URL_MAIN) + aResult[1][0]+'&skip=10'

    return False             


    return False
def sshowBox2():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    Url = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    
    
    sTitle = alfabekodla(sTitle) 
    urla  = "https://www.kanald.com.tr"
                      
    oRequestHandler = cRequestHandler(Url)
    data = oRequestHandler.request()
  

    data=data.replace('"SecurePath": "', '"SecurePath":"')      
    sUrl= re.findall('"SecurePath":"(.*?)"', data)[0]
    if not 'http' in sUrl:
         sUrl = "https://soledge4.dogannet.tv//%s" %( sUrl.replace('\u0026', "&"))  
       
   
                                                                               
    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sTitle)
    oGuiElement.setMediaUrl(sUrl)
    

    #cConfig().log("Hoster - play " + str(sTitle))
    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    #tout repetter
    #xbmc.executebuiltin("xbmc.playercontrol(RepeatAll)")
    
    oPlayer.startPlayer()

def akanald():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url = oInputParameterHandler.getValue('siteUrl')
    
    name = oInputParameterHandler.getValue('sMovieTitle')
    name = alfabekodla ( name) 
    
                                                        
    
    
    
    from resources.lib.hlsplayer import hlsproxy
    
    progress = xbmcgui.DialogProgress()
    import checkbad
    checkbad.do_block_check(False)
    stopPlaying=threading.Event()
    _bitrate =0
    maxbitrate=9000000
    f4m_proxy=hlsproxy()
    stopPlaying.clear()
    runningthread=thread.start_new_thread(f4m_proxy.start,(stopPlaying,))
    progress.create('Starting HLS Player')
    streamtype='HLS'                                                                   
    progress.update( 20, "", 'Loading local proxy', "" )
    url_to_play=f4m_proxy.prepare_url(url,proxy,use_proxy_for_chunks,maxbitrate=maxbitrate,simpleDownloader=simpleDownloader,auth=auth,streamtype=streamtype,swf=swf ,callbackpath=callbackpath,callbackparam=callbackparam)
    listitem = xbmcgui.ListItem(name,path=url_to_play, iconImage=iconImage, thumbnailImage=iconImage)
    listitem.setInfo('video', {'Title': name})
    if setResolved:
        return url_to_play, listitem
    mplayer = MyPlayer()    
    mplayer.stopPlaying = stopPlaying
    progress.close() 
    mplayer.play(url_to_play,listitem)

    firstTime=True
    played=False
    while True:
       if stopPlaying.isSet():
           break;
       if xbmc.Player().isPlaying():
           played=True
       xbmc.log('Sleeping...')
       xbmc.sleep(200)
                #if firstTime:
                #    xbmc.executebuiltin('Dialog.Close(all,True)')
                #    firstTime=False
            #stopPlaying.isSet()

    print 'Job done'
    return played

class MyPlayer (xbmc.Player):
    def __init__ (self):
        xbmc.Player.__init__(self)

    def play(self, url, listitem):
        print 'Now im playing... %s' % url
        self.stopPlaying.clear()
        xbmc.Player( ).play(url, listitem)
        
    def onPlayBackEnded( self ):
        # Will be called when xbmc stops playing a file
        print "seting event in onPlayBackEnded " 
        self.stopPlaying.set();
        print "stop Event is SET" 
    def onPlayBackStopped( self ):
        # Will be called when user stops xbmc playing a file
        print "seting event in onPlayBackStopped " 
        self.stopPlaying.set();
        print "stop Event is SET" 



def _m3u8Exit(self):
     import otv_kuresel
     otv_kuresel.yt_tmp_storage_dirty = True    
def partplay():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    Url = oInputParameterHandler.getValue('siteUrl')
    Title = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    urla  = "http://www.netd.com/"
                      
    referer=[('Referer',urla)]
    data=gegetUrl(Url,headers=referer) 
     
    stream = re.findall("type: 'GET'.*?url: '/actions/control/player/(.*?)? ',", data, re.S)
    url = "http://www.netd.com/actions/content/media/" +stream[0]
    urla  = "http://www.netd.com/"
                      
    referer=[('Referer',urla)]
    data=gegetUrl(Url,headers=referer)
    
    tarzlistesi= []
    tarzlistesi.append(("part=1", ""+url.replace('</span> <b>','<OTV>')))
    tarzlistesi.append(("part=2", ""+url.replace('part=1-6','part=2-6')))
    tarzlistesi.append(("part=3", ""+url.replace('part=1-6','part=3-6')))
    tarzlistesi.append(("part=4", ""+url.replace('part=1-6','part=4-6')))
    tarzlistesi.append(("part=5", ""+url.replace('part=1-6','part=5-6')))
    tarzlistesi.append(("part=6", ""+url.replace('part=1-6','part=6-6')))
        
    for sTitle,sUrl in tarzlistesi:
           
         
         
        sTitle = alfabekodla(sTitle)         
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oGui.addDir(SITE_IDENTIFIER, 'sshowBox3', sTitle, 'tv.png', oOutputParameterHandler)
    
  
    oGui.setEndOfDirectory()


def play__():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
   
    sUrl = sUrl+ '|User-Agent=Mozilla/5.0 (iPhone; CPU iPhone OS 9_2 like Mac OS X)'
    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sTitle)
    oGuiElement.setMediaUrl(sUrl)
    

    #cConfig().log("Hoster - play " + str(sTitle))
    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    #tout repetter
    #xbmc.executebuiltin("xbmc.playercontrol(RepeatAll)")
    
    oPlayer.startPlayer()
    


def sshowBox3():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    oInputParameterHandler = cInputParameterHandler()
    sUrl ='http://www.netd.com'+ oInputParameterHandler.getValue('siteUrl')
    sUrltit = oInputParameterHandler.getValue('sMovieTitle')
    ua='Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'                                                                            
    urla= "http://www.netd.com/"
    referer=[('Referer',sUrl)]
             
       


    Server=gegetUrl(sUrl,headers=referer)          
    Server=Server.replace('/u002F', "")
    aResult= re.findall('"title":"'+sUrltit+'".*?"type":"applicationx-mpegURL","value":"(.*?)"', Server)
    for sTitle,url in aResult:
    
        sHosterUrl='http://media.netd.com.tr/' + url
    

                  

    
        sTitle = alfabekodla(sTitle) 
        oGuiElement = cGuiElement()
        oGuiElement.setSiteName(SITE_IDENTIFIER)
        oGuiElement.setTitle(sTitle)
        oGuiElement.setMediaUrl(sHosterUrl)
        

        oPlayer = cPlayer()
        oPlayer.clearPlayList()
        oPlayer.addItemToPlaylist(oGuiElement)
        oPlayer.startPlayer()  
        return False
def showMessage(heading='TURKvod', message = '', times = 2000, pics = ''):
                try: xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading, message, times, pics))
                except Exception, e:
                        xbmc.log( '[%s]: showMessage: exec failed [%s]' % ('', e), 1 )                                           

                        xbmc.log( '[%s]: showMessage: exec failed [%s]' % ('', e), 1 )        