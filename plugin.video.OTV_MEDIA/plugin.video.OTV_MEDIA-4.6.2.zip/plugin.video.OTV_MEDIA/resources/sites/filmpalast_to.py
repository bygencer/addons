#-*- coding: utf-8 -*-
import urllib2, urllib,cookielib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, zipfile, re, stat, xbmcvfs, base64
from resources.lib.otvhelper import  gegetUrl,getUrl ,alfabekodla
from resources.lib.config import cConfig
import requests
import re,xbmcgui,unicodedata              
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress, VSlog
from resources.lib.player import cPlayer
from resources.lib.kplayer  import Player
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.util import cUtil
SITE_IDENTIFIER = 'filmpalast_to'
SITE_NAME = 'FilmPalast'
SITE_ICON = 'filmpalast.png'
SITE_DESC = 'Replay TV'

URL_MAIN = 'https://filmpalast.to/'
import re,json
ALMAN_SINEMA = (True, 'showGenre') 

baseurl = 'http://filmpalast.to/'
URL_STREAM = URL_MAIN + 'stream/%d/1'
streamurl = 'https://filmpalast.to/stream/{id}/1'
def getStreamSRC(id):
	from t0mm0.common.net import Net
	net = Net()
	data = cRequestHandler(streamurl.replace('{id}', id), {'streamID':id}, {'Referer':baseurl, 'X-Requested-With':'XMLHttpRequest'}).request()
	for url in re.findall('"url":"([^"]+)"', data, re.S|re.I): return url.replace('\\','')
    
def decodeHtml(data):

	
		data = data.decode('unicode-escape').encode('UTF-8') 
		return data

def search_new():
            url ='http://api.trakt.tv/search/movie?limit=20&page=1&query=joy'
           
            q =trakt_list(url)
           
           
          
           
            name ='test'
            addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,q,'')
                                                                                            

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok 

def sEcho(s):
      s=s
      if 'page/1' in s:
	s=s.replace('page/1','page/2')
        return s 
      if 'page/2' in s:
	s=s.replace('page/2','page/3')
        return s 
      if 'page/3' in s:	
        s=s.replace('page/3','page/4')
        return s 
      if 'page/4' in s:	
        s=s.replace('page/4','page/5')
        return s 
      if 'page/5' in s:	
        s=s.replace('page/5','page/6')
        return s 
      if 'page/6' in s:	
        s=s.replace('page/6','page/7')
        return s 
      if 'page/7' in s:	
        s=s.replace('page/7','page/8')
        return s 
      if 'page/8' in s:	
        s=s.replace('page/8','page/9')
        return s 
      if 'page/9' in s:	
        s=s.replace('page/9','page/10')
        return s 
      if 'page/10' in s:	
        s=s.replace('page/10','page/11')
        return s 
      if 'page/11' in s:	
        s=s.replace('page/11','page/12')
        return s 
      if 'page/12' in s:	
        s=s.replace('page/12','page/13')
        return s 
      if 'page/13' in s:	
        s=s.replace('page/13','page/14')
        return s 
      if 'page/14' in s:	
        s=s.replace('page/14','page/15')
        return s 
      if 'page/15' in s:	
        s=s.replace('page/15','page/16')
        return s 
      if 'page/16' in s:	
        s=s.replace('page/16','page/17')
        return s
      if 'page/17' in s:	
        s=s.replace('page/17','page/18')
        return s 
      if 'page/18' in s:	
        s=s.replace('page/18','page/19')
        return s 
      if 'page/19' in s:	
        s=s.replace('page/19','page/20')
        return s 
      if 'page/20' in s:	
        s=s.replace('page/20','page/21')
        return s 
      if 'page/21' in s:	
        s=s.replace('page/21','page/22')
        return s 
      if 'page/22' in s:	
        s=s.replace('page/22','page/23')
        return s 
      if 'page/23' in s:	
        s=s.replace('page/23','page/24')
        return s 
      if 'page/24' in s:	
        s=s.replace('page/24','page/25')
        return s 
      if 'page/25' in s:	
        s=s.replace('page/25','page/26')
        return s 
      if 'page/26' in s:	
        s=s.replace('page/26','page/27')
        return s 
      if 'page/27' in s:	
        s=s.replace('page/27','page/28')
        return s 
      if 'page/28' in s:	
        s=s.replace('page/28','page/29')
        return s 
      if 'page/29' in s:	
        s=s.replace('page/29','page/30')
        return s 
      if 'page/30' in s:	
        s=s.replace('page/30','page/31')
        return s 
      if 'page/31' in s:	
        s=s.replace('page/31','page/32')
        return s 
      if 'page/32' in s:	
        s=s.replace('page/32','page/33')
        return s 
      if 'page/33' in s:	
        s=s.replace('page/33','page/34')
        return s 
      if 'page/34' in s:	
        s=s.replace('page/34','page/35')
        return s 
      if 'page/35' in s:	
        s=s.replace('page/35','page/36')
        return s 
      if 'page/36' in s:	
        s=s.replace('page/36','page/37')
        return s 
      if 'page/37' in s:	
        s=s.replace('page/37','page/38')
        return s 
      if 'page/38' in s:	
        s=s.replace('page/38','page/39')
        return s 
      if 'page/39' in s:	
        s=s.replace('page/39','page/40')
        return s 
      if 'page/40' in s:	
        s=s.replace('page/40','page/41')
        return s 
      if 'page/41' in s:	
        s=s.replace('page/41','page/42')
        return s 
      if 'page/42' in s:	
        s=s.replace('page/42','page/43')
        return s 
      if 'page/43' in s:	
        s=s.replace('page/43','page/44')
        return s 
      if 'page/44' in s:	
        s=s.replace('page/44','page/45')
        return s 
      if 'page/45' in s:	
        s=s.replace('page/45','page/46')
        return s 
      if 'page/46' in s:	
        s=s.replace('page/46','page/47')
        return s 
      if 'page/47' in s:	
        s=s.replace('page/47','page/48')
        return s 
      if 'page/48' in s:	
        s=s.replace('page/48','page/49')
        return s 
      if 'page/49' in s:	
        s=s.replace('page/49','page/50')
        return s 
      return False  
def showSearch():
    oGui = cGui()

    sSearchText = oGui.showKeyBoard()
    if (sSearchText != False):
            sUrl = 'http://filmpalast.to/search/title/'+sSearchText  
            sUrl= sUrl.replace(' ','%20')
            searchowMovies(sUrl)
            oGui.setEndOfDirectory()
            return  


def load():
    oGui = cGui()
    tarzlistesi= [ ('Suche',"https://filmpalast.to/search/alpha/%s"),
                   ('NEUE',"https://filmpalast.to/page/1"),
                   ('NEUE FILME',"https://filmpalast.to/movies/new/page/1"),
		   ('TOP FILME',"http://filmpalast.to/movies/top/page/1"),
		   ('SERIEN',"https://filmpalast.to/serien/view/page/1"),
		   ('Abenteuer',"http://filmpalast.to/search/genre/Abenteuer/1"),
		   ('Action',"https://filmpalast.to/search/genre/Action/1"),
                            ('Fantasy',"https://filmpalast.to/search/genre/Fantasy/1"),
                            ('Animation',"https://filmpalast.to/search/genre/Animation/1"),
                            ('Biography',"https://filmpalast.to/search/genre/biography/1"),
                            ('Kom�die',"https://filmpalast.to/search/genre/Kom�die/1"),
                            ('Krimi',"https://filmpalast.to/search/genre/Krimi/1"),
                            ('Documentary',"https://filmpalast.to/search/genre/documentary/1"),
                            ('Drama',"https://filmpalast.to/search/genre/Drama/1"),
                            ('Familie',"https://filmpalast.to/search/genre/Familie/1"),
                            ('History',"https://filmpalast.to/search/genre/history/1"),
                            ('Horror',"https://filmpalast.to/search/genre/Horror/1"),
                            ('Music',"https://filmpalast.to/search/genre/music/1"),
                            ('Musical',"https://filmpalast.to/search/genre/musical/1"),
                            ('Mystery',"https://filmpalast.to/search/genre/Mystery/1"),
                            ('Romantik',"https://filmpalast.to/search/genre/Romantik/1"),
                            ('Sci-Fi',"https://filmpalast.to/search/genre/Sci-Fi/1"),
                            ('Short',"https://filmpalast.to/search/genre/short/1"),
                            ('Sport',"https://filmpalast.to/search/genre/sport/1"),
                            ('Thriller',"https://filmpalast.to/search/genre/thriller/1"),
                            ('Krieg',"https://filmpalast.to/search/genre/Krieg/1"),
                            ('Western',"https://filmpalast.to/search/genre/western/1"),
                            ('Movie Title 0-9',"https://filmpalast.to/search/alpha/0-9/"),
                            ('Movie Title A',"https://filmpalast.to/search/alpha/a/"),
                            ('Movie Title B',"https://filmpalast.to/search/alpha/b/"),
                            ('Movie Title C',"http://www.filmpalast.to/search/alpha/c/"),
                            ('Movie Title D',"http://www.filmpalast.to/search/alpha/d/"),
                            ('Movie Title E',"http://www.filmpalast.to/search/alpha/e/"),
                            ('Movie Title F',"http://www.filmpalast.to/search/alpha/f/"),
                            ('Movie Title G',"http://www.filmpalast.to/search/alpha/g/"),
                            ('Movie Title H',"http://www.filmpalast.to/search/alpha/h/"),
                            ('Movie Title I',"http://www.filmpalast.to/search/alpha/i/"),
                            ('Movie Title J',"http://www.filmpalast.to/search/alpha/j/"),
                            ('Movie Title K',"http://www.filmpalast.to/search/alpha/k/"),
                            ('Movie Title L',"http://www.filmpalast.to/search/alpha/l/"),
                            ('Movie Title M',"http://www.filmpalast.to/search/alpha/m/"),
                            ('Movie Title N',"http://www.filmpalast.to/search/alpha/n/"),
                            ('Movie Title O',"http://www.filmpalast.to/search/alpha/o/"),
                            ('Movie Title P',"http://www.filmpalast.to/search/alpha/p/"),
                            ('Movie Title Q',"http://www.filmpalast.to/search/alpha/q/"),
                            ('Movie Title R',"http://www.filmpalast.to/search/alpha/r/"),
                            ('Movie Title S',"http://www.filmpalast.to/search/alpha/s/"),
                            ('Movie Title T',"http://www.filmpalast.to/search/alpha/t/"),
                            ('Movie Title U',"http://www.filmpalast.to/search/alpha/u/"),
                            ('Movie Title V',"http://www.filmpalast.to/search/alpha/v/"),
                            ('Movie Title W',"http://www.filmpalast.to/search/alpha/w/"),
                            ('Movie Title X',"http://www.filmpalast.to/search/alpha/x/"),
                            ('Movie Title Y',"http://www.filmpalast.to/search/alpha/y/"),
                            ('Movie Title Z',"http://www.filmpalast.to/search/alpha/z/"),]

               
    for sTitle,sUrl2 in tarzlistesi:
        sTitle = alfabekodla(sTitle)   
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl2)
        if sTitle == 'DIZILER-harfler':
             oGui.addDir(SITE_IDENTIFIER, 'dizizleABC', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'NEUE':
             oGui.addDir(SITE_IDENTIFIER, 'showSinema2', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'SERIEN':
             oGui.addDir(SITE_IDENTIFIER, 'showSHOW', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'Suche':
             oGui.addDir(SITE_IDENTIFIER, 'showSearch', sTitle, 'genres.png', oOutputParameterHandler)

        else:
             oGui.addDir(SITE_IDENTIFIER, 'showSinema', sTitle, 'genres.png', oOutputParameterHandler)
                   
                    
    oGui.setEndOfDirectory()

def searchowMovies(sUrl):
    oGui = cGui()
    data = cRequestHandler(sUrl).request()
   
    sHtmlContent = re.findall('<small class="rb">.*?<a href="(.*?)" title=".*?"> <img src="(.*?)" class="cover-opacity" alt="(.*?)"/>', data, re.S)
         
    for sUrl,sPicture,sTitle in sHtmlContent:
             
                       
            sTitle = alfabekodla(sTitle)
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))            
            oGui.addMovie(SITE_IDENTIFIER, 'showHost', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
         
    oGui.setEndOfDirectory()  
page =0
def showpage(sUrl):
           
            sUrl = "%s/%s" % (sUrl, str(page+ 1))
            showSinema(sUrl)
            return 
    


def showSHOW():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request();
    oParser = cParser()
    sPattern = '<ul id="serien-nav">(.+?)</section>'
    
    aResult = oParser.parse(sHtmlContent, sPattern)
    sHtmlContent = aResult
    sPattern = '<a href="(.*?)">(.*?)</a>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            Url = str(aEntry[0])
            if not 'http' in Url:
                Url = 'https:' + Url
            sTitle = alfabekodla(aEntry[1])
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', str(Url))
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', str(sThumbnail))
            oGui.addTV(SITE_IDENTIFIER, 'showSHOW2', sTitle, '', sThumbnail, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory()
def showSHOW2():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    
    sHtmlContent= cRequestHandler(sUrl).request()
    oParser = cParser()

    sPattern = '<a data-id="staffId.*?" id="sid.*?" class="staffTab" data-sid="(.*?)".*?<i class="fa fa-angle-left"></i>(.*?)</a>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            Url = str(aEntry[0])
            
            sTitle = alfabekodla(aEntry[1])
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', str(sUrl))
            oOutputParameterHandler.addParameter('Season', str(Url))
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', str(sThumbnail))
            oGui.addTV(SITE_IDENTIFIER, 'showSHOW3', sTitle, '', sThumbnail, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory()
def showSHOW3():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    Season = oInputParameterHandler.getValue('Season')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request();
    oParser = cParser()
    sPattern= '<div[^>]*class="staffelWrapperLoop[^"]*"[^>]*data-sid="%s">(.*?)</div></li></ul></div>' % Season
    
    aResult = oParser.parse(sHtmlContent, sPattern)
    sHtmlContent = aResult
    sPattern = '<a[^>]*href="([^"]*)"[^>]*class="getStaffelStream"[^>]*>.*?<small>([^>]*?)</small>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            Url = str(aEntry[0])
            if not 'http' in Url:
                Url = 'https:' + Url
            sTitle = alfabekodla(aEntry[1])
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', str(Url))
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', str(sThumbnail))
            oGui.addTV(SITE_IDENTIFIER, 'showHost', sTitle, '', sThumbnail, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory()



def mshowSHOW(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url =  sSearch
        request = urllib2.Request(url,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
        
 
        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern ='</cite>.*?<a href="(.*?)" title="(.*?)"> <img src="(.*?)"'
                    
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
   
        
        sHtmlContent = cRequestHandler(sUrl).request()
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '</cite>.*?<a href="(.*?)" title="(.*?)"> <img src="(.*?)"'
    
    sHtmlContent = sHtmlContent
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = cUtil().unescape(aEntry[1])
            sPicture = str(aEntry[2])
            if not 'http' in sPicture:
                sPicture = str(URL_MAIN) + sPicture
                
            Url = str(aEntry[0])
            if not 'http' in Url:
                Url = str(URL_MAIN) + Url
           
            #not found better way
            #sTitle = unicode(sTitle, errors='replace')
            #sTitle = sTitle.encode('ascii', 'ignore').decode('ascii')
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', Url)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture)
                                                                     
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/sinemalar/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'pageshowMovies', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'showStaffel', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = sEcho(str(sUrl))
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showSHOW', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
                
    if not sSearch:
        oGui.setEndOfDirectory()

def ddizizleABC():
    oGui = cGui()
  
    oInputParameterHandler = cInputParameterHandler()
    urll = oInputParameterHandler.getValue('siteUrl') 
    url = HTTPKIR(urll)
       
        
    name ='test'
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')
                                                                                            

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok 


def showStaffel(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url =  sSearch
        request = urllib2.Request(url,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
        
 
        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern ='</cite>.*?<a href="(.*?)" title="(.*?)"> <img src="(.*?)"'
                    
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        sPicture = oInputParameterHandler.getValue('sThumbnail')
        sHtmlContent = cRequestHandler(sUrl).request()
    
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '<li class="stitle">.*?<a id="staffId_" href="(.*?)" class="getStaffelStream" data-sid=".*?">.*?<small>(.*?)</small>'
                                         
    sHtmlContent = sHtmlContent                                                                                   
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)                                                             
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = cUtil().unescape(aEntry[1])
                            
            Url = str(aEntry[0])
           
            sTitle = alfabekodla(sTitle)
            #not found better way
            #sTitle = unicode(sTitle, errors='replace')
            #sTitle = sTitle.encode('ascii', 'ignore').decode('ascii')
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', Url)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
          
 
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/sinemalar/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'pageshowMovies', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'showHost', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = sEcho(str(sUrl))
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showSHOW', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
                
    if not sSearch:
        oGui.setEndOfDirectory()
def showSinema2(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url =  sSearch
        request = urllib2.Request(url,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
        
 
        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern ='</cite>.*?<a href="(.*?)" title="(.*?)"> <img src="(.*?)"'
                            
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
   
        sHtmlContent = cRequestHandler(sUrl).request()
        
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '<article class="liste rb pHome">.*?<a href="(.*?)" title="(.*?)".*?<img src="(.*?)"'
    
    sHtmlContent = sHtmlContent
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = cUtil().unescape(aEntry[1])
            sPicture = str(aEntry[2])
            if not 'http' in sPicture:
                sPicture = str(URL_MAIN) + sPicture
                
            Url = str(aEntry[0])
            if not 'http' in Url:
                Url = 'https:' + Url
           
            #not found better way
            #sTitle = unicode(sTitle, errors='replace')
            #sTitle = sTitle.encode('ascii', 'ignore').decode('ascii')
            sTitle = alfabekodla(sTitle)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', Url)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
          
 
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/sinemalar/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'pageshowMovies', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'showHost', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = sEcho(str(sUrl))
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showSinema2', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
                
    if not sSearch:
        oGui.setEndOfDirectory()



def showSinema(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url =  sSearch
        request = urllib2.Request(url,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
        
 
        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern ='</cite>.*?<a href="(.*?)" title="(.*?)"> <img src="(.*?)"'
                            
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
   
        sHtmlContent = cRequestHandler(sUrl).request()
        
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '</cite>.*?<a href="(.*?)" title="(.*?)"> <img.*?src="(.*?)"'
    
    sHtmlContent = sHtmlContent
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = cUtil().unescape(aEntry[1])
            sPicture = str(aEntry[2])
            if not 'http' in sPicture:
                sPicture = str(URL_MAIN) + sPicture
                
            Url = str(aEntry[0])
            if not 'http' in Url:
                Url = 'https:' + Url
           
           
            
            sTitle = alfabekodla(sTitle)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', Url)
            oOutputParameterHandler.addParameter('sThumbnail', str(sPicture))
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/sinemalar/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'pageshowMovies', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'showHost', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = sEcho(str(sUrl))
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showSinema', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
                
    if not sSearch:
        oGui.setEndOfDirectory()
def mmshowHost():
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sHtmlContent = cRequestHandler(sUrl).request()
    pattern = 'hostName">([^<]+).*?href="([^"]+)'
    isMatch, aResult = cParser().parse(sHtmlContent, pattern)
    hosters = []
    if isMatch:
        for sName, sUrl in aResult:
            hoster = {'link': sUrl, 'name': sName}
            hosters.append(hoster)
    if hosters:
        hosters.append('getHosterUrl')
    return hosters   
def showHost():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    Url = oInputParameterHandler.getValue('siteUrl')                  
    

    sHtmlContent = cRequestHandler(Url).request()
                                  
   
    #sPattern = '<a href="((?:categorie\.php\?watch=)|(?:&#99;&#97;&#116;&#101;&#103;&#111;&#114;&#105;&#101;&#46;&#112;&#104;&#112;&#63;&#119;&#97;&#116;&#99;&#104;&#61;).+?)" onmouseover=.+?decoration:none;">(.+?)<\/a>'
                                              
    sPattern = 'hostName">([^<]+).*?(http[^"]+)'
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            
            sGenre = cUtil().unescape(aEntry[0])
            sUrl= aEntry[1]
            sTitle = aEntry[0].decode("latin-1").encode("utf-8")
            
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('host', Url)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            if 'vivo' in sUrl:
               oGui.addDir(SITE_IDENTIFIER, 'vivosx', sTitle, 'filmpalast.png', oOutputParameterHandler)
            else:
            
                oGui.addTV(SITE_IDENTIFIER, 'showHosters', sGenre, '', '', '', oOutputParameterHandler)
        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory()    

def showMovies(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'http://www.voirfilms.org/rechercher'
        request = urllib2.Request(url,data,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
        
        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern = '<small class="rb">.*?<a href="(.*?)" title=".*?"> <img src="(.*?)" class="cover-opacity" alt="(.*?)"/>'
                    
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
   
        sHtmlContent = cRequestHandler(sUrl).request()
        
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '<div class="film">.*?<a href="(.*?)" title=".*?"><img src="(.*?)" width=".*?" height=".*?"  alt="(.*?)"'
    
    sHtmlContent = sHtmlContent
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = cUtil().unescape(aEntry[2])
            sPicture = str(aEntry[1])
            if not 'http' in sPicture:
                sPicture = str(URL_MAIN) + sPicture
                
            sUrl = str(aEntry[0])
            if not 'http' in sUrl:
                sUrl = str(URL_MAIN) + sUrl
           
            #not found better way
            #sTitle = unicode(sTitle, errors='replace')
            #sTitle = sTitle.encode('ascii', 'ignore').decode('ascii')
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
          
 
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/anime/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'pageshowMovies', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = sEcho(str(sUrl))#cherche la page suivante
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'pageshowMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()
def pageshowMovies(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'http://www.voirfilms.org/rechercher'
        request = urllib2.Request(url,data,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
         
        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern = '<div class="film">.*?<a href="(.*?)" title=".*?"><img src="(.*?)" width=".*?" height=".*?"  alt="(.*?)"'
                    
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
   
        sHtmlContent = cRequestHandler(sUrl).request()
        
                 
        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '<div class="ust">.*?<div class="resim" id=".*?"><a href="(.*?)" title=".*?"><img src="(.*?)".*?<div class="ad"><a href=".*?" title=".*?">(.*?)</a></div>'
    
    sHtmlContent = sHtmlContent.replace('<br />','<OTV>')
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = cUtil().unescape(aEntry[2])
            sPicture = str(aEntry[1])
            if not 'http' in sPicture:
                sPicture = str(URL_MAIN) + sPicture
                
            sUrl = str(aEntry[0])
            if not 'http' in sUrl:
                sUrl = str(URL_MAIN) + sUrl
           
            #not found better way
            #sTitle = unicode(sTitle, errors='replace')
            #sTitle = sTitle.encode('ascii', 'ignore').decode('ascii')
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumbnail', sPicture)
 
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif 'verystream.com' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'pageshowMovies', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = __NextPage(sHtmlContent,sUrl)#cherche la page suivante
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'pageshowMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()
def __NextPage(sHtmlContent,sUrl):
    sHtmlContent = sHtmlContent.replace("'",'"')    
    sPattern = '<a class="pageing button-small rb active">.*?</a> <a class="pageing button-small rb" href="(.*?)">'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        return sUrl +str(aResult[1][0]) 
         
def __checkForNextPage(sHtmlContent):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sPattern = '</a> <a href="(.*?)" class="syfno">Sonraki Sayfa &raquo;</a>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        return str(sUrl) + aResult[1][0]

    return False
def kuoku():
    oInputParameterHandler = cInputParameterHandler()
    sUrl = 'https://verystream.com/e/BCFvf5nU71V/'
#    Url = 'http://139.59.68.238/stm-v3/api/def2.php?id=723&quality=0&type=0'

    oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('Referer', 'https://filmpalast.to/stream/saphirblau')
    page = oRequest.request()
    token = re.findall('videolink">([^<]+)', page)[0]

    url ='https://verystream.com/gettoken/' + token + '?mime=true' 
    name="r"            
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')
                      

def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    ref = oInputParameterHandler.getValue('host')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    sUrl = oInputParameterHandler.getValue('siteUrl')
      
    sHosterUrl = sUrl
    
    sMovieTitle = str(sMovieTitle) 
    oHoster = cHosterGui().checkHoster(sHosterUrl)

    if (oHoster != False):
        
        sMovieTitle = cUtil().DecoTitle(sMovieTitle)
        
        
        
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumbnail)

    oGui.setEndOfDirectory()
def __getSource(id):
    oRequest = cRequestHandler(URL_STREAM % int(id))
    oRequest.addParameters('streamID', id)
    oRequest.addHeaderEntry('Origin', URL_MAIN)
    oRequest.addHeaderEntry('Host', 'filmpalast.to')
    oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
    sJson = oRequest.request()
    if sJson:
        data = json.loads(sJson)
        if 'error' in data and int(data['error']) == 0 and 'url' in data:
            return data['url']
        if 'msg' in data:
            logger.info("Get link failed: '%s'" % data['msg'])
    return False


def vivosx():
        oInputParameterHandler = cInputParameterHandler()
        ref = oInputParameterHandler.getValue('host')
        sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
        sThumbnail = oInputParameterHandler.getValue('sThumbnail')
        sUrl = oInputParameterHandler.getValue('siteUrl')
        if 'vivo.php' in sUrl:
           oRequest = cRequestHandler(ref)
           oRequest.addHeaderEntry('Referer', ref)
           sHtml  = oRequest.request()
           sUrl = re.findall('<p class="hostName">vivo.sx</p></li><li class="streamPlayBtn clearfix rb"><a  class="button rb iconPlay" target="_blank" href="(.*?)"', sHtml)[0]
           oRequest = cRequestHandler(sUrl)
           oRequest.addHeaderEntry('Referer', ref)
           oRequest.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36')
           html = oRequest.request()

        else:                     
           oRequest = cRequestHandler(sUrl)
           oRequest.addHeaderEntry('Referer', ref)
           oRequest.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36')
           html = oRequest.request()

        
        urll = re.findall('stream="(.*?)"', html)
        urll= urll[0]
        url = base64.b64decode(urll)   
        name = sMovieTitle
        addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok