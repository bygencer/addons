#-*- coding: utf-8 -*-
import urllib2, urllib,cookielib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, zipfile, re, stat, xbmcvfs, base64
from resources.lib.otvhelper import  gegetUrl,getUrl ,alfabekodla
from resources.lib.config import cConfig
import requests
import re,xbmcgui,unicodedata              
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress, VSlog
from resources.lib.player import cPlayer
from resources.lib.kplayer  import Player
from resources.lib.gui.guiElement import cGuiElement


HOST = 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36'

import binascii 
from base64 import b64decode, urlsafe_b64encode
import requests
s = requests.Session()


import urllib2,urllib,cgi, re
import cookielib
cj = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
TIK='|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36'


def _get(request,post=None):
    """Performs a GET request for the given url and returns the response"""
    return opener.open(request,post).read()
SITE_IDENTIFIER = 'diziizlehdfull_net'
SITE_NAME = 'diziizlehdfull.org'
MOVIE_HD = (True, 'showGenre')
def diziizlehdfulltr():
    oGui = cGui()
 
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://www.diziizlesene1.com/fulllllll-4/')
    oGui.addDir(SITE_IDENTIFIER, 'diziyeni', 'Yeni Eklenen Dizi B�lümler', 'search.png', oOutputParameterHandler)
   
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://www.diziizlesene1.com/fulllllll-4/')
    oGui.addDir(SITE_IDENTIFIER, 'm3u8Box3', 'Gündüz Kusagi Programlari', 'search.png', oOutputParameterHandler)
   
   
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://www.diziizlesene1.com/fulllllll-4/')
    oGui.addDir(SITE_IDENTIFIER, 'dizifulltr', 'TUM DIZILER', 'search.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://www.diziizlesene1.com/kore-dizileri-izle-turkce-dublaj/')
    oGui.addDir(SITE_IDENTIFIER, 'dizikore', 'Kore Dizileri', 'search.png', oOutputParameterHandler)
           
    oGui.setEndOfDirectory()
def ASCIIDecode(string):

    i = 0
    l = len(string)
    ret = ''
    while i < l:
        c =string[i]
        if string[i:(i+2)] == '\\x':
            c = chr(int(string[(i+2):(i+4)], 16))
            i+=3
        if string[i:(i+2)] == '\\u':
            cc = int(string[(i+2):(i+6)], 16)
            if cc > 256:
                #ok c'est de l'unicode, pas du ascii
                return ''
            c = chr(cc)
            i+= 5
        ret = ret + c
        i = i + 1

    return ret
 
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if (sSearchText != False):
        showMovies(sSearchText)
        oGui.setEndOfDirectory()
        return
        
def AlphaSearch():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    
    dialog = cConfig().createDialog(SITE_NAME)
    
    for i in range(0,27) :
        cConfig().updateDialog(dialog, 36)
        
        if (i > 0):
            sTitle = chr(64+i)
        else:
            sTitle = '09'
            
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl + sTitle.upper() )
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal] Lettre [COLOR red]'+ sTitle +'[/COLOR][/COLOR]', 'genres.png', oOutputParameterHandler)
def diziyeni(): #affiche les genres
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    urla  = "http://www.diziizlesene1.com/"
                                                                 
                                                                                                         
    referer=[('Referer',urla)]       
    data=getUrl(sUrl).result   
                      
#
    playlist = re.findall('<div class="post_title "><a href="(.*?)" title="(.*?)" class=".*?"><img.*?src="(.*?)"', data, re.S)
    for sUrl,sGenre,resim in playlist:
            
            sGenre = alfabekodla(sGenre)    
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sGenre)
            oGui.addTV(SITE_IDENTIFIER, 'play__dizi', sGenre, '', resim, '', oOutputParameterHandler)
    oGui.setEndOfDirectory()        

def dizikore(): #affiche les genres
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    urla  = "http://www.diziizlesene1.com/"
                                                                 
                                                                                                         
    referer=[('Referer',urla)]       
    data=getUrl(sUrl).result   
                      
#
    playlist = re.findall('<div class="item"><div class="item_inner"><div class="item-image"><a href="(.*?)" class=".*?"><img class="" src="(.*?)" width=".*?" height=".*?" alt="(.*?)"/>', data, re.S)
    for sUrl,resim,sGenre in playlist:
            
            sGenre = alfabekodla(sGenre)    
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sGenre)
            oGui.addTV(SITE_IDENTIFIER, 'dizifulltr2', sGenre, '', resim, '', oOutputParameterHandler)
    oGui.setEndOfDirectory()        
     
def dizifulltr(): #affiche les genres
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    oRequestHandler = cRequestHandler(sUrl)
    data = oRequestHandler.request();
                         
    playlist = re.findall('<a class="alinka" title="(.*?)" href="(.*?)">', data, re.S)
    for sGenre,sUrl in playlist:
            
            sGenre = alfabekodla(sGenre)    
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sGenre)
            oGui.addTV(SITE_IDENTIFIER, 'dizifulltr2', sGenre, '', '', '', oOutputParameterHandler)
        

    oGui.setEndOfDirectory()    
def dizifulltr2(): #affiche les genres
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    oRequestHandler = cRequestHandler(sUrl)
    data = oRequestHandler.request();
                            
    playlist = re.findall('</a><div class="date hidden-xs">.*?<a title="(.*?)" href="(.*?)">', data, re.S)
    for sGenre,sUrl in playlist:
            
            sGenre = alfabekodla(sGenre)    
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sGenre)
            oGui.addTV(SITE_IDENTIFIER, 'play__dizi', sGenre, '', '', '', oOutputParameterHandler)
        

    oGui.setEndOfDirectory()    

def hextranslate(s):
        res = ""
        for i in range(len(s)/2):
                realIdx = i*2
                res = res + chr(int(s[realIdx:realIdx+2],16))
        return res    
     


def play__dizi():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    rUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    name = alfabekodla(sTitle)
    data= requests.session().get(rUrl ,headers={"Referer": rUrl,"User-Agent": "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36","Host": "www.diziizlesene1.com","Connection": "Keep-Alive","Upgrade-Insecure-Requests": "1"}).text
 
    Url= re.findall('<p><ifram.*?src="(.*?)"', data, re.S)[0]
    Url = Url.replace('http://www.diziizlesene1.com/v/player/index.php?data=','')
    if  "/watch/" in Url:
       play2dizifulltr(Url)
    elif  "/y/vid/" in Url:
       play2dizifulltr(Url)
    elif "dailymotion" in Url:
       if not 'http' in  Url:
          Url = 'https:'+ Url
       lHosters(Url)
    else: 
                      
       list_url ='http://www.diziizlesene1.com/v/player/index.php?data='+Url +'&do=getVideo' 
#       url ='http://www.diziizlesene1.com/v/player/index.php?data='+Url+'&do=getVideo' 
       req = urllib2.Request(list_url)
       
#       req.add_header('Accept','*/*')
#       req.add_header('Accept-Encoding','gzip, deflate')
#       req.add_header('Accept-Language','en-US,en;q=0.9,de;q=0.8')
#       req.add_header('Connection','keep-alive')
#       req.add_header('Content-Type','application/x-www-form-urlencoded; charset=UTF-8')
#       req.add_header('Connection','keep-alive')                
#       req.add_header('Cookie','_cfduid=d14e53cd149f15c4d06679c51e030cfbd1559382970; _ga=GA1.2.526040622.1559382970; _gid=GA1.2.488324434.1559382970; PHPSESSID=dcearrgc9t3k97r5kqij11e3uj; _gat=1; GED_PLAYLIST_ACTIVITY=W3sidSI6InJhdlAiLCJ0c2wiOjE1NTk0MTc4NzYsIm52IjowLCJ1cHQiOjE1NTk0MDI3OTgsImx0IjoxNTU5NDAyNzk4fSx7InUiOiIxVTNrIiwidHNsIjoxNTU5NDE3ODc1LCJudiI6MSwidXB0IjoxNTU5NDE3NTEyLCJsdCI6MTU1OTQxNzg3NX0seyJ1Ijoibi9HVSIsInRzbCI6MTU1OTQxNzg3NSwibnYiOjAsInVwdCI6MTU1OTQwMzkwNCwibHQiOjE1NTk0MDM5MDZ9XQ..') 
#       req.add_header('Host','www.diziizlesene1.com')
       req.add_header('Referer',''+rUrl) 
       req.add_header('User-Agent','Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36')
       req.add_header('X-Requested-With','XMLHttpRequest') 
       post={ "hash": Url,"r": rUrl}
#	post={'connect_user':userName,'connect_password':password}
       post = urllib.urlencode(post)
       sHtml=  _get(req,post)
       sHtml = sHtml.replace('\/','/')
       url= re.findall('"file":"(.*?)"', sHtml, re.S)[0]
       if  "mars.inxy.co" in url:
           m3u8Box3(url)
       else:
           url= url
           addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,url,'')
def play2dizifulltr(sUrl): #affiche les genres
    oGui = cGui()
   
    oRequestHandler = cRequestHandler(sUrl)
    data = oRequestHandler.request();
  
		                      
    playlist = re.findall('file:"(.*?)",.*?label: "(.*?)",', data, re.S)
    for sUrl,sGenre in playlist:
            
            sGenre = alfabekodla(sGenre)    
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oGui.addTV(SITE_IDENTIFIER, 'sshowBox3', sGenre, '', '', '', oOutputParameterHandler)
        

    oGui.setEndOfDirectory()  

def lHosters(Url):
    oGui = cGui()
 
    
    sMovieTitle = 'sMovieTitle'
    sThumbnail = 'sThumbnail'
    
    sHosterUrl = Url
    
  
    oHoster = cHosterGui().checkHoster(sHosterUrl)

    if (oHoster != False):
        
        sMovieTitle = cUtil().DecoTitle(sMovieTitle)
        
        
        
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumbnail)

    oGui.setEndOfDirectory()
def showMovies(sSearch = ''):
    oGui = cGui()
   
    if sSearch:
        #on redecode la recherhce codé il y a meme pas une seconde par l'addon
        sSearch = urllib2.unquote(sSearch)
 
        query_args = { 'do' : 'search' , 'subaction' : 'search' , 'story' : str(sSearch) , 'x' : '0', 'y' : '0'}
        
        #print query_args
        
        data = urllib.urlencode(query_args)
        headers = {'User-Agent' : 'Mozilla 5.10'}
        url = 'http://www.voirfilms.org/rechercher'
        request = urllib2.Request(url,data,headers)
     
        try:
            reponse = urllib2.urlopen(request)
        except URLError, e:
            print e.read()
            print e.reason
     
        sHtmlContent = reponse.read()
        #sPattern = '<div class="imagefilm">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
        sPattern = '<div class="fixwidt.*?">.*?<a href="(.*?)">.*?<img class="izimg" src="(.*?)" alt="(.*?)"'
 
    else:
        oInputParameterHandler = cInputParameterHandler()
        Url = oInputParameterHandler.getValue('siteUrl')
        sUrl='http://www.diziizlehdfulltr.com/?cat='+ Url
        oRequestHandler = cRequestHandler(sUrl)
        sHtmlContent = oRequestHandler.request()

        #sPattern = '<div class="imagefilm"> *<a href="(.+?)" title="(.+?)".+?<img src="(.+?)" alt="(.+?)"'
        sPattern = '<div class="fixwidt.*?">.*?<a href="(.*?)".*?<img class="izimg" src="(.*?)" alt="(.*?)"'
    
    sHtmlContent = sHtmlContent.replace('\n','')
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = cUtil().unescape(aEntry[2])
            sPicture = str(aEntry[1])
            if not 'http' in sPicture:
                sPicture = str(URL_MAIN) + sPicture
                
            sUrl = str(aEntry[0])
            if not 'http' in sUrl:
                sUrl = str(URL_MAIN) + sUrl
           
            #not found better way
            #sTitle = unicode(sTitle, errors='replace')
            #sTitle = sTitle.encode('ascii', 'ignore').decode('ascii')
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', sPicture) #sortis du poster
 
            if '/serie/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            elif '/anime/' in aEntry[1]:
                oGui.addTV(SITE_IDENTIFIER, 'serieHosters', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'sinemaPart', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
           
        if not sSearch:
            sNextPage = __checkForNextPage(sHtmlContent)#cherche la page suivante
            if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
                #Ajoute une entrer pour le lien Next | pas de addMisc pas de poster et de description inutile donc
 
    if not sSearch:
        oGui.setEndOfDirectory()
  
def __checkForNextPage(sHtmlContent):
    sPattern = '</span><a href="(.+?)" class="single_page" title=".+?">'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        sUrl = aResult[1][0]
        return sUrl

    return False
 

def Hosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')
    
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request();

    sPattern = '<a href="(http://www.diziizlehdfull.org/.*?)"><span>(.*?)</span>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            
            sTitle = sMovieTitle+' - '+aEntry[1]
            
            sDisplayTitle = cUtil().DecoTitle(sTitle)
            
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', str(aEntry[0]))
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oOutputParameterHandler.addParameter('sThumbnail', str(sThumbnail))
            oGui.addTV(SITE_IDENTIFIER, 'showHosters', sDisplayTitle, '', sThumbnail, '', oOutputParameterHandler)

        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory()

def sinemaPart():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')                  
    liste = []
    liste.append( ['Part 1',sUrl+'/'] )
    liste.append( ['Part 2',sUrl+'/2'] )
    liste.append( ['Part 3',sUrl+'/3'] )
    liste.append( ['Tek Parca izle',sUrl+'/4'] )
    liste.append( ['Alternatif',sUrl+'/5'] )
    liste.append( ['Alternatif',sUrl+'/6'] )
    
               
    for sTitle,sUrl in liste:
        
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('sMovieTitle',sTitle)
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oGui.addDir(SITE_IDENTIFIER, 'showHosters', sTitle, 'genres.png', oOutputParameterHandler)
       
    oGui.setEndOfDirectory()

def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request();
    sHtmlContent = sHtmlContent.replace('<iframe src="//www.facebook.com/','')


    sPattern = '<iframe.+?src=[\'|"](.+?)[\'|"]'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break

            sHosterUrl = str(aEntry)

            #oHoster = __checkHoster(sHosterUrl)
            oHoster = cHosterGui().checkHoster(sHosterUrl)

            if (oHoster != False):
                sDisplayTitle = cUtil().DecoTitle(sMovieTitle)
                oHoster.setDisplayName(sDisplayTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumbnail)

        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory()


def m3u8Box3(rUrl):
    oGui = cGui()
                
                
    Content= requests.session().get(rUrl ,headers={"Referer": rUrl,"User-Agent": "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36","Connection": "Keep-Alive","Upgrade-Insecure-Requests": "1"}).text
    sHtmlContent = re.findall('#EXT-X-STREAM-INF:.*?,RESOLUTION=.*?x(.*?)\n(.*?)\n', Content, re.S)
    for sTitle,Url  in sHtmlContent:    

            
           
            Title = alfabekodla(sTitle)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sMovieTitle', Title)
    
            oOutputParameterHandler.addParameter('siteUrl', Url)
           
            oGui.addTV(SITE_IDENTIFIER, 'sshowBox3', Title, '', '', '', oOutputParameterHandler)

        
    oGui.setEndOfDirectory()


def sshowBox3():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sHosterUrl = oInputParameterHandler.getValue('siteUrl')+ TIK
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    sTitle = alfabekodla(sTitle)
    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sTitle)
    oGuiElement.setMediaUrl(sHosterUrl)
    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    oPlayer.startPlayer()  
    

def MakeToken(sLoc):
        
        def base36encode(number):
            if not isinstance(number, (int, long)):
                raise TypeError('number must be an integer')
            if number < 0:
                raise ValueError('number must be positive')
            alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
            base36 = ''
            while number:
                number, i = divmod(number, 36)
                base36 = alphabet[i] + base36
            return base36 or alphabet[0]
            
        #oRequest = cRequestHandler('http://www.wat.tv/servertime2')
        #stime = oRequest.request()
        #stime = base36encode(int(stime))
            
        stime = base36encode(int(time.time()))

        timesec = hex(int(stime, 36))[2:]
        while(len(timesec)<8):
            timesec = "0" + timesec

        key = '9b673b13fa4682ed14c3cfa5af5310274b514c4133e9b3a81e6e3aba009l2564'
        token = md5.new(key + sLoc + timesec).hexdigest() + '/' + timesec
        return token