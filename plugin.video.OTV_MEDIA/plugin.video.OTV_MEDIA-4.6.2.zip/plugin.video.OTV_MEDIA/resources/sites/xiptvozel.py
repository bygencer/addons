#-*- coding: utf-8 -*-
import urllib2, urllib,cookielib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, zipfile, re, stat, xbmcvfs, base64
from resources.lib.otvhelper import  gegetUrl,getUrl ,alfabekodla
from resources.lib.config import cConfig
import requests
import re,xbmcgui,unicodedata
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress, VSlog

import re
from resources.lib.gui.guiElement import cGuiElement

import time    
from datetime import datetime
from resources.lib.player import cPlayer
from resources.lib.kplayer  import Player


import requests
import string
import random
import time
import uuid
from base64 import b64encode, b64decode
from hashlib import md5


from sqlite3 import dbapi2 as sqlite


ddatam_url='http://app.liveplanettv.com/beta/api.php?device_id=354630080742220'   


import urllib2, urllib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, zipfile, re, stat, xbmcvfs, base64
SITE_IDENTIFIER = 'xiptvozel'
from resources.lib.config import cConfig

from resources.lib.instaladdons import Enableaddons,enableaddons
import sys
import urllib2,urllib,cgi, re
import cookielib
cj = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
TIK='|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36'

def _get(request,post=None):
    """Performs a GET request for the given url and returns the response"""
    return opener.open(request,post).read()

da_url= 'http://glazandroid.com/andr/chas-online-json-1.5.php'
#http://139.59.68.238/stm-v3/api/def2.php?id=723&quality=0&type=0
Host = 'https://raw.githubusercontent.com/PrivateTr/Zone_enigma/master/userbouquet.Remy_IPTV2.tv'
Hostbir = 'https://raw.githubusercontent.com/PrivateTr/Zone_enigma/master/userbouquet.Remy_IPTV1.tv'
              
s = requests.Session()
useragent = 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Mobile Safari/537.36'
def okuoku(cba):
        oku = ""
        i = len(cba) - 1
        while i >= 0:
            oku += cba[i]
            i -= 1
        return oku        
url1="PXdXYjQ1Q1praDJMbWxUTTI4V2NrbFdadzRXY25KRE52TTNMdDkyWXVRbmJsUm5idk5tY2xOWGQ0OW1ZdzltY2s1Q2JrOXlMNk1IYzBSSGE="
url2 = base64.b64decode(url1)
url3 =  okuoku(url2)            
streamurl=base64.b64decode(url3)
import zipfile
def getUrl(url):
        pass#print "Here in getUrl url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
def ExtractAll(_in, _out):
    try:
        zin = zipfile.ZipFile(_in, 'r')
        zin.extractall(_out)
    except Exception, e:
        print str(e)
        return False

    return True
selfAddon = xbmcaddon.Addon()
ulkeLists = 'http://85.132.71.12/channels'
ulkeListem ='http://hyfystreamz.com/dfytv/list.json'
SITE_IDENTIFIER = 'xiptvozel'
SITE_NAME = 'IPTV OZEL'
MOVIE_VIEWS = (True, 'user_info')

icon = 'tv.png'

def getyoutubepage( url):
    headers = {'Host': 'www.youtube.com',
               'Connection': 'keep-alive',
               'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36',
               'Accept': '*/*',
               'DNT': '1',
               'Referer': 'https://www.youtube.com',
               'Accept-Encoding': 'gzip, deflate',
               'Accept-Language': 'en-US,en;q=0.8,de;q=0.6'}

    result = requests.get(url,  headers=headers, allow_redirects=True)
    return result.text


class getUrl(object):
    def __init__(self, url, close=True, proxy=None, post=None, headers=None, mobile=False, referer=None, cookie=None, output='', timeout='10'):
        handlers = []
        if not proxy == None:
            handlers += [urllib2.ProxyHandler({'http':'%s' % (proxy)}), urllib2.HTTPHandler]
            opener = urllib2.build_opener(*handlers)
            opener = urllib2.install_opener(opener)
        if output == 'cookie' or not close == True:
            import cookielib
            cookies = cookielib.LWPCookieJar()
            handlers += [urllib2.HTTPHandler(), urllib2.HTTPSHandler(), urllib2.HTTPCookieProcessor(cookies)]
            opener = urllib2.build_opener(*handlers)
            opener = urllib2.install_opener(opener)
        try:
            if sys.version_info < (2, 7, 9): raise Exception()
            import ssl; ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            handlers += [urllib2.HTTPSHandler(context=ssl_context)]
            opener = urllib2.build_opener(*handlers)
            opener = urllib2.install_opener(opener)
        except:
            pass
        try: headers.update(headers)
        except: headers = {}
        if 'User-Agent' in headers:
            pass
        elif not mobile == True:
            headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; rv:34.0) Gecko/20100101 Firefox/34.0'
        else:
            headers['User-Agent'] = 'Apple-iPhone/701.341'
        if 'referer' in headers:
            pass
        elif referer == None:
            headers['referer'] = url
        else:
            headers['referer'] = referer
        if not 'Accept-Language' in headers:
            headers['Accept-Language'] = 'en-US'
        if 'cookie' in headers:
            pass
        elif not cookie == None:
            headers['cookie'] = cookie
        request = urllib2.Request(url, data=post, headers=headers)
        response = urllib2.urlopen(request, timeout=int(timeout))
        if output == 'cookie':
            result = []
            for c in cookies: result.append('%s=%s' % (c.name, c.value))
            result = "; ".join(result)
        elif output == 'geturl':
            result = response.geturl()
        else:
            result = response.read()
        if close == True:
            response.close()
        self.result = result
 

class track():
    def __init__(self, length, title, path, icon,data=''):
        self.length = length
        self.title = title
        self.path = path
        self.icon = icon
        self.data = data



def rusya():
    oGui = cGui() 
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://')
    oGui.addDir('turkvod_org', 'TUrKVod', 'Russia TV+ Kino +EURASIA  TV', 'turkey-free-iptv.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://')
    oGui.addDir('iptvbox', 'Russia', 'Russia', 'turkey-free-iptv.png', oOutputParameterHandler)
    oOutputParameterHandler = cOutputParameterHandler()
    
    oOutputParameterHandler.addParameter('siteUrl', 'https://')
    oGui.addDir('iptvbox', 'peerstv', 'PeersTV', 'turkey-free-iptv.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()
                                

def iptvuser_info():
    oGui = cGui()
    liz=xbmcgui.ListItem('LIVE NET TV',thumbnailImage= "https://superrepo.org/static/images/icons/original/xplugin.video.xtream-codes.png.pagespeed.ic.7uLaZTpLY3.png",iconImage="DefaultFolder.png")
    uurl="plugin://script.module.otvlivetv3"
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), listitem=liz,url=uurl,isFolder=True)   
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://')
    oGui.addDir('LIVETV', 'roootom', 'LIVE NET TV1', 'turkey-free-iptv.png', oOutputParameterHandler)

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://')
    oGui.addDir('LINETV', 'LINETV2', 'LIVE NET TV2', 'turkey-free-iptv.png', oOutputParameterHandler)

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://')
    oGui.addDir('LINETV', 'root', 'LIVE NET TV3', 'turkey-free-iptv.png', oOutputParameterHandler)

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://')
    oGui.addDir(SITE_IDENTIFIER, 'rrootata', 'LIVE NET TV4', 'turkey-free-iptv.png', oOutputParameterHandler)

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://')
    oGui.addDir('LINETV', 'rootat', 'LIVE NET TV5', 'turkey-free-iptv.png', oOutputParameterHandler)

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://')
    oGui.addDir('LIVETV2', 'rooot', 'LIVE NET TV6', 'turkey-free-iptv.png', oOutputParameterHandler)
    

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://')
    oGui.addDir(SITE_IDENTIFIER, 'showContentB1', 'REMY TV E2', 'turkey-free-iptv.png', oOutputParameterHandler)


    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://')
    oGui.addDir('iptvbox', 'weebtv', 'Polski', 'turkey-free-iptv.png', oOutputParameterHandler)
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'https://dl.dropboxusercontent.com/s/9c13vo7kda5k3fu/script.module.otvlivetv3.zip')
    oGui.addDir(SITE_IDENTIFIER, 'satplaylive', 'LIVE NET TV..2x.YUKLE..INSTAL', 'turkey-free-iptv.png', oOutputParameterHandler)
    oGui.setEndOfDirectory()
#Enableaddons
#http://cdnapi.kaltura.com/p/1878761/sp/187876100/playManifest/entryId/1_usagz19w/flavorIds/1_5spqkazq,1_nslowvhp,1_boih5aji,1_qahc37ag/format/applehttp/protocol/http/a.m3u8       

def satplaylive():
    Url = 'http://web.canlitvlive.io/kanallar/spor-kanallari.html'
#    header = {'Referer':Url,'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36 OPR/41.0.2353.69', 'Connection': 'keep-alive', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
    oRequest = cRequestHandler(Url)
    oRequest.addHeaderEntry('Referer', Url)
    oRequest.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36')
    oRequest.addHeaderEntry('Accept-Language', 'en-US,en;q=0.9,de;q=0.8')
#            oRequest.addHeaderEntry('Host', 'www.hdfilme.net')
#            oRequest.addHeaderEntry('Connection', 'keep-alive')
#            oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
#            oRequest.addHeaderEntry('Connection', 'keep-alive')
    sUrl = oRequest.request()
    name = 'sMovieTitle'
   # sUrl= re.findall("file: '(.*?)'",content, re.S)[0]    
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]' + name, sUrl, '')
s = requests.Session()
s.headers.update({"User-Agent": "Dalvik/2.1.0 (Linux; U; Android 5.1.1; AFTT Build/LVY48F)"})


user="b0ca81082dcc06351ba35edce6fcbbd5"
config =""

host = "echo-d.livenettv.io/data/1/"
package_name = "com.int.androidnettv"
sha1 = "39:A0:97:F6:A5:98:2E:2E:BE:15:4D:A4:36:8F:94:7A:97:EE:F9:FC"
                     
s = requests.Session()
s.headers.update({"User-Agent": "Dalvik/2.1.0 (Linux; U; Android 5.1.1; AFTT Build/LVY48F)"})
def id_generator(size=8, chars=string.ascii_lowercase + string.digits):
        return "".join(random.choice(chars) for _ in range(size))
def lmget_channel_list():
        login_url = "https://echo-i.livenettv.io/index"
        time_stamp = str(int(time.time() * 1000))
        allow = b64encode(
            "{time_md5}${package_name}${apk_cert_sha1}${time_stamp}${user_id}${provider}".format(
                time_md5=md5(time_stamp.encode()).hexdigest(),
                package_name=package_name,
                apk_cert_sha1=sha1,
                time_stamp=time_stamp,
                user_id=user,
                provider="2",
            ).encode()
        )
        data = {"ALLOW": allow}
        r = s.post(login_url, data=data)
        _key = r.json().get("funguo")
        _meta = r.headers["etag"].split(":")[0]
        _enc = r.headers["etag"].split(":")[1]
        _hash, _host = b64decode(_enc + "=" * (-len(_enc) % 4)).decode("utf-8").split("|")
        if _host.startswith("http"):
            host = _host + "data.nettv/"
        
           
        
        name ='test'
        addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,host,'')

def mmget_channel_list():
        login_url = "https://echo-i.livenettv.io/index"
        time_stamp = str(int(time.time() * 1000))
        allow = b64encode(
            "{time_md5}${package_name}${apk_cert_sha1}${time_stamp}${user_id}${provider}".format(
                time_md5=md5(time_stamp.encode()).hexdigest(),
                package_name=package_name,
                apk_cert_sha1=sha1,
                time_stamp=time_stamp,
                user_id=user,
                provider="2",
            ).encode()
        )
        data = {"ALLOW": allow}
        r = s.post(login_url, data=data)
        _key = r.json().get("funguo")
        _meta = r.headers["etag"].split(":")[0]
        _enc = r.headers["etag"].split(":")[1]
        _hash, _host = b64decode(_enc + "=" * (-len(_enc) % 4)).decode("utf-8").split("|")
        if _host.startswith("http"):
            host = _host + "data.nettv/"
        
        check = "1"
        headers = {
            "Referer": "https://echo-i.livenettv.io/index",
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 5.1.1; AFTT Build/LVY48F)",
#            "Meta": _meta,
#            "Authorization": "Basic aGVsbG9NRjpGdWNrb2Zm",
        }
        data = {"": ""}
        hos =  json.dumps(mylist, separators=(',', ':'))
        
                
        name ='test'
        addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]'+name,hos,'')
       
def mmget_channel_list():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url =  "https://dl.dropboxusercontent.com/s/1cq9anwx0lfv27g/sh.xml"                             
    
  
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'}
    data = requests.get(url, headers = headers).text
    data =data.replace('[COLOR blue]D[/COLOR]ONATION [COLOR blue]RS[/COLOR]IPTV',"")                              
                                         
    datadata= re.findall('<string name="s6023767_seccs">(.*?)</string>',data, re.S)
    datadata=str(datadata).replace('>',",").replace('<',",")                                 
                  
    title= re.findall('(\d+)',datadata, re.S)
    for dat in title:
               
                          sTitle= re.findall('<string name="s'+dat+'_tit">(.*?)</string>',data, re.S)[0] 
                          sTitle = alfabekodla(sTitle).replace('[COLOR blue]A[/COLOR]UTO',"")
                          
                          
                          sUrl ='s' + dat
                          oOutputParameterHandler = cOutputParameterHandler()
                          oOutputParameterHandler.addParameter('siteUrl', sUrl)
                         
                          oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
                          oGui.addDir(SITE_IDENTIFIER, 'channellist', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory() 
def channellist():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    cat_id = oInputParameterHandler.getValue('siteUrl')
    url =  "https://dl.dropboxusercontent.com/s/1cq9anwx0lfv27g/sh.xml"                             
    
  
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'}
    data = requests.get(url, headers = headers).text
    data =data.replace('[COLOR blue]D[/COLOR]ONATION [COLOR blue]RS[/COLOR]IPTV',"")                              
                                         
    datadata= re.findall('<string name="'+cat_id+'_seccs">(.*?)</string>',data, re.S)
    datadata=str(datadata).replace('>',",").replace('<',",")                                 
                  
    title= re.findall('(\d+)',datadata, re.S)
    for dat in title:
                          
                          sTitle= re.findall('<string name="s'+dat+'_tit">(.*?)</string>',data, re.S)[0] 
                          sTitle = alfabekodla(sTitle).replace('[COLOR blue]A[/COLOR]UTO',"")
                          sUrl= re.findall('<string name="s'+dat+'_url">(.*?)</string>',data, re.S)[0] 
                          if 'yadi.sk' in sUrl:
                                headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'}
                                datak = requests.get(sUrl, headers = headers).text
                                sUrl= re.findall('"dimension":"adaptive","size":.*?,"url":"(.*?)"',datak, re.S)[0] 
                          oOutputParameterHandler = cOutputParameterHandler()
                          oOutputParameterHandler.addParameter('siteUrl', sUrl)
                         
                          oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
                          oGui.addDir(SITE_IDENTIFIER, 'pplay__rabictv', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory() 
def ASCIIDecode(string):

    i = 0
    l = len(string)
    ret = ''
    while i < l:
        c =string[i]
        if string[i:(i + 2)] == '\\x':
            c = chr(int(string[(i + 2):(i + 4)], 16))
            i+= 3
        if string[i:(i + 2)] == '\\u':
            cc = int(string[(i + 2):(i + 6)], 16)
            if cc > 256:
                #ok c'est de l'unicode, pas du ascii
                return ''
            c = chr(cc)
            i+= 5
        ret = ret + c
        i = i + 1

    return ret
def decodeUN(a):
    
    s3= a.decode('unicode-escape')
   
        

def mmget_channel_list():
    oGui = cGui()
    ADDON_DATA_DIR = xbmc.translatePath(addon.getAddonInfo("path")).decode("utf-8")
    path = os.path.abspath(os.path.join(ADDON_DATA_DIR, "sites"))
    
    for foldername in os.listdir(path):
        if foldername.startswith(".") or (foldername.endswith("py") 
                                      or foldername.endswith("pyc")):
            continue 
        zeile = foldername.strip().split(".")
        urls = zeile[0].replace('__init__', '')
                     
                         
        item ='siteUrl'
#        names = names.replace('.pyo', '').replace('.py', '').replace('__init__', '')
        patho = os.path.abspath(os.path.join(path, "%s.py"% urls))
        d = open(patho)
        content = d.read()

        d.close              

        wmsAuth = re.findall("SITE_NAME = '(.*?)'",content, re.S)[0]        
        addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]' + item, wmsAuth , '')	


  	   



def mget_channel_list():
               
                          
                    
    oGui = cGui()
    ADDON_DATA_DIR = xbmc.translatePath(addon.getAddonInfo("path")).decode("utf-8")
    path = os.path.abspath(os.path.join(ADDON_DATA_DIR, "sites"))
    
    for foldername in os.listdir(path):
        if foldername.startswith(".") or (foldername.endswith("py") 
                                      or foldername.endswith("pyc")):
            continue 
        zeile = foldername.strip().split(".")
        urls = zeile[0]
                     
                        
        patho = os.path.abspath(os.path.join(path, ""+urls+".py"))
        d = open(patho)
        content = d.read()
        d.close              
        cont= re.findall("SITE_NAME = '(.*?)'.*?SITE_ICON = '(.*?)'",content, re.S)
        for NAME,sPicture in cont:
        
       
             oOutputParameterHandler = cOutputParameterHandler()
             oOutputParameterHandler.addParameter('siteUrl',  urls)
             oOutputParameterHandler.addParameter('sMovieTitle', urls)
             oGui.addDir(SITE_IDENTIFIER, 'testzest',NAME, sPicture, oOutputParameterHandler)
    oGui.setEndOfDirectory()	


def testzest():        
   oInputParameterHandler = cInputParameterHandler()
   sSiteName = oInputParameterHandler.getValue('siteUrl')
   plugins = __import__('sites.%s' % sSiteName, fromlist=[sSiteName])
   function = getattr(plugins, 'load')
   function()                                                                                         

def maddLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok        
        
        
def eLIVETV():
          oGui = cGui()
          oInputParameterHandler = cInputParameterHandler()
          cat_id = oInputParameterHandler.getValue('siteUrl')
          liste = 'http://swiftstreamz.com/SwiftPanel/apiv1.php?get_channels_by_cat_id=28'
          sJson = cRequestHandler(liste).request()    

          sPattern = '"stream_url": "(.*?)".*?"token": "(.*?)"'
          jsonOb = re.compile(sPattern,re.DOTALL).findall(sJson )
          for  urll,token in  jsonOb:
           -1 
           for i in ( len(- 1) ): 
                      
#            EARNINGS = slice(0)
            stop = step = None
            start = 25
            string =''
            name=  "TOKEN TYPE"
            url =start[i:0]
            sPicture = 'http://swiftstreamz.com/SwiftPanel/apiv1.php?get_channels_by_token_link=28'
           
         
           
            addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]' + name, url, '')




def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&#039;',"'")
	char = char.replace('&quot;','"')
	char = char.replace('&nbsp;',".").replace('&amp;','&')
	return char	
class JsUnwiser:
    def unwiseAll(self, data):
        try:
            in_data=data
            sPattern = 'eval\\(function\\(w,i,s,e\\).*?}\\((.*?)\\)'
            wise_data=re.compile(sPattern).findall(in_data)
            for wise_val in wise_data:
                unpack_val=self.unwise(wise_val)
                in_data=in_data.replace(wise_val,unpack_val)
            return re.sub(re.compile("eval\(function\(w,i,s,e\).*?join\(''\);}", re.DOTALL), "", in_data, count=1)
        except: 
            traceback.print_exc(file=sys.stdout)
            return data
        
    def containsWise(self, data):
        return 'w,i,s,e' in data
        
    def unwise(self, sJavascript):
        page_value=""
        try:        
            ss="w,i,s,e=("+sJavascript+')' 
            exec (ss)
            page_value=self.__unpack(w,i,s,e)
        except: traceback.print_exc(file=sys.stdout)
        return page_value
        
    def __unpack( self,w, i, s, e):
        lIll = 0;
        ll1I = 0;
        Il1l = 0;
        ll1l = [];
        l1lI = [];
        while True:
            if (lIll < 5):
                l1lI.append(w[lIll])
            elif (lIll < len(w)):
                ll1l.append(w[lIll]);
            lIll+=1;
            if (ll1I < 5):
                l1lI.append(i[ll1I])
            elif (ll1I < len(i)):
                ll1l.append(i[ll1I])
            ll1I+=1;
            if (Il1l < 5):
                l1lI.append(s[Il1l])
            elif (Il1l < len(s)):
                ll1l.append(s[Il1l]);
            Il1l+=1;
            if (len(w) + len(i) + len(s) + len(e) == len(ll1l) + len(l1lI) + len(e)):
                break;
            
        lI1l = ''.join(ll1l)
        I1lI = ''.join(l1lI)
        ll1I = 0;
        l1ll = [];
        for lIll in range(0,len(ll1l),2):
            ll11 = -1;
            if ( ord(I1lI[ll1I]) % 2):
                ll11 = 1;
            l1ll.append(chr(    int(lI1l[lIll: lIll+2], 36) - ll11));
            ll1I+=1;
            if (ll1I >= len(l1lI)):
                ll1I = 0;
        ret=''.join(l1ll)
        if 'eval(function(w,i,s,e)' in ret:
            ret=re.compile('eval\(function\(w,i,s,e\).*}\((.*?)\)').findall(ret)[0] 
            return self.unwise(ret)
        else:
            return ret

def addOfflineMediaFile(urla,name):
        
      if 'plugin' in urla:  
          liz=xbmcgui.ListItem('',thumbnailImage= "https://superrepo.org/static/images/icons/original/xplugin.video.xtream-codes.png.pagespeed.ic.7uLaZTpLY3.png",iconImage="DefaultFolder.png")
          uurl=""+ urla
          xbmcplugin.addDirectoryItem(int(sys.argv[1]), listitem=liz,url=uurl,isFolder=True)
       

 
def Russia():
    oGui = cGui()
    sJson = cRequestHandler(da_url).request()    
    aJson = json.loads(sJson)
    
    for cat in aJson["channels"]:
            catid =cat['id']
            sTitle =cat['name']
            sPic=cat['logo']
            cat=cat['stream']
#            sTitle = alfabekodla(sTitle)
            sPicture=''+ sPic 
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl',cat )
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)            
            oOutputParameterHandler.addParameter('sThumbnail',  sPicture) 
            oGui.addMovie(SITE_IDENTIFIER, 'pplay__rabictv', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
         
    oGui.setEndOfDirectory() 



def showContentB3(): 
                oGui = cGui()  
                content = getUrl(Hostbir)
                           
                pass#print "#DESCRIPTION ===(.*?)====
                regexcat = "#SERVICE 1:64:.*?:0:0:0:0:0:0:0::([\S\s]+?)#"
                match = re.compile(regexcat,re.DOTALL).findall(content)
                pass#print "match A=", match
                i = 0
                for sTitle in match:
                        
                        if i < 3:
                              i = i+1
                              continue
                        i = i+1 
                        # if (not "ADULTI" in name) and (not "VINTAGE ITALIANO Film Completi" in name):
                              # continue     
                        url1 = Hostbir
                        sPicture= " "
                        oOutputParameterHandler = cOutputParameterHandler()
                        oOutputParameterHandler.addParameter('siteUrl',  url1)
                        oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
                        oOutputParameterHandler.addParameter('sThumbnail', sPicture) #sortis du poster
 
                        oGui.addMovie(SITE_IDENTIFIER, 'showContentB2',sTitle, sPicture, sPicture, '', oOutputParameterHandler)

                oGui.setEndOfDirectory()

def showContentB1(): 
                oGui = cGui()  
#                content = getUrl(Host)
                content=cRequestHandler(Host).request()             
                pass#print "#DESCRIPTION ===(.*?)====
                regexcat = "★★(.+?)★★"
                match = re.compile(regexcat,re.DOTALL).findall(content)
                pass#print "match A=", match
                i = 0
                for sTitle in match:
                        
                        if i < 3:
                              i = i+1
                              continue
                        i = i+1 
                        # if (not "ADULTI" in name) and (not "VINTAGE ITALIANO Film Completi" in name):
                              # continue     
                        url1 = Host
                        sPicture= " "
                        oOutputParameterHandler = cOutputParameterHandler()
                        oOutputParameterHandler.addParameter('siteUrl',  url1)
                        oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
                        oOutputParameterHandler.addParameter('sThumbnail', sPicture) #sortis du poster
 
                        oGui.addMovie(SITE_IDENTIFIER, 'showContentB2',sTitle, sPicture, sPicture, '', oOutputParameterHandler)

                oGui.setEndOfDirectory()

def showContentB2():
	oGui = cGui()
	oInputParameterHandler = cInputParameterHandler()
	url = oInputParameterHandler.getValue('siteUrl')
	name = oInputParameterHandler.getValue('sMovieTitle')
	content=cRequestHandler(url).request()
	pass#print "content B =", content
	name = name.replace("+", " ")
	name = name.replace("%20", " ")
	pass#print "name B =", name
	n1 = content.find(name, 0)
	n2 = content.find("---", (n1+100))
	if n2 > -1:
                 content2 = content[n1:n2]
        else:          
                 content2 = content[n1:]
        pass#print "content2 =", content2         
	regexvideo = '#SERVICE 4097\:.*?\:.*?\:.*?\:.*?\:.*?\:.*?\:.*?\:.*?\:.*?\:(.*?)\:(.*?)#'
	match = re.compile(regexvideo,re.DOTALL).findall(content2)
        pass#print "match B=", match
        for url, name in match:
                 pic = " "
                 name = name[:-1]
                 name = name.replace('"', '')
                 name = name.replace('\n', '')
                 url = url.replace("%3a", ":")
                 Title = name
                 url1 = url
                 sPicture= " "
                 oOutputParameterHandler = cOutputParameterHandler()
                 oOutputParameterHandler.addParameter('siteUrl',  url1)
                 oOutputParameterHandler.addParameter('sMovieTitle', str(Title))
                 oOutputParameterHandler.addParameter('sThumbnail', sPicture) #sortis du poster
 
                 oGui.addMovie(SITE_IDENTIFIER, 'pplay__rabictv',Title, sPicture, sPicture, '', oOutputParameterHandler)

	oGui.setEndOfDirectory()





def wmsAuth():    
    son = cRequestHandler(ddatam_url).request() 
    wmsAuth = re.findall('"wmsAuthSign": "(.*?)"',son, re.S)[0]
   
    return  wmsAuth
def Auth():    
       req = urllib2.Request(ddatam_url)
       req.add_header('User-Agent','Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-G965N Build/NRD90M)')
       req.add_header('Host','app.liveplanettv.com') 
       req.add_header('Connection','Keep-Alive')
       req.add_header('Accept-Encoding','gzip') 
       son=  _get(req)  
       wmsAuth = re.findall('"wmsAuthSign": "(.*?)"',son, re.S)[0]
       list_url='http://app.liveplanettv.com/beta/token.php?wmsAuthSign='+wmsAuth+'&device_id=354630080742220'
       req = urllib2.Request(list_url)
       
#       req.add_header('Accept','*/*')
#       req.add_header('Accept-Encoding','gzip, deflate')
#       req.add_header('Accept-Language','en-US,en;q=0.9,de;q=0.8')
#       req.add_header('Connection','keep-alive')
#       req.add_header('Content-Type','application/x-www-form-urlencoded; charset=UTF-8')
#       req.add_header('Connection','keep-alive')                
#       req.add_header('Cookie','_cfduid=d14e53cd149f15c4d06679c51e030cfbd1559382970; _ga=GA1.2.526040622.1559382970; _gid=GA1.2.488324434.1559382970; PHPSESSID=dcearrgc9t3k97r5kqij11e3uj; _gat=1; GED_PLAYLIST_ACTIVITY=W3sidSI6InJhdlAiLCJ0c2wiOjE1NTk0MTc4NzYsIm52IjowLCJ1cHQiOjE1NTk0MDI3OTgsImx0IjoxNTU5NDAyNzk4fSx7InUiOiIxVTNrIiwidHNsIjoxNTU5NDE3ODc1LCJudiI6MSwidXB0IjoxNTU5NDE3NTEyLCJsdCI6MTU1OTQxNzg3NX0seyJ1Ijoibi9HVSIsInRzbCI6MTU1OTQxNzg3NSwibnYiOjAsInVwdCI6MTU1OTQwMzkwNCwibHQiOjE1NTk0MDM5MDZ9XQ..') 
       req.add_header('User-Agent','Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-G965N Build/NRD90M)')
       req.add_header('Host','app.liveplanettv.com') 
       req.add_header('Connection','Keep-Alive')
       req.add_header('Accept-Encoding','gzip') 
       sHtml=  _get(req)    
       wmsAuthSign = re.findall('"videoToken": "(.*?)"',sHtml , re.S)[0]
       return  wmsAuthSign

def mAuth():    
    son = cRequestHandler(ddatam_url).request() 
    wmsAuth = re.findall('"wmsAuthSign": "(.*?)"',son, re.S)[0]
   
    ddatam='http://app.liveplanettv.com/beta/token.php?wmsAuthSign='+wmsAuth+'&device_id=354630080742220'
    sJson = cRequestHandler(ddatam).request()  
    wmsAuthSign = re.findall('"wmsAuthSign": "(.*?)"',sJson , re.S)[0]
    return  wmsAuthSign
def nnwmsAuth():
      
            sJson = cRequestHandler(ddatam_url).request() 
            aJson = json.loads(sJson)
          
            for _token in aJson['LIVETV']['token']:
                Pic=_token
                wmsAuth=Pic.get['wmsAuthSign']
                              
                return wmsAuth                 
            
      
        	
def sEcho():
      s=str(time.strftime('%S'))
      if '01' in s:
     	  s=Auth()
     	  return s 
      if '02' in s:
      	s=Auth()
        return s 
      if '03' in s:	
        s=Auth()
        return s 
      if '04' in s:	
        s=Auth()
        return s 
      if '05' in s:	
        s=Auth()
        return s 
      if '06' in s:	
        s=Auth()
        return s 
      if '07' in s:	
        s=Auth()
        return s 
      if '08' in s:	
        s=Auth()
        return s 
      if '09' in s:	
        s=Auth()
        return s 
      if '10' in s:	
        s=Auth()
        return s 
      if '11' in s:	
        s=Auth()
        return s 
      if '12' in s:	
        s=Auth()
        return s 
      if '13' in s:	
        s=Auth()
        return s 
      if '14' in s:	
        s=Auth()
        return s 
      if '15' in s:	
        s=Auth()
        return s 
      if '16' in s:	
        s=Auth()
        return s
      if '17' in s:	
        s=Auth()
        return s 
      if '18' in s:	
        s=Auth()
        return s 
      if '19' in s:	
        s=Auth()
        return s 
      if '20' in s:	
        s=Auth()
        return s 
      if '21' in s:	
        s=Auth()
        return s 
      if '22' in s:	
        s=Auth()
        return s 
      if '23' in s:	
        s=Auth()
        return s 
      if '24' in s:	
        s=Auth()
        return s 
      if '25' in s:	
        s=Auth()
        return s 
      if '26' in s:	
        s=Auth()
        return s 
      if '27' in s:	
        s=Auth()
        return s 
      if '28' in s:	
        s=Auth()
        return s 
      if '29' in s:	
        s=Auth()
        return s 
      if '30' in s:	
        s=Auth()
        return s 
      if '31' in s:	
        s=Auth()
        return s 
      if '32' in s:	
        s=Auth()
        return s 
      if '33' in s:	
        s=Auth()
        return s 
      if '34' in s:	
        s=Auth()
        return s 
      if '35' in s:	
        s=Auth()
        return s 
      if '36' in s:	
        s=Auth()
        return s 
      if '37' in s:	
        s=Auth()
        return s 
      if '38' in s:	
        s=Auth()
        return s 
      if '39' in s:	
        s=Auth()
        return s 
      if '40' in s:	
        s=Auth()
        return s 
      if '41' in s:	
        s=Auth()
        return s 
      if '42' in s:	
        s=Auth()
        return s 
      if '43' in s:	
        s=Auth()
        return s 
      if '44' in s:	
        s=Auth()
        return s 
      if '45' in s:	
        s=Auth()
        return s 
      if '46' in s:	
        s=Auth()
        return s 
      if '47' in s:	
        s=Auth()
        return s 
      if '48' in s:	
        s=Auth()
        return s 
      if '49' in s:	
        s=Auth()
        return s 
      if '50' in s:	
        s=Auth()
        return s 
      if '51' in s:	
        s=Auth()
        return s 
      if '52' in s:	
        s=Auth()
        return s 
      if '53' in s:	
        s=Auth()
        return s 
      if '54' in s:	
        s=Auth()
        return s 
      if '55' in s:	
        s=Auth()
        return s 
      if '56' in s:	
        s=Auth()
        return s 
      if '57' in s:	
        s=Auth()
        return s 
      if '58' in s:	
        s=Auth()
        return s 
      if '59' in s:	
        s=Auth()
        return s 
      if '60' in s:	
        s=Auth()
        return s 
      return False


def rrootata():
    oGui = cGui()
    
    

    ddat='https://dl.dropboxusercontent.com/s/k1lovh8v9ry9cqn/ana.api.json'
    sJson=cRequestHandler(ddat).request()   
    aJson = json.loads(sJson)
    
    for cat in aJson["LIVETV"]["category"]:
            catid =cat['cid']
            sTitle =cat['category_name']
            sPic=cat['category_image']
            sTitle = alfabekodla(sTitle)
            sPicture='http://app.liveplanettv.com/beta/images/'+ sPic 
         
            
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl',str(catid))
          
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))            
            oOutputParameterHandler.addParameter('sThumbnail',  sPicture) 
            oGui.addMovie(SITE_IDENTIFIER, 'tatLIVETV', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
         
    oGui.setEndOfDirectory() 
         

def tatLIVETV():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    catid = oInputParameterHandler.getValue('siteUrl')
    cat=cRequestHandler(catid).request()  
    aJson = json.loads(cat)
    for cat in aJson["LIVETV"]["category_detail"]:
            catid =cat['channel_url'] 
            sTitle =cat['channel_title']
            sPic=cat['channel_thumbnail']
            sTitle = alfabekodla(sTitle)
            sPicture='http://app.liveplanettv.com/beta/images/'+ sPic 
            
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl',catid)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))            
            oOutputParameterHandler.addParameter('sThumbnail',  sPicture) 
            oGui.addMovie(SITE_IDENTIFIER, 'play__rabictv', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
         

    oGui.setEndOfDirectory()  
    



     
def atplaylive():
    oInputParameterHandler = cInputParameterHandler()
    Urla = oInputParameterHandler.getValue('siteUrl')
    Url = 'http://139.59.68.238/stm-v3/api/def2.php?id=%s&quality=0&type=0'%Urla
    name = oInputParameterHandler.getValue('sMovieTitle')
    data=requests.session().get(Url,headers={"WWW-Authenticate": "IVYBOWQn+1rgFXNAWMDB06XjA=","User-Agent": "Dalvik/2.1.0 (Linux; U; Android 5.1.1; Nexus 6 Build/LYZ28N)","Host": "139.59.68.238","Connection": "Keep-Alive","Accept-Encoding": "gzip"}).text
    data = data.replace('\/','/')
    url = re.findall('"link": "(.*?)"',data, re.S)[0] +"|User-Agent=User-Agent=stagefright/1.2 (Linux;Android 5.1.1)"
    if not 'http' in url:     
        
       dat = b64decode(re.findall('"link": "(.*?)"',data, re.S)[0][2:])    
       liste = re.findall('(http://.*?.php),(http://.*?.m3u8)',dat, re.S)  
       if liste : 
          token, File = liste[0] 
          post_data = {"data": posta_data()}
          r = s.post(token, headers={"Content-Length": "101","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","Host": "swiftstreamz.com","Connection": "Keep-Alive","Accept-Encoding": "gzip"}, data=post_data, timeout=10)
          auth= r.text                                                                                                   
          token= 'http://hyfytv.today/decrypt1.php?token='+ auth 
          auth_token = cRequestHandler(token).request()     
          url = "{0}{1}|User-Agent={2}".format(File, auth_token, quote(player_user_agent))


#    liste = re.findall('"token": "VL(.*?)"',data, re.S)[0]    
#    datam = b64decode(liste)
#    listem = re.findall('"swt",".*?","1","aY(http://.*?)"',datam, re.S)[0] 
#    datama= b64decode(listem)
#    data= re.findall('"data":"(.*?)"',datama, re.S)[0]
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]' + name, url, '')


def sourcetvm3u():
	oGui = cGui()
     
        oInputParameterHandler = cInputParameterHandler()
        url = oInputParameterHandler.getValue('siteUrl')
        import re
	open = OPEN_URL(url)
	url  = regex_from_to(open,'<p><a href="','"')
	open = OPEN_URL(url)
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for sTitle,Url in regex:
	    sTitle =  alfabekodla(sTitle)
          
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl',  Url)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oGui.addDir(SITE_IDENTIFIER, 'iptvplay_info', sTitle, 'genres.png', oOutputParameterHandler)
	oGui.setEndOfDirectory()	

def rmootatam():
    oGui = cGui()
    sJson = cRequestHandler(ulkeLists).request()    
    aJson = json.loads(sJson)
    
    for cat in aJson:
            catid =cat['stream']
            sTitle =cat['name']
            sPic=cat['logo_file_name']
            sTitle = alfabekodla(sTitle)
            sPicture='http://apim.livetv.az/images/medium/'+ sPic 
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl',catid)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))            
            oOutputParameterHandler.addParameter('sThumbnail',  sPicture) 
            oGui.addMovie(SITE_IDENTIFIER, 'showtv', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
         
    oGui.setEndOfDirectory() 

def worldrootata():
    oGui = cGui()
    
    ulk ='http://hyfystreamz.com/dfytv/list.json'
    sJson = cRequestHandler(ulk).request()    
    aJson = json.loads(sJson)
    for cat in aJson["CATLIST"]:
            sTitle =cat['category']
        
            sPicture=cat['cat_img']
            sTitle = alfabekodla(sTitle)
           
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl',sTitle)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))            
            oOutputParameterHandler.addParameter('sThumbnail',  sPicture) 
            oGui.addMovie(SITE_IDENTIFIER, 'worldroota', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
         
    oGui.setEndOfDirectory() 
      
def worldroota():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    cat_title = oInputParameterHandler.getValue('siteUrl')
    ulk ='http://hyfystreamz.com/dfytv/list.json'
    sJson = cRequestHandler(ulk).request()    
    aJson = json.loads(sJson)
    for cat in aJson["TVLINK"]:
        if cat["country"] == cat_title:   
            sTitle =cat['name']
            url=cat['link']
            sPicture=cat['icon']
            sTitle = alfabekodla(sTitle)
            surl = b64decode(url[1:])
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl',surl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))            
            oOutputParameterHandler.addParameter('sThumbnail',  sPicture) 
            oGui.addMovie(SITE_IDENTIFIER, 'showtv', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
       
    oGui.setEndOfDirectory()      
def fatplaylive():
       #token 6 http://134.209.153.85/stm-v3/api/def2.php?id=1198&quality=0&type=0
       #token 13 http://134.209.153.85/stm-v3/api/def2.php?id=470&quality=0&type=0
       Url = 'http://139.59.68.238/stm-v3/api/def2.php?id=470&quality=0&type=0'
       data=requests.session().get(Url,headers={"WWW-Authenticate": "IVYBOWQn+1rgFXNAWMDB06XjA=","User-Agent": "Dalvik/2.1.0 (Linux; U; Android 5.1.1; Nexus 6 Build/LYZ28N)","Host": "134.209.153.85","Connection": "Keep-Alive","Accept-Encoding": "gzip"}).text
       liste = re.findall('"token": "(.*?)"',data, re.S)[0]    
       liste = b64decode(liste[2:]) 
       listem = re.findall('"swt","aYW10=","1","(.*?)"',liste, re.S)[0]  

       datama = b64decode(listem[2:]) 
       data= re.findall('"data":"(.*?)"',datama, re.S)[0]
       Urlum='http://swiftstreamz.com/newapptoken13.php'
       post = {"data":data, }
       
       req = urllib2.Request(Urlum)
                            
       req.add_header('User-Agent','Dalvik/2.1.0 (Linux; U; Android 5.1.1; Nexus 6 Build/LYZ28N)')
#       req.add_header('"WWW-Authenticate','IVYBOWQn+1rgFXNAWMDB06XjA=')
       req.add_header('Host','swiftstreamz.com')
       post = urllib.urlencode(post)
       autho=_get(req,post)  
       #post = {"type":"swt","source":"http://swiftstreamz.com/newapptoken13.php,http://212.8.253.141:7071/wildsci2019/animalplanet/playlist.m3u8", "data":"?wmsAuthSign=c2VydmVyX3RpbWU9Ni8yNy8yMDE5IDY6MTE6MjEgUE0maGFzaF92YWx1ZT1xcVlDc25lM1JnMmNvUDU2bThIeTh3PT0mdmFsaWRtaW51dGVzPTI=", "":""}
       post = {"data":data, }
                          
       Urlu='http://swiftstreamz.com/newapptoken13.php'                                       
       req = urllib2.Request(Urlu)
                            
       req.add_header('User-Agent','Dalvik/2.1.0 (Linux; U; Android 5.1.1; Nexus 6 Build/LYZ28N)')
       req.add_header('"WWW-Authenticate','IVYBOWQn+1rgFXNAWMDB06XjA=')
       req.add_header('Host','139.59.68.238')
       post = urllib.urlencode(post)
       auth=_get(req,post).replace('\/',"/")
       
       data=  "http://212.8.253.141:7071/wildsci2019/animalplanet/playlist.m3u8"+auth
       name =  "https://goo.gl/wqsVrs"  
       addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]' + name, data, '')
def miptv():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    url =  "https://goo.gl/wqsVrs"                             
    
  
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'}
    data = requests.get(url, headers = headers).text
    data =data.replace('[COLOR blue]D[/COLOR]ONATION [COLOR blue]RS[/COLOR]IPTV',"")                              
               
                      
    title= re.findall("<title>(.*?)</title>.*?<externallink>(.*?)</externallink>",data, re.S)
    for sTitle,sUrl in title:
               
                          
                          sTitle = alfabekodla(sTitle).replace('[COLOR blue]A[/COLOR]UTO',"")
                          
                          sUrl=sUrl.replace('$$TSDOWNLOADER$$',"") 
                          
                          oOutputParameterHandler = cOutputParameterHandler()
                          oOutputParameterHandler.addParameter('siteUrl', sUrl)
                         
                          oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
                          oGui.addDir(SITE_IDENTIFIER, 'motvshowGenre', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory() 
def iptvyeni():
    oGui = cGui()
     
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    
    

    data =gegetUrl(ulkeListem)
    
    
   #EXTINF:-1 logo="http://194.251.18.248:9981/imagecache/2" tvg-id="5d497c3cb1a7cf5e03bd4f314e9c1251", 
    
                          
    channels = re.findall('<title>(.*?)</title>.*?<jsonrpc>(.+?)</jsonrpc>', data, re.S)                                    
    for sTitle ,sUrl in channels: 
            
        sTitle =  alfabekodla(sTitle)
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        if sTitle == 'USA Ch.':
             oGui.addDir(SITE_IDENTIFIER, 'liste_channels',  sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'Movies':
             oGui.addDir(SITE_IDENTIFIER, 'liste_channels', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'Documentary':
             oGui.addDir(SITE_IDENTIFIER, 'liste_channels', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'Entertainment':
             oGui.addDir(SITE_IDENTIFIER, 'liste_channels', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'News':
             oGui.addDir(SITE_IDENTIFIER, 'liste_channels', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'Kids':
             oGui.addDir(SITE_IDENTIFIER, 'liste_channels', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'Sports':
             oGui.addDir(SITE_IDENTIFIER, 'liste_channels', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'LIVE NET TV3':
             oGui.addDir(SITE_IDENTIFIER, 'liste_channels', sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'Kurd-KarwanTV':
             oGui.addDir(SITE_IDENTIFIER, 'kurdtv',  sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'Russia':
             oGui.addDir(SITE_IDENTIFIER, 'peerstv',  sTitle, 'genres.png', oOutputParameterHandler)
        elif sTitle == 'Polski':
             oGui.addDir(SITE_IDENTIFIER, 'weebtv',  sTitle, 'genres.png', oOutputParameterHandler)

        else:
             oGui.addDir(SITE_IDENTIFIER, 'list_channels',  sTitle, 'genres.png', oOutputParameterHandler)

            
            
            
             
    
    oGui.setEndOfDirectory()
def iptvyeni2():
    
    oGui = cGui() 
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    
    

    calis=calisan()
    data =gegetUrl(calis)#.replace('\n',"")
    

    
                          
    channels= re.findall(''+sUrl, data)                                    
    
    
    for sTitle ,sUrl in channels: 
            
            sTitle =  alfabekodla(sTitle)
            sPicture ='https://i.ytimg.com/vi/qL8qgXZHJJE/hqdefault.jpg'
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oGui.addDir(SITE_IDENTIFIER, 'pplay__rabictv',  sTitle, 'genres.png', oOutputParameterHandler)
             
    
    oGui.setEndOfDirectory()



def play__rabictv():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    iconimage= oInputParameterHandler.getValue('sMovieTitle')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    sUrl = sUrl+Auth()+"|User-Agent=stagefright/1.2 (Linux;Android 5.1.1)"
    name =  alfabekodla(sTitle)
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    
    Player().play(sUrl,liz)

   
def pplay__rabictv():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
#    sUrl = sUrl+"|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36"
    iconimage= oInputParameterHandler.getValue('sMovieTitle')
    name =  alfabekodla(sTitle)
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    
    Player().play(sUrl,liz)
#    oGuiElement.setSiteName(SITE_IDENTIFIER)
#    oGuiElement.setTitle(sTitle)
#    oGuiElement.setMediaUrl(sUrl)
                
def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")                                                                  	

        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok  
#    oPlayer = cPlayer()
#    oPlayer.clearPlayList()
#    oPlayer.addItemToPlaylist(oGuiElement)
#    oPlayer.startPlayer()  

def iptv_in():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')                              
    
    urla  = "http://iptvsatlinks.blogspot.de/"
    referer=[('Referer',urla)]
    urlo=gegetUrl(sUrl,headers=referer) 
    urlo=urlo.replace('\r',"").replace('\s',"").replace('\n',"").replace('amp;',"").replace('<br />/get.php',"/get.php")                         
    if  '<br />#EXTINF:-1,' in urlo:
            title= re.findall('#EXTINF:-1,(.*?)<br />(.*?)<br />',urlo, re.S)
    
    else:
             title= re.findall('>(http://(.*?)/.*?)<',urlo, re.S)
    for sTitle,sUrl in title:
               
                          
                          
                          
                           
                                      
            
           
            sTitle = alfabekodla(sTitle)
            
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sTitle)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            if '.m3u8' in sUrl:
                oGui.addDir(SITE_IDENTIFIER, 'iptvplay_info', sTitle, 'genres.png', oOutputParameterHandler)
            elif '.ts'in  sUrl:
                 oGui.addDir(SITE_IDENTIFIER, 'iptvplay_info', sTitle, 'genres.png', oOutputParameterHandler)
            
            elif '/playlist'in  sTitle:
                 oGui.addDir(SITE_IDENTIFIER, 'motvshowGenre', sTitle, 'genres.png', oOutputParameterHandler)

            else:
                oGui.addDir(SITE_IDENTIFIER, 'miptvuser_inm', sTitle, 'genres.png', oOutputParameterHandler)
 
        
        
        
        
    oGui.setEndOfDirectory()


def miptvuser_inm():
    oGui = cGui()
    sHtml='https://www.oneplaylist.space/'
 
    url  = "https://www.oneplaylist.space/"
   
    time1=str(time.strftime('%d-'))
    time1=time1.replace('01',"1").replace('02',"2").replace('03',"3").replace('04',"4").replace('05',"5").replace('06',"6").replace('07',"7").replace('08',"8").replace('09',"9")      

    time2=str(time.strftime('%Y/%m'))   
    time2=time2.replace('01',"1").replace('02',"2").replace('03',"3").replace('04',"4").replace('05',"5").replace('06',"6").replace('07',"7").replace('08',"8").replace('09',"9").replace('217',"2017").replace('218',"2018")       
     
   
    urlo=OPEN_URL(url)                                                                                                                                               
   
    urlo=urlo.replace('| ',"").replace('\s',"").replace('\n',"").replace('amp;',"").encode('utf-8')                      
                                                                  
    
                                                             
        
    
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    title= re.findall('<span style="color:#000">(.+?)</span><span style="color:#06C">(.+?)</span><br />',urlo,re.IGNORECASE)
    for sTitle,sUrl in title:
            
           
            sTitle = alfabekodla(sTitle)
             
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            if '.m3u8' in sUrl:
                oGui.addDir(SITE_IDENTIFIER, 'iptvplay_info', sTitle, 'genres.png', oOutputParameterHandler)
            elif '.ts'in  sUrl:
                 oGui.addDir(SITE_IDENTIFIER, 'iptvplay_info', sTitle, 'genres.png', oOutputParameterHandler)
            
            elif '/playlist'in  sUrl:
                 oGui.addDir(SITE_IDENTIFIER, 'otvshowGenre', sTitle, 'genres.png', oOutputParameterHandler)

            else:
                oGui.addDir(SITE_IDENTIFIER, 'iptvuser_iptvuser', sTitle, 'genres.png', oOutputParameterHandler)

 
        
    oGui.setEndOfDirectory()


def showWeb():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    Url = oInputParameterHandler.getValue('siteUrl')
    Url = str(Url).replace('get.php','panel_api.php')
   
    
    urlo=OPEN_URL(Url)                                                
#    title= re.findall('"category_id":"(.*?)","category_name":"(.*?)","parent_id"',urlo,re.IGNORECASE)
    for a in urlo:

          sTitle = regex_from_to(a,'"category_name":"','"')
	  sUrl  = regex_from_to(a,'"category_id":"','"')
          oOutputParameterHandler = cOutputParameterHandler()
          oOutputParameterHandler.addParameter('siteUrl', sUrl)
          oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
          oGui.addDir(SITE_IDENTIFIER, 'iptvuser_iptvuser', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory()
def mshowWeb():    
    for png,sTitle,sUrl in playlist:
               
                        
                          sTitle = alfabekodla(sTitle)
                          
                           
                          
                          oOutputParameterHandler = cOutputParameterHandler()
                          oOutputParameterHandler.addParameter('siteUrl', sUrl)
                          oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
                          oGui.addDir(SITE_IDENTIFIER, 'iptvuser_iptvuser', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory() 
def iptvuser_in():
    oGui = cGui()
    sHtml='https://freeiptv4ever.com/'
 
    ssUrl  = "https://freeiptv4ever.com/download-iptv-turky"                  
  
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1', 'Referer': ssUrl, 'Connection': 'keep-alive', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
    sHtmlContent = requests.get(ssUrl, headers = headers).text                                                                                                                                                  
    oParser = cParser()
    sPattern = '<tbody class="row-hover">(.*?)<tr class="row-6 even">'
    aResult = oParser.parse(sHtmlContent, sPattern)
    sHtmlContent = aResult
    
    
    sPattern = '</td><td class="column-.*?">(.+?)</td><td class="column-.*?">(.+?)</td><td class="column-.*?"><a href="(.+?)"'
                                                               
           
   
    #fh = open('c:\\test.txt', "w")
    #fh.write(sHtmlContent)
    #fh.close()
    
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
   
    #print aResult
   
    if not (aResult[0] == False):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
       
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
           
            sTitle = aEntry[1]+':' + str(aEntry[0])
              
            sUrl = aEntry[2]
            
           
            sTitle = alfabekodla(sTitle)
            
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
          
            oGui.addDir(SITE_IDENTIFIER, 'otvshowGenre', sTitle, 'genres.png', oOutputParameterHandler)
 
        cConfig().finishDialog(dialog)
    oGui.setEndOfDirectory()
    
    
   
    
def miptvuser_info():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')                              
    
  
    referer=[('Referer',sUrl)]
                              
    data=gegetUrl(sUrl,headers=referer)                                            
    
    
    title= re.findall('(http://(.*?)/get.php?.*?type=m3u)',data, re.S)
    for sUrl,sTitle in title:
               
                        
                          sTitle = alfabekodla(sTitle)
                          
                           
                          
                          oOutputParameterHandler = cOutputParameterHandler()
                          oOutputParameterHandler.addParameter('siteUrl', sUrl)
                          oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
                          oGui.addDir(SITE_IDENTIFIER, 'iptvuser_iptvuser', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory() 
                                                                                            
    
#ssUrl= 'http://vip.goldtv.org:8000/panel_api.php?username=Elifsafak&password=Md0yNqoilL&type=m3u'
def motvshowGenre():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    
    

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    
   #EXTINF:-1 logo="http://194.251.18.248:9981/imagecache/2" tvg-id="5d497c3cb1a7cf5e03bd4f314e9c1251", 
    
    playlist = parseWebM3U(sUrl)                              
    for track in playlist: 
            url = str(track.path)
            sTitle =  str(track.title)
            sPicture =track.icon
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', url)
            oOutputParameterHandler.addParameter('sMovieTitle', str(sTitle))
            oGui.addMovie(SITE_IDENTIFIER, 'iptvplay_info', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
    oGui.setEndOfDirectory()

def wotvshowGenre():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    
    

    data =gegetUrl(ulkeLists)
    
    
   #EXTINF:-1 logo="http://194.251.18.248:9981/imagecache/2" tvg-id="5d497c3cb1a7cf5e03bd4f314e9c1251", 
    
    
    channels = re.findall('#EXTINF:-1,(.*?)\n(.*?)\n', data, re.S)                                    
    for sTitle ,sUrl in channels: 
            
            sTitle =  alfabekodla(sTitle)
            sPicture ='https://i.ytimg.com/vi/qL8qgXZHJJE/hqdefault.jpg'
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            if sTitle == 'Kurd-KarwanTV':
               oGui.addDir(SITE_IDENTIFIER, 'kurdtv',  sTitle, 'genres.png', oOutputParameterHandler)
            elif sTitle == 'Polski':
               oGui.addDir(SITE_IDENTIFIER, 'weebtv', sTitle, 'genres.png', oOutputParameterHandler)
            elif sTitle == 'Russia':
               oGui.addDir(SITE_IDENTIFIER, 'peerstv', sTitle, 'genres.png', oOutputParameterHandler)
            elif sTitle == 'French-racacaxtv':
               oGui.addDir(SITE_IDENTIFIER, 'racacaxtvga', sTitle, 'genres.png', oOutputParameterHandler)
            elif sTitle == 'IPTV_IPTV_int':
               oGui.addDir(SITE_IDENTIFIER, 'canlitvzoneBox', sTitle, 'genres.png', oOutputParameterHandler)

            else:
               oGui.addMovie(SITE_IDENTIFIER, 'list_channels', sTitle, sPicture, sPicture, '', oOutputParameterHandler)

    
    oGui.setEndOfDirectory()

def otvshowGenre():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    
    

    data=OPEN_URL(sUrl) 
    
    
    
    data = data.encode('utf-8') 
    channels = re.findall('#EXTINF:.*?,(.*?)\n(.*?)\n', data, re.S)                                    
    for sTitle ,sUrl in channels: 
           
            sTitle =  alfabekodla(sTitle)
            sPicture ='https://i.ytimg.com/vi/qL8qgXZHJJE/hqdefault.jpg'
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oGui.addMovie(SITE_IDENTIFIER, 'iptvplay_info', sTitle, sPicture, sPicture, '', oOutputParameterHandler)
       

        

       
    oGui.setEndOfDirectory()
def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")                                                                  	

        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok  
def iptvuser_iptvuser():#affiche les genres
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    ssUrl = oInputParameterHandler.getValue('siteUrl')
    ssUrl=ssUrl.replace('get.php','panel_api.php')
  
                                                                                                                                         
  
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 'Upgrade-Insecure-Requests': '1'}
    sHtmlContent = requests.get(ssUrl, headers = headers).text


               
    sPattern = '{"category_id":"(.*?)","category_name":"(.*?)","parent_id":.*?}'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            
            
            Link = aEntry[0]
            sTitle = aEntry[1]
            sTitle = alfabekodla(sTitle)
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('ssUrl', ssUrl)
            oOutputParameterHandler.addParameter('siteUrl', Link)
           
            oGui.addDir(SITE_IDENTIFIER, 'user_info3', sTitle, 'genres.png', oOutputParameterHandler)
                   

            
            
           
        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory() 
def miptvuser_iptvuser():#affiche les genres
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    ssUrl = oInputParameterHandler.getValue('siteUrl')
    ssUrl=str(ssUrl).replace('get.php','panel_api.php')
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1', 'Referer': ssUrl, 'Connection': 'keep-alive', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
    r = requests.get(ssUrl, headers = headers).text                
    js =r.json(strict=False)
    
    for a in js:
         sTitle = a['category_name']
         Link   = a['category_id']
        
         sTitle = alfabekodla(sTitle)
         oOutputParameterHandler = cOutputParameterHandler()
         oOutputParameterHandler.addParameter('ssUrl', ssUrl)
         oOutputParameterHandler.addParameter('siteUrl', Link)
           
         oGui.addDir(SITE_IDENTIFIER, 'user_info3', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory() 
def user_info3():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    ssUrl= oInputParameterHandler.getValue('ssUrl')
    sUrl= oInputParameterHandler.getValue('siteUrl')
       
  
    
  
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1', 'Referer': ssUrl, 'Connection': 'keep-alive', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
    data = requests.get(ssUrl, headers = headers).text
    sHosterUrl = re.findall('"username":"(.*?)","password":"(.*?)".*?"server_info":{"url":"(.*?)","port":"(.*?)"', data, re.S)
    (username,password,url,port) =sHosterUrl[0]
   
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1', 'Referer': ssUrl, 'Connection': 'keep-alive', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
    dat = requests.get(ssUrl, headers = headers).text
    dat = dat.replace('"container_extension":null,','"container_extension":"null"')                                     
    HosterUrl = re.findall('"category_id":"%s"'%sUrl+',"series_no".*?"tv_archive_duration":0},"(.*?)":{"num":.*?,"name":"(.*?)".*?"container_extension":"(.*?)"', dat, re.S)
    for mUrl,sTitle,mkUrl in HosterUrl:
       
       streamUrl = 'http://%s:%s/live/%s/%s/%s.%s' % (url,port,username,password,mUrl,mkUrl)
       streamUrl =streamUrl.replace('.null','.ts')
       sTitle = alfabekodla(sTitle)
       oOutputParameterHandler = cOutputParameterHandler()
       oOutputParameterHandler.addParameter('siteUrl',  streamUrl)
       oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
       oGui.addDir(SITE_IDENTIFIER, 'iptvplay_info', sTitle, 'genres.png', oOutputParameterHandler)
    oGui.setEndOfDirectory()

def showtv():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl= oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    
                             
    
     
#    sHosterUrl =  alfabekodla(sHosterUrl)
#    sHosterUrl =str(sHosterUrl)
    Header = 'User-Agent=VLC/3.0.6 LibVLC/3.0.6'
    sUrl= sUrl + '|' + Header 
    sTitle=  alfabekodla(sTitle) 
    cHosterGui().addLink(sTitle,sUrl,'')   
 
def Muser_info3(): #affiche les genres
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    ssUrl = oInputParameterHandler.getValue('ssUrl')
    
    referer=[('Referer',ssUrl)]
    data=gegetUrl(ssUrl,headers=referer) 
    sHosterUrl = re.findall('"username":"(.*?)","password":"(.*?)".*?"server_info":{"url":"(.*?)","port":"(.*?)"', data, re.S)
    (username,password,url,port) =sHosterUrl[0]

   
    


    oRequestHandler = cRequestHandler(ssUrl)
    sHtmlContent = oRequestHandler.request()
    sPattern = '"category_id":"%s"'%sUrl+',"series_no".*?"tv_archive_duration":0},"(.*?)":{"num":.*?,"name":"(.*?)"'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if (aResult[0] == True):
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
            sTitle = str(aEntry[1])
            
            
              
            Urll = 'http://%s:%s/live/%s/%s/%s.ts' % (url,port,username,password,aEntry[0])
            url2 = base64.b64encode(Urll)
    
            streamUrl=TURKIYE+url2

            
            
            sTitle =  alfabekodla(sTitle)
          
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl',  streamUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oGui.addDir(SITE_IDENTIFIER, 'iptvplay_info', sTitle, 'genres.png', oOutputParameterHandler)
        cConfig().finishDialog(dialog)

    oGui.setEndOfDirectory() 
    




class MyPlayer (xbmc.Player):
    def __init__ (self):
        xbmc.Player.__init__(self)

    def play(self, url, listitem):
        print 'Now im playing... %s' % url
        self.stopPlaying.clear()
        xbmc.Player( ).play(url, listitem)
        
    def onPlayBackEnded( self ):
        # Will be called when xbmc stops playing a file
        print "seting event in onPlayBackEnded " 
        self.stopPlaying.set();
        print "stop Event is SET" 
    def onPlayBackStopped( self ):
        # Will be called when user stops xbmc playing a file
        print "seting event in onPlayBackStopped " 
        self.stopPlaying.set();
        print "stop Event is SET" 


def _substitute_entity(match):
        ent = match.group(3)
        if match.group(1) == '#':
            # decoding by number
            if match.group(2) == '':
                # number is in decimal
                return unichr(int(ent))
            elif match.group(2) == 'x':
                # number is in hex
                return unichr(int('0x' + ent, 16))
        else:
            # they were using a name
            cp = n2cp.get(ent)
            if cp: return unichr(cp)
            else: return match.group()

def decode_html(data):
	try:
		if not type(data) == unicode:
			data = unicode(data, 'utf-8', errors='ignore')
		entity_re = re.compile(r'&(#?)(x?)(\w+);')
    		return entity_re.subn(_substitute_entity, data)[0]
	except:
		traceback.print_exc()
		#print [data]
		return data
def kodu(iyi):
    while iyi!=[0]:
      
      iyi=iyi
      return iyi
           

def getTotalLikedMedia( scan_rate= 1 ):
        next_id = ''
        liked_items = []
        for x in range(0, scan_rate):
            temp =getLikedMedia(next_id)
            temp = LastJson
            try:
                next_id = temp["next_max_id"]
                for item in temp["items"]:
                    liked_items.append(item)
            except KeyError as e:
                break
        return liked_items
              

def kRussia(): #affiche les genres
    oGui = cGui()
    urla  = "https://www.blutv.com.tr/int/diziler/yerli/bozkir-izle"                                
    cookie = getUrl(urla, output='cookie').result 
    req = urllib2.Request('https://www.blutv.com.tr/quark/content/getresults')
    req.add_header('Host','www.blutv.com.tr')
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 10.0; rv:67.0) Gecko/20100101 Firefox/67.0')
    req.add_header('Accept','application/json, text/html, text/javascript')
    req.add_header('Accept-Language',' en-US,en;q=0.5')
    req.add_header('Referer','https://www.blutv.com.tr/')
    req.add_header('access-control-allow-headers','Authorization,Date,x-amz-date')
    req.add_header('access-control-allow-methods','GET,POST,PUT,DELETE,BATCH,OPTIONS')
    req.add_header('access-control-allow-origin','*')
    req.add_header('access-control-allow-credentials','true')
    req.add_header('Connection','keep-alive')
    req.add_header('Cookie',''+cookie)
    post= {'category': 'dizi','order': '','platform': 'com.blu.lama','query': '','segment': 'default','take': '16'}
    post = urllib.urlencode(post)
    sJson =_get(req,post)
    
    for cat  in sJson['subtitles']:
     
            
          
                      
            stream = cat['id']
            sTitle =cat['Title']
            sPic=cat['Image']
          
                     
            name =  "https://goo.gl/wqsVrs"  
            addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]' + name, cat, '')


def lkRussia(): #affiche les genres
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    hssUrl = oInputParameterHandler.getValue('siteUrl')
    urla  = "https://www.blutv.com.tr/int/diziler/yerli/bozkir-izle"                                
    cookie = getUrl(urla, output='cookie').result 
    req = urllib2.Request('https://www.blutv.com.tr/quark/content/getcontent')
    req.add_header('Host','www.blutv.com.tr')
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 10.0; rv:67.0) Gecko/20100101 Firefox/67.0')
    req.add_header('Accept','application/json, text/html, text/javascript')
    req.add_header('Accept-Language',' en-US,en;q=0.5')
    req.add_header('Referer','https://www.blutv.com.tr/')
    req.add_header('access-control-allow-headers','Authorization,Date,x-amz-date')
    req.add_header('access-control-allow-methods','GET,POST,PUT,DELETE,BATCH,OPTIONS')
    req.add_header('access-control-allow-origin','*')
    req.add_header('access-control-allow-credentials','true')
    req.add_header('Connection','keep-alive')
    req.add_header('Cookie',''+cookie)
    post= {'package': 'ALL','segment': 'default','sessionid': '1','url': '/diziler/yerli/sifir-bir-bir-zamanlar-adanada/1-sezon/sifir-bir-bir-zamanlar-adanada-2-bolum'}
    post = urllib.urlencode(post)
    sHtmlContent =_get(req,post)
    url =sHtmlContent.replace('\\/', '/')
    name =  "https://goo.gl/wqsVrs"  
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]' + name, url, '')

def lkkRussia(): #affiche les genres
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    hssUrl = oInputParameterHandler.getValue('siteUrl')
    urla  = "https://www.blutv.com.tr/int/diziler/yerli/bozkir-izle"                                
    cookie = getUrl(urla, output='cookie').result 
    req = urllib2.Request('https://www.blutv.com.tr/quark/content/getcontent')
    req.add_header('Host','www.blutv.com.tr')
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 10.0; rv:67.0) Gecko/20100101 Firefox/67.0')
    req.add_header('Accept','application/json, text/html, text/javascript')
    req.add_header('Accept-Language',' en-US,en;q=0.5')
    req.add_header('Referer','https://www.blutv.com.tr/')
    req.add_header('access-control-allow-headers','Authorization,Date,x-amz-date')
    req.add_header('access-control-allow-methods','GET,POST,PUT,DELETE,BATCH,OPTIONS')
    req.add_header('access-control-allow-origin','*')
    req.add_header('access-control-allow-credentials','true')
    req.add_header('Connection','keep-alive')
    req.add_header('Cookie',''+cookie)
    post= {'id': hssUrl,'package': 'SVOD','segment': 'default'}
    post = urllib.urlencode(post)
    sHtmlContent =_get(req,post)
    url =sHtmlContent.replace('\\/', '/')
    name =  "https://goo.gl/wqsVrs"  
    addLink('[COLOR lightblue][B]OTV MEDIA >>  [/B][/COLOR]' + name, url, '')

def miptv():
    oGui = cGui()
    oParser = cParser()
    sPattern = '"Poster":"(.*?)","Source".*?,"Url":"(.*?)".*?"SeasonNumber":(.*?),"StartDate":".*?","Title":"(.*?)".*?"Id":".*?","Url":"(.*?)"'
    aResult = oParser.parse(sHtmlContent, sPattern)          
    
    if (aResult[0] == True):                                                                               
        total = len(aResult[1])
        dialog = cConfig().createDialog(SITE_NAME)
        for aEntry in aResult[1]:
            cConfig().updateDialog(dialog, total)
            if dialog.iscanceled():
                break
                
            surl = aEntry[4]
            sTitle ='Sezon-'+ aEntry[2]+' '+ aEntry[3]                                                           
            Referer = aEntry[1]
            sTitle = alfabekodla(sTitle)
            img = aEntry[0]
            sTitle = alfabekodla(sTitle)
            img ="https://dhaym0822ddy8.cloudfront.net/q/t/i/bluv2/85/600x338/"+ aEntry[0]
            
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', surl)
            oOutputParameterHandler.addParameter('Referer', Referer)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oGui.addTV(SITE_IDENTIFIER, 'piptvplay_info', sTitle, '',img, '', oOutputParameterHandler)
        cConfig().finishDialog(dialog)
        sNextPage =surl#cherche la page suivante
        if (sNextPage != False):
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'blutv_d1', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()     
                    

class MyPlayer (xbmc.Player):
    def __init__ (self):
        xbmc.Player.__init__(self)

    def play(self, url, listitem):
        print 'Now im playing... %s' % url
        self.stopPlaying.clear()
        xbmc.Player( ).play(url, listitem)
        
    def onPlayBackEnded( self ):
        # Will be called when xbmc stops playing a file
        print "seting event in onPlayBackEnded " 
        self.stopPlaying.set();
        print "stop Event is SET" 
    def onPlayBackStopped( self ):
        # Will be called when user stops xbmc playing a file
        print "seting event in onPlayBackStopped " 
        self.stopPlaying.set();
        print "stop Event is SET" 



def _m3u8Exit(self):
     import otv_kuresel
     otv_kuresel.yt_tmp_storage_dirty = True  
     
     
def parseWebM3U(infile):
    inf = urllib.urlopen(infile)

    line = inf.readline()

    if not line.startswith('#EXTM3U'):
       return

    playlist=[]
    song=track(None,None,None,None)
    ValidEntry = False

    for line in inf:
        line=line.strip()
        if line.startswith('#EXTINF:'):
            length,title=line.split('#EXTINF:')[1].split(',',1)
            try:
                licon = line.split('#EXTINF:')[1].partition('tvg-logo=')[2]
                icon = licon.split('"')[1]
            except:
                icon = "tv.png"
            ValidEntry = True

            song=track(length,title,None,icon)
        elif (len(line) != 0):
            if (ValidEntry) and (not (line.startswith('!') or line.startswith('#'))):
                ValidEntry = False
                song.path=line
                playlist.append(song)
                song=track(None,None,None,None)

    inf.close()

    return playlist

def parseM3U(infile):
    inf = open(infile,'r')

    line = inf.readline()
    if not line.startswith('#EXTM3U'):
       return

    playlist=[]
    song=track(None,None,None,None)
    ValidEntry = False

    for line in inf:
        line=line.strip()
        if line.startswith('#EXTINF:'):
            length,title=line.split('#EXTINF:')[1].split(',',1)
            song=track(length,title,None,None)
            ValidEntry = True
        elif (len(line) != 0):
            if (not line.startswith('!') and ValidEntry):
                ValidEntry = False
                song.path=line
                playlist.append(song)
                song=track(None,None,None,None)

    inf.close()

    return playlist


#http://libretv.me/Liste-m3u/Liste-anonymes/(PB)Marchannel.m3u
def parseLibretvM3U(sUrl):

    #print infile
    oRequestHandler = cRequestHandler(sUrl)
    inf = oRequestHandler.request()
    #version normale
#    inf = urllib.urlopen(infile)

    #version qui memorise les m3u
    #file = GetLibreTVFile(infile)
    #inf = open(file, "r")

#    line = inf.readline()

    playlist=[]

    #if not (line.startswith('#EXTM3U') or line.startswith('#EXTINF:')):
    #    return playlist

    song=track(None,None,None,None)

    ValidEntry = False

    for line in inf:
        line=line.strip()
        if line.startswith('#EXTINF:'):

            m = re.search(',([^,]+?)$', line)
            if m:
                title = m.groups(1)[0]
                length = 0

                ValidEntry = True

                m = re.search('tvg-logo="(.+?)"', line)
                if m:
                    logo = m.groups(1)[0]
                else:
                    logo = ''

                m = re.search('group-title="(.+?)"', line)
                if m:
                    data = m.groups(1)[0]
                else:
                    data = None

                song=track(length,title,None,logo,data)
        elif (len(line) != 0):
            if (not line.startswith('#') and ValidEntry):
                ValidEntry = False
                song.path=line
                playlist.append(song)
                song=track(None,None,None,None)

    inf.close()
    return playlist

cj = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
def _get(request,post=None):
    """Performs a GET request for the given url and returns the response"""
    return opener.open(request,post).read()
def calisana():
        oGui = cGui() 
        oInputParameterHandler = cInputParameterHandler()
        hssUrl = oInputParameterHandler.getValue('siteUrl')
        urla  = "http://www.teledunet.com/plugin_tv_login.php?referer=http%3A%2F%2Fwww.teledunet.com%2F"                                
        cookie = getUrl(urla, output='cookie').result 
        req = urllib2.Request('http://www.teledunet.com/')
        req.add_header('User-Agent','Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36')
        req.add_header('Referer','http://www.teledunet.com/')
        req.add_header('Host','www.teledunet.com')
        req.add_header('Cookie',''+cookie)
        req.add_header('Upgrade-Insecure-Requests','1')
        req.add_header('Connection','keep-alive')                
        req.add_header('Accept-Language','de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7') 
        req.add_header('Accept-Encoding','gzip, deflate')
        req.add_header('Accept','text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8')
        userName=selfAddon.getSetting( "teledunetTvLogin" )
	password=selfAddon.getSetting( "teledunetTvPassword" )
        post={'connect_user':userName,'connect_password':password}
        post = urllib.urlencode(post)
        _get(req,post)
        name ='http://www.teledunet.com/'  
	url ='http://www.teledunet.com/'
        req = urllib2.Request('http://www.teledunet.com/')
        req.add_header('User-Agent','Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36')
        req.add_header('Referer','http://www.teledunet.com/')
        req.add_header('Host','www.teledunet.com')
        req.add_header('Cookie',''+cookie)
        req.add_header('Upgrade-Insecure-Requests','1')
        req.add_header('Connection','keep-alive')                
        req.add_header('Accept-Language','de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7') 
        req.add_header('Accept-Encoding','gzip, deflate')
        req.add_header('Accept','text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8')
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36', 'Upgrade-Insecure-Requests':'1', 'Connection': 'keep-alive', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8','Cookie':cookie}
        data = requests.get(url, headers = headers).text
        data= unicodedata.normalize('NFD', data).encode('ascii', 'ignore')#vire accent
        data = data.encode( "utf-8")
        data = urllib.unquote_plus(data) 
        data = data.replace('�','')
        
        aut = re.findall("idu_curent_user='(.*?)'",data ,re.S)[0]
        sUrl="http://www.teledunet.com/load_playlist.php?world=1&link=1&idu="+aut             
        da = requests.get(sUrl, headers = headers).text
        da =  alfabekodla(da)
        channels= re.findall(""+hssUrl, da)                                    
    
    
        for sTitle ,Url in channels: 
            
            
            sPicture ='https://i.ytimg.com/vi/qL8qgXZHJJE/hqdefault.jpg'
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl',  str(Url))
            oGui.addDir(SITE_IDENTIFIER, 'play__rabictv',  sTitle, 'genres.png', oOutputParameterHandler)
             
    
        oGui.setEndOfDirectory()
def playf4m():
            oInputParameterHandler = cInputParameterHandler()
            name = oInputParameterHandler.getValue('sMovieTitle')
            url = oInputParameterHandler.getValue('siteUrl')    
            name=  alfabekodla(str(name)) 
            try:
                import urlparse,json
                if not any(i in url for i in ['.f4m', '.ts', '.m3u8']): raise Exception()
                ext = url.split('?')[0].split('&')[0].split('|')[0].rsplit('.')[-1].replace('/', '').lower()
                if not ext: ext = url
                if not ext in ['f4m', 'ts', 'm3u8']: raise Exception()

                params = urlparse.parse_qs(url)

                try: proxy = params['proxy'][0]
                except: proxy = None

                try: proxy_use_chunks = json.loads(params['proxy_for_chunks'][0])
                except: proxy_use_chunks = True

                try: maxbitrate = int(params['maxbitrate'][0])
                except: maxbitrate = 0

                try: simpleDownloader = json.loads(params['simpledownloader'][0])
                except: simpleDownloader = False

                try: auth_string = params['auth'][0]
                except: auth_string = ''


                try:
                   streamtype = params['streamtype'][0]
                except:
                   if ext =='ts': streamtype = 'TSDOWNLOADER'
                   elif ext =='m3u8': streamtype = 'HLS'
                   else: streamtype = 'HDS'

                try: swf = params['swf'][0]
                except: swf = None

                from F4mProxy import f4mProxyHelper
                return f4mProxyHelper().playF4mLink(url, name, proxy, proxy_use_chunks, maxbitrate, simpleDownloader, auth_string, streamtype, False, swf)
            except:
                pass

def play__rab(ictv):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    sUrl=str(sUrl)+Auth()+"|User-Agent=User-Agent=stagefright/1.2 (Linux;Android 5.1.1)"
    sTitle =  alfabekodla(sTitle)
    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sTitle)
    oGuiElement.setMediaUrl(sUrl)
                

    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    oPlayer.startPlayer()  
mac =""
def StartPort(url, mac = None):
        url = url.replace('TURKvodModul@','').replace('@m3u@TURKvod','?')
        sign = '?'
        url = url.strip(' \t\n\r')
        if url.find('?') > -1:
            sign = '&'
        if mac != None:
            security_key = ""
            security_param = ""
            url = url + sign + 'box_mac=' + mac + security_key + security_param
        if url.find('|') > -1:
                parts = url.split('|')
                url = parts[0]
                pass#print "Here in Turkvod url 6 =", url
                cookie = parts[1]
                req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 TURKvod 9.0',
                 'Connection': 'Close',
                 'Cookie': cookie})
        else:
                req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 TURKvod 9.0',
                 'Connection': 'Close'})
        xmlstream = urllib2.urlopen(req).read()
        pass#print "Here in Turkvod xmlstream  =", xmlstream 

        return xmlstream
		
yen= "aHR0cHM6Ly9kbC5kcm9wYm94dXNlcmNvbnRlbnQuY29tL3MvNDJncW4wZWlkcW82MTlmL2hkZC54bWw="
yeni =base64.b64decode(yen)
http = yeni+mac				
def terscevir(cba):
        oku = ""
        i = len(cba) - 1
        while i >= 0:
            oku += cba[i]
            i -= 1
        return oku        
def blutv():
                        
     Host = "http://turkvod.me/90/iptv/modul.php?site=TURKvod+Ulusal+Kanallar&tur=s&url=blutv.com.tr"                   
     url = StartPort(Host, mac)
     return url

def regex_from_to(text, from_string, to_string, excluding=True):
	import re,string
	if excluding:
		try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
		except: r = ''
	else:
		try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
		except: r = ''
	return r


def regex_get_all(text, start_with, end_with):
	import re,string
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r


def OPEN_URL(url):
	import requests
	headers = {}
	headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'
	link = requests.session().get(url, headers=headers, verify=False).text
	link = link.encode('ascii', 'ignore')
	return link
     
def piptvplay_info(): #affiche les genres
    
    
    oInputParameterHandler = cInputParameterHandler()
    name = oInputParameterHandler.getValue('sMovieTitle')
    url = oInputParameterHandler.getValue('siteUrl')    
    iconimage= oInputParameterHandler.getValue('siteUrl') 
    Header = '|User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Mobile Safari/537.36'
    sUrl= url  + Header 
    sTitle=  alfabekodla(name) 
    OTVPLAYER.playLink(sTitle,sUrl)

class MyPlayer (xbmc.Player):
    def __init__ (self):
        xbmc.Player.__init__(self)

    def play(self, url, listitem):
        print 'Now im playing... %s' % url
        self.stopPlaying.clear()
        xbmc.Player( ).play(url, listitem)
        
    def onPlayBackEnded( self ):
        # Will be called when xbmc stops playing a file
        print "seting event in onPlayBackEnded " 
        self.stopPlaying.set();
        print "stop Event is SET" 
    def onPlayBackStopped( self ):
        # Will be called when user stops xbmc playing a file
        print "seting event in onPlayBackStopped " 
        self.stopPlaying.set();
        print "stop Event is SET" 

import sys
import re
import requests


def request_file(uri):
    """
    Make a request and return its content
    
    Args:
        uri (string): The URI with the protected content
    
    Returns:
        object: Response object
    """
    r = requests.get(uri, stream=True, headers={"User-Agent": 'CED'})
    return r
    

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        xbmc.Player().play(url,liz)
        sys.exit()
        return ok


def ced_main(args):
    """
    Main function called by launcher
    """
    logger = logging.getLogger('CED')	
    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)

    logger.info("Starting ced-launcher.py ...")

    # With input file
    if args.file:
        logger.info("Trying to open the input file ...")

        try:
            lines = [line.rstrip('\n') for line in open(args.file)]
            replace_content(lines)
            logger.info("The replacements were done successfully")
        except Exception as e:
            sys.exit("ERROR: Ensure you have permission to read the input file.")

    # With URI
    elif args.uri:
        logger.info("Trying to get the content of the requested URI ...")

        try:
            replace_content(request_file(args.uri), True)
            logger.info("The replacements were done successfully")
        except Exception as e:
            sys.exit("ERROR: Ensure you have permission to write the output file.")
