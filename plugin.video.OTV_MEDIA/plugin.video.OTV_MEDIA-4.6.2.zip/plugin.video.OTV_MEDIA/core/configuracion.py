# -*- coding: iso-8859-1 -*-
#------------------------------------------------------------
# streamondemand-pureita-master - XBMC Plugin
# Configuraci�n
# http://blog.tvalacarta.info/plugin-xbmc/streamondemand-pureita-master/
#------------------------------------------------------------

from Plugins.Extensions.OrhanTV1.sources.core import downloadtools
from Plugins.Extensions.OrhanTV1.sources.core import config
from platformcode import logger

logger.info("[configuracion.py] init")

def mainlist(params,url,category):
    logger.info("[configuracion.py] mainlist")
    
    config.open_settings( )
