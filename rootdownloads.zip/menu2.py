import xbmc,os

addon_id   = 'plugin.video.bygencer'

icon       = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))


def cat():
	addDir('[COLOR white][B]TEST 1[/COLOR][/B]','yayin1',2,'https://pbs.twimg.com/profile_images/858019601820467200/FWi_rtsG.jpg',fanart,'')
	addDir('[COLOR white][B]TEST 2[/COLOR][/B]','yayin2',2,'https://pbs.twimg.com/profile_images/858019601820467200/FWi_rtsG.jpg',fanart,'')
	addDir('[COLOR white][B]TEST 3[/COLOR][/B]','yayin3',2,'https://pbs.twimg.com/profile_images/858019601820467200/FWi_rtsG.jpg',fanart,'')
	addDir('[COLOR white][B]TEST 4[/COLOR][/B]','yayin4',2,'https://pbs.twimg.com/profile_images/858019601820467200/FWi_rtsG.jpg',fanart,'')
	addDir('[COLOR white][B]TEST 5[/COLOR][/B]','yayin5',2,'https://pbs.twimg.com/profile_images/858019601820467200/FWi_rtsG.jpg',fanart,'')
	addDir('[COLOR white][B]TEST 6[/COLOR][/B]','yayin6',2,'https://pbs.twimg.com/profile_images/858019601820467200/FWi_rtsG.jpg',fanart,'')
	
def get(url):
	if url == 'yayin6':
		yayin6()
	elif 'shadownetchan:' in url:
		shadownetchannels(url)
	elif url == 'yayin3':
		yayin3()
	elif url == 'yayin2':
		yayin2()
	elif url == 'yayin4':
		yayin4()
	elif url == 'yayin1':
		yayin1()
	elif url == 'yayin5':
		yayin5()
		
def yayin5():
	import re
	open  = OPEN_URL('https://archive.org/download/message_2019/yayin1.m3u')
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for name,url in regex:
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,10,icon,fanart,'')
		
def yayin4():
	import re
	open  = OPEN_URL('http://vip.bacoiptv.site:8080/get.php?username=myilmaz&password=eThQHRSXpk&type=m3u')
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for name,url in regex:
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,10,icon,fanart,'')
		
		
def yayin2():
	import re
	open  = OPEN_URL('http://liveline.nu:8000/get.php?username=yNW9Z6ExZk&password=MRcFd1JKmL&type=m3u')
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for name,url in regex:
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,10,icon,fanart,'')
        
def yayin1():
	import re
	open  = OPEN_URL('https://archive.org/download/message_2019/yayin1.m3u')
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for name,url in regex:
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,10,icon,fanart,'')
		
		
def yayin3():
	import re
	open  = OPEN_URL('http://denms.ru/playlists/bygencer/Rehim.m3u')
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for name,url in regex:
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,10,icon,fanart,'')
		
		
		
def yayin6():
	import re
	open  = OPEN_URL('https://www.dropbox.com/s/pzijwxy6o5mtohb/spor.m3u?dl=1')
	regex = re.compile('#EXTINF:.+?\,(.+?)\n(.+?)\n', re.MULTILINE|re.DOTALL).findall(open)
	for name,url in regex:
		addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,10,icon,fanart,'')
        
def log(text):
	file = open(logfile,"w+")
	file.write(str(text))
				
				
######################################################################################################
		
		
		
def regex_from_to(text, from_string, to_string, excluding=True):
	import re,string
	if excluding:
		try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
		except: r = ''
	else:
		try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
		except: r = ''
	return r


def regex_get_all(text, start_with, end_with):
	import re,string
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r



def OPEN_URL(url):
	import requests
	headers = {}
	headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'
	link = requests.session().get(url, headers=headers, verify=False).text
	link = link.encode('ascii', 'ignore')
	return link
		
def addDir(name,url,mode,iconimage,fanart,description):
	import xbmcgui,xbmcplugin,urllib,sys
	u=sys.argv[0]+"?url="+url+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==10:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
	xbmcplugin.endOfDirectory